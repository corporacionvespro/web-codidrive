<?php
require("logica/clsUsuario.php");
require_once("logica/clsCompartido.php");
if(!isset($_SESSION['idusuario'])){
	header('Location:index.php');
}
$objUsu= new clsUsuario();
$permisos=$objUsu->consultarOpciones($_SESSION['idperfil']);
$permisos=$permisos->fetchAll();
$img="";

$formatos=array("JPG","jpg","JPEG","jpeg","PNG","png","gif","GIF");
$existe=false;
$img="files/imagenes/usuarios/".$_SESSION['login'];
foreach($formatos as $k=>$v){
	if(file_exists($img.'.'.$v)){
		$img=$img.'.'.$v;
		$existe=true;
		break;
	}
}

if(!$existe){
	$img="files/imagenes/user_icon.png";	
}
	
$_SESSION["img"]=$img;
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>TAQINI SISTEMAS</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<!-- CSS -->
	<!-- CSS -->
	<!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="plugins/ionicons/css/ionicons.min.css">
	<!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/skin-blue-light.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
    <!-- Morris chart -->
    <link rel="stylesheet" href="plugins/morris/morris.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
	<!-- Time Picker-->
    <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
	<!-- fullCalendar 2.2.5-->
    <link rel="stylesheet" href="plugins/fullcalendar/fullcalendar.min.css">
    <link rel="stylesheet" href="plugins/fullcalendar/fullcalendar.print.css" media="print">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
	<!-- loading Overlay -->
	<link rel="stylesheet" href="plugins/loading/loading-overlay.css">
	<!-- file input -->
	<link rel="stylesheet" href="plugins/fileinput/css/fileinput.css">
	<!-- include summernote css/js-->
	<link href="plugins/summernote/summernote.css" rel="stylesheet">	
	<!-- Croppie -->
	<link rel="stylesheet" href="plugins/croppie/croppie.css">    
   	<!-- Counter -->
	<link rel="stylesheet" href="plugins/counter/counter.css">  
	<!-- Toast -->
	<link rel="stylesheet" href="plugins/toast/jquery.toast.min.css">	
    <!-- JSCRIPT -->
    
	<!-- JSCRIPT -->

	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="plugins/jQueryUI/jquery-ui.min.js"></script>
	<!-- jQueryTouch -->
	<script src="plugins/jQueryTouch/jquery.ui.touch-punch.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.js"></script>
	<!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
	<!-- Chart JS-->
	<script src="plugins/chartjs/Chart.min.js"></script>
    <!-- Morris.js charts -->
    <script src="plugins/raphael/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js"></script>
    <!-- AmCharts - Theme Light-->
    <script src="plugins/amcharts/amcharts.js"></script>
    <script src="plugins/amcharts/serial.js"></script>
    <script src="plugins/amcharts/themes/light.js"></script>
    <script src="plugins/amcharts/lang/es.js"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <!-- jQuery Knob Chart -->
    <script src="plugins/knob/jquery.knob.js"></script>
	 <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <!-- daterangepicker -->
    <script src="plugins/moment/moment.min.js"></script>
    <script src="plugins/daterangepicker/daterangepicker.js"></script>
	<script src="plugins/fullcalendar/fullcalendar.min.js"></script>
	<script src="plugins/fullcalendar/es.js"></script>
	<!-- Time Picker-->
    <script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
	<!-- Loading Overlay -->
	<script src="plugins/loading/loading-overlay.js"></script>
	<!-- File Input -->
	<script src="plugins/fileinput/js/fileinput.js"></script>
	<script src="plugins/fileinput/js/fileinput_locale_es.js"></script>
	<!-- include summernote css/js-->
	<script src="plugins/summernote/summernote.js"></script>
    <script src="plugins/summernote/lang/summernote-es-ES.min.js"></script>
	<!-- Croppie -->
	<script src="plugins/croppie/croppie.js"></script>      
    <script src="plugins/croppie/exif.js"></script>
    <!-- Autosize text area -->
    <script src="plugins/autosize/autosize.min.js"></script>
    <!-- Counter -->
    <script src="plugins/counter/countdown.min.js"></script>
    <script src="plugins/counter/lodash.min.js"></script>
    <!-- Video capture-->
    <script src="plugins/fabric/fabric.min.js"></script>     
    <!-- Toast -->
    <script src="plugins/toast/jquery.toast.min.js"></script>    
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhYU_b_Y-42LLmKLNO--iY6IlRlf7y-eU&callback="></script>    
<script>
var xError="%$u$V$%+c";
var msjError="***";
function setRun(urlx, parx, divx, msjx, imgx){
	var s = "", r = /<script>([\s\S]+)<\/script>/mi;
	$('#'+msjx).loadingOverlay();
	$.ajax({
		method: "POST",
		url: urlx+'.php?ajax=true&'+parx
	})
	.done(function( html ) {	
		evaluarActividadSistema(html);
		if(html.indexOf(xError)==-1){
			if (html.match(r)){
				s = RegExp.$1;
				html = html.replace(r, "");
			}
			$( "#"+divx ).html( html );
			var etiquetaScript=document.createElement("script");
			document.getElementsByTagName("head")[0].appendChild(etiquetaScript);
			etiquetaScript.text=s;			
		}
	})
  .fail(function(jqXHR, textStatus, errorThrown){    
    $.toast({'text': 'Error al obtener datos','icon': 'error' })
  })
  .always(function(){
    $('#'+msjx).loadingOverlay('remove');
  });
	
}

function evaluarActividadSistema(xform){
			if(xform.length>9){
				if(xform.substring(0,9)==xError){
					alert(xform.substring(9,xform.length),'salir');
				}
			}			
}

(function(proxied) {
  window.alert = function() {
	NuevaAlerta(arguments[0],arguments[1],arguments[2],arguments[3]);
  };
})(window.alert);


function NuevaAlerta(text,iconx,title,divx){
	var divmodal='divMensaje';
	var icon="";
	if(iconx){
		if(iconx=='info'){icon='fa-info-circle';}
		else if(iconx=='warning' || iconx=='salir'){icon='fa-warning';}
		else if(iconx=='ok'){icon='fa-check-circle'}
		else {icon=iconx}
	}else{
		icon='fa-info-circle';
	}
	if(!(title)){
		title='Mensaje del Sistema';
	}
	if(divx){
		divmodal=divx;
	}
	$('#'+divmodal).on('hidden.bs.modal', function (e) {
		$(e.currentTarget).unbind();
		document.getElementById(divmodal+"Titulo").innerHTML='';
		document.getElementById(divmodal+'Contenido').innerHTML="...";
		if(iconx=='salir'){
			window.open("index.php","_self");
		}
	}).on('show.bs.modal', function(e) {
		document.getElementById(divmodal+"Titulo").innerHTML='<i class="fa '+icon+'"></i> '+title;
		document.getElementById(divmodal+"Contenido").innerHTML=text;
	}).modal("show");	
}

(function(proxied) {
  window.confirm = function() {
	NuevoConfirmar(arguments[0],arguments[1]);
  };
})(window.confirm);

function NuevoConfirmar(text,accionOk){
	var divmodal='divConfirmar';
	var icon="fa-question-circle";
	
	$('#'+divmodal).on('hidden.bs.modal', function (e) {
		$(e.currentTarget).unbind();
		document.getElementById(divmodal+"Titulo").innerHTML='';
		document.getElementById(divmodal+'Contenido').innerHTML="...";		
	}).on('show.bs.modal', function(e) {
		document.getElementById(divmodal+"Titulo").innerHTML='<i class="fa '+icon+'"></i> Mensaje del Confirmación';
		document.getElementById(divmodal+"Contenido").innerHTML=text;
		$("#"+divmodal+"Aceptar").attr("onclick",accionOk+';CloseModal("'+divmodal+'");');
	}).modal("show");	
}

function Salir(){
	confirm('¿Está seguro de salir del sistema?','window.open("index.php","_self")');
}

function ViewModal(page,param,divmodal,title){
		$('#'+divmodal).on('show.bs.modal', function(e) {
			document.getElementById(divmodal+"Titulo").innerHTML=title;
			setRun(page,param,divmodal+'Contenido',divmodal+'Contenido');
			$(e.currentTarget).unbind();
			$('#'+divmodal).on('hidden.bs.modal', function (e) {
				document.getElementById(divmodal+"Titulo").innerHTML='';
				document.getElementById(divmodal+'Contenido').innerHTML="...";
				$("#"+divmodal+"Aceptar").prop("onclick",null);
				$(e.currentTarget).unbind();
			});
		}).modal({
			keyboard: false,
			backdrop: 'static'
		});
}

function CloseModal(divmodal){
	$('#'+divmodal).modal('hide');	
}

    function solo_numero(evt) {
		var charCode = (evt.which) ? evt.which : event.keyCode;
		if(charCode > 31 && (charCode < 48 || charCode > 57)){
			return false;
		}
		return true;
	} 

	function solo_decimal(evt){
		var charCode = (evt.which) ? evt.which : event.keyCode;
		if((charCode > 31 && (charCode < 46 || charCode > 57))||charCode==47){
			return false;
		}
		return true;
	}
	
	function verificar_especial(evt){
		var charCode = (evt.which) ? evt.which : event.keyCode;
		if(charCode <65){
			return false;
		}
		return true;
	}
	
	String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g,"");
	}
	
	$(function() {
		$(this.document).tooltip();
  });
  
  
  function AgregarError(nameElement,mensaje,noparent){
	  if(noparent){
		$('#'+nameElement).addClass('has-error');
	  }else{
		  $('#'+nameElement).parent().addClass('has-error');
	  }
	  $('#'+nameElement).attr("data-toggle","tooltip");
	  $('#'+nameElement).attr("data-original-title",mensaje);
  }
  
  function QuitarError(nameElement, isCorrecto,noparent){
	  if(noparent){
		$('#'+nameElement).removeClass('has-error');
	  }else{
		  $('#'+nameElement).parent().removeClass('has-error');
	  }
	  $('#'+nameElement).attr("data-original-title","");
	  if(isCorrecto){
		  $('#'+nameElement).parent().addClass('has-success');
	  }
  }
  
  function DeshabilitarFormulario(form){
	  $('#'+form).find('input, textarea, button, select').each(
			function(){
				$(this).prop("onclick",null);
				$(this).prop("disabled",true);
			}
		)
  }
  
 var isMobile = {
    Android: function() {
        return navigator.userAgent.match(/Android/i);
    },
    BlackBerry: function() {
        return navigator.userAgent.match(/BlackBerry/i);
    },
    iOS: function() {
        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
    },
    Opera: function() {
        return navigator.userAgent.match(/Opera Mini/i);
    },
    Windows: function() {
        return navigator.userAgent.match(/IEMobile/i);
    },
    any: function() {
        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
    }
};
</script>
  </head>
  <body class="hold-transition skin-blue-light sidebar-mini">
  <audio id="ringtoneNotificacion" src="files/notificacion.mp3"></audio>
    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
        <a href="#" onclick="index.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><img src="files/imagenes/logo_dash.png" style="max-width:80%; margin-top:10px;" valign="middle" /></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><img src="files/imagenes/logo_dash.png" style="max-height:45px; margin-top:5px; padding-bottom:2px;" valign="center" /></span>
        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Mensajes -->
              <li class="dropdown messages-menu notifications-menu">
              	<a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-comments"></i>
                </a>
                <ul class="dropdown-menu notificacion-border">
                  <li class='header'>No tienes nuevos mensajes</li>
                  <li class="footer"><a href="#">Ver todos los mensajes</a></li>
                </ul>                
              </li>
              <!-- Notifications: style can be found in dropdown.less -->
              <li class="dropdown messages-menu notifications-menu" id="ulNotificaciones">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-bell"></i>
                </a>
                <ul class="dropdown-menu notificacion-border">
                  <li class='header'>No tienes nuevas notificaciones</li>
                  <li class="footer"><a href="#">Ver todas las notificaciones</a></li>
                </ul>
              </li>
              <!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <img src="<?php echo $img; ?>" class="user-image">
                  <span class="hidden-xs"><?php echo utf8_encode($_SESSION['persona']); ?></span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                    <img src="<?php echo $img;?>" class="img-circle" alt="User Image">
                    <p>
                      <?php echo utf8_encode($_SESSION['persona']); ?>
                      <small><?php echo utf8_encode($_SESSION['login']); ?></small>
					  <small><?php echo date("d/m/Y"); ?></small>
                    </p>
                  </li>
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="#" onClick="setRun('presentacion/micuenta','idx=<?php echo $_SESSION['idusuario'];?>','divForm','divForm')" class="btn btn-default btn-flat">Mi Cuenta</a>
                    </div>
                    <div class="pull-right">
                      <a href="#" onClick="Salir();" class="btn btn-default btn-flat">Cerrar Sesión</a>
                    </div>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
		<!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo $img; ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p style="white-space: normal; text-shadow:2px 2px rgba(191, 190, 190, 0.54)"><?php echo strtolower($_SESSION['persona']); ?></p>
            </div>
          </div>
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
		  
		  
		<li class="active">
			<a href="#" onclick="InicioAdmin()">
				<i class='fa fa-home'></i><span>Inicio</span>
			</a>
		</li>
	<?php
	$idp='';
	$siguiente=next($permisos);
	foreach($permisos as $k=>$v){
		$ultimo=false;
		if($siguiente['idprincipal']!=$v['idprincipal']){
			$ultimo=true;
		}
		if($v['idprincipal']!=$idp){
			echo "<li class='treeview'>
					<a href='#'>
						<i class='fa ".$v['iconprincipal']."'></i><span>".$v['principal']."</span><i class='fa fa-angle-left pull-right'></i>
					</a>
					<ul class='treeview-menu'>";
			$idp=$v['idprincipal'];
		}
					echo "<li>
							<a href='#' onClick=\"setRun('".$v['link']."','idoptx=".$v['idopcion']."','divForm','divForm')\"' >
							<i class='fa ".$v['icon']."'></i>".$v['descripcion']."
							</a></li>";
           if($ultimo){	
		   	echo "</ul></li>";
		   }
		$siguiente=next($permisos);
	}?>
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div id="divForm" class="content-wrapper" style="min-height: 617px;">
        
      </div><!-- /.content-wrapper -->
    </div><!-- ./wrapper -->
	<div class="modal fade bs-example-modal-lg" id="divlibre" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-lg">
	  <div class="modal-content">
      <div class="modal-header">
        <button tabindex="10000" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
        <h4 class="modal-title" id="divlibreTitulo">Título</h4>
      </div>
      <div class="modal-body" id="divlibreContenido">
	  ...
      </div>
    </div>
	</div>
	</div>
    
    	<div class="modal fade bs-example-modal" id="divSinClose" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	  <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="divSinCloseTitulo">Título</h4>
      </div>
      <div class="modal-body" id="divSinCloseContenido">
	  ...
      </div>
    </div>
	</div>
	</div>
    
	<div class="modal fade bs-example-modal-sm" id="divMensaje" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" >
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<div class="modal-header">
					<button tabindex="10001" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
					<h4 class="modal-title" id="divMensajeTitulo">Título</h4>
				</div>
				<div class="modal-body" id="divMensajeContenido">
					...
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				</div>
			</div>
		</div>
	</div>
    	<div class="modal fade bs-example-modal" id="divMensajeMediano" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button tabindex="10000" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
					<h4 class="modal-title" id="divMensajeMedianoTitulo">Título</h4>
				</div>
				<div class="modal-body" id="divMensajeMedianoContenido">
					...
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				</div>
			</div>
		</div>
	</div>
    	<div class="modal fade bs-example-modal" id="divMensajeCumple" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header hidden">
					<button tabindex="10000" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
					<h4 class="modal-title" id="divMensajeCumpleTitulo">Título</h4>
				</div>
				<div class="modal-body" id="divMensajeCumpleContenido">
					...
				</div>
				<div class="modal-footer">
                	<h4 class="pull-left" id="txtMsjCompartirFacebook"></h4>                    
					<a class="btn btn-social btn-facebook" id="btnLoginFacebook" style="display:none">
                    	<i class="fa fa-facebook"></i> Iniciar Sesion
                  	</a>                                    
					<a class="btn btn-social btn-facebook" id="btnCompartirFacebook" style="display:none">
                    	<i class="fa fa-facebook"></i> Compartir en Facebook
                  	</a>                
					<button type="button" class="btn btn-default" onClick="CloseModal('divMensajeCumple');" >Cerrar</button>
				</div>
			</div>
		</div>
	</div>    
	<div class="modal fade bs-example-modal-sm" id="divConfirmar" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" >
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<div class="modal-header">
					<button tabindex="10000" type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
					<h4 class="modal-title" id="divConfirmarTitulo">Título</h4>
				</div>
				<div class="modal-body" id="divConfirmarContenido">
					...
				</div>
				<div class="modal-footer" id="divConfirmarFooter">
					<button type="button" class="btn btn-primary" id="divConfirmarAceptar">Aceptar</button>
					<button type="button" class="btn btn-default" id="divConfirmarCancelar" data-dismiss="modal">Cancelar</button>
				</div>
			</div>
		</div>		
	</div>
	<script>
function InicioAdmin(){
<?php if(file_exists('presentacion/dash_'.$_SESSION['idperfil'].'.php')){
?>
	setRun('presentacion/dash_<?php echo $_SESSION['idperfil'];?>','','divForm','divForm');
<?php
}else{	
	?>
	setRun('presentacion/dash_default','','divForm','divForm');
<?php 
}
?>
}
InicioAdmin();

function getNotificaciones(sonido){
  /*
	$('#ulNotificaciones').loadingOverlay({tipo:'input'});
	$.ajax({
		method: "POST",
		url: 'controlador/contNotificacion.php',
		data: {accion: "NOTIFICACIONES"}
	})
	.done(function( text ) {
		evaluarActividadSistema(text);
		$('#ulNotificaciones').loadingOverlay('remove');
		if(text.substring(0,3)!='***'){
			result=text.split("##||##");
			if(result[0]>0){
				if(sonido){
					document.getElementById('ringtoneNotificacion').play();
				}
			}
			element=document.getElementById('ulNotificaciones');
			element.innerHTML=result[1];
		}
	});
  */
}

getNotificaciones(true);

window.setInterval(function(){
	getNotificaciones(true);  
}, 60000);

function SetLeidoNotificacion(iddn){
	$.ajax({
		method: "POST",
		url: 'controlador/contNotificacion.php',
		data: {'accion':'MENSAJE_LEIDO', 'iddn': iddn}
	})
	.done(function( text ) {
		evaluarActividadSistema(text);
		getNotificaciones(false);
	});	
}

</script>
  </body>
</html>
