<?php
session_start();
session_destroy();
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>TAQINI SISTEMAS</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="plugins/ionicons/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
	<!-- loading Overlay -->
	<link rel="stylesheet" href="plugins/loading/loading-overlay.css">
    	
	<!-- JAVA SCRIPT -->
	<!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js"></script>
	<!-- Loading Overlay -->
	<script src="plugins/loading/loading-overlay.js"></script>    
	<script>
(function(proxied) {
  window.alert = function() {
	NuevaAlerta(arguments[0],arguments[1]);
  };
})(window.alert);


function NuevaAlerta(text,iconx){
		var divmodal='divMensaje';
		var icon="";
		if(iconx){
			if(iconx=='info'){icon='fa-info-circle';}
			else if(iconx=='warning'){icon='fa-warning';}
			else if(iconx=='ok'){icon='fa-check-circle'}
			else {icon=iconx}
		}else{
			icon='fa-info-circle';
		}
		$('#'+divmodal).on('hidden.bs.modal', function () {
			document.getElementById(divmodal+"Titulo").innerHTML='';
			document.getElementById(divmodal+'Contenido').innerHTML="...";
		}).on('show.bs.modal', function(e) {
			document.getElementById(divmodal+"Titulo").innerHTML='<i class="fa '+icon+'"></i> Mensaje del Sistema';
			document.getElementById(divmodal+"Contenido").innerHTML=text;
		}).modal("show");	
	}
	</script>
  </head>
  <body class="hold-transition login-page" onLoad="inicio()">
    <div class="login-box">
      <div class="login-logo">
        <img class="img-responsive" src="files/imagenes/logo_intranet.png" style="margin-top:30px; margin-bottom:20px; display:inline;" />

      </div>
      <div class="login-box-body">
        <p class="login-box-msg" style="font-weight: 700; font-size: 28px; font-style: italic;">INGRESO AL SISTEMA</p>
        <form id="frmLogin" name="frmLogin">
          <div class="form-group has-feedback">
            <input onKeyUp="if(event.keyCode=='13'){LogIn();}" name="txtLogin" id="txtLogin" type="text" class="form-control-login" placeholder="Usuario">
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input onKeyUp="if(event.keyCode=='13'){LogIn();}" name="txtPassword" id="txtPassword" type="password" class="form-control-login" placeholder="Contraseña">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
            <div class="col-xs-8">
              <div class="checkbox icheck" style="display: none;">
                <label>
				  <input type="hidden" name="accion" id="accion" value="IN" />
                </label>
              </div>
            </div><!-- /.col -->
            <div class="col-xs-4">
              <button type="button" onClick="LogIn()" class="btn btn-primary-login btn-block btn-flat">Ingresar</button>
            </div><!-- /.col -->
          </div>
        </form>
      </div><!-- /.login-box-body -->  
    </div><!-- /.login-box -->	
	<div class="modal fade bs-example-modal-sm" id="divMensaje" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" >
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
					<h4 class="modal-title" id="divMensajeTitulo">Título</h4>
				</div>
				<div class="modal-body" id="divMensajeContenido">
					...
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				</div>
			</div>
		</div>
	</div>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
	  
	  
	  function inicio(){
		document.getElementById('txtLogin').focus();	
		}
		
	function LogIn(){
		$('#frmLogin').loadingOverlay();
		var datax = $('#frmLogin').serializeArray();
		$.ajax({
			method: "POST",
			url: 'controlador/contUsuario.php',
			data: datax
		})
		.done(function( text ) {
			$('#frmLogin').loadingOverlay('remove');
			if(text.substring(0,3)=='***'){
				alert(text,'warning');
			}else{
				window.open(text,'_self');
			}
		});
	}
    </script>
  </body>
</html>
