<?php 
require_once("../logica/clsCaja.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objCaja=new clsCaja();

	switch ($accion){
		
		case "NUEVO_CAJA": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();
					
					$fecha = null; $fecha_comision=null;$comision=null;$estado_comision=null;
					if ($_POST['fecha'] !== '') {
						$dat = explode('/', $_POST['fecha']);
						$fecha = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['tipo'] == 'I') {
						if ($_POST['fecha_comision'] !== '') {
							$dat = explode('/', $_POST['fecha_comision']);
							$fecha_comision = $dat[2].'-'.$dat[1].'-'.$dat[0];
						}
						$comision = $_POST['comision'];
						$estado_comision = $_POST['estado_comision'];
					}
					
					
					$objCaja->insertarCaja($_POST['importe'],$comision,$_POST['descripcion'],$fecha_comision,$estado_comision,$fecha,$_POST['tipo'],'N');
					echo "movimiento de caja registrado satisfactoriamente";
					

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos movimiento de caja no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_CAJA": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$fecha = null; $fecha_comision=null;$comision=null;$estado_comision=null;
					if ($_POST['fecha'] !== '') {
						$dat = explode('/', $_POST['fecha']);
						$fecha = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					
					if ($_POST['tipo'] == 'I') {
						if ($_POST['fecha_comision'] !== '') {
							$dat = explode('/', $_POST['fecha_comision']);
							$fecha_comision = $dat[2].'-'.$dat[1].'-'.$dat[0];
						}
						$comision = $_POST['comision'];
						$estado_comision = $_POST['estado_comision'];
					}
					
					$objCaja->actualizarCaja($_POST['txtIdCaja'],$_POST['importe'],$comision,$_POST['descripcion'],$fecha_comision,$estado_comision,$fecha,$_POST['tipo'],'N');

					echo "movimiento de caja actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos movimiento de caja no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_CAJA": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idcaja[]'];
						foreach($ids as $k=>$v){
							$objCaja->actualizarEstadoCaja($v,$_POST['estado']);
						}
					}else{
					$objCaja->actualizarEstadoCaja($_POST['idcaja'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos movimiento de caja no ha sido removido, intentelo nuevamente";
				}
				break;

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>