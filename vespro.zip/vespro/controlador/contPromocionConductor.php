<?php 
require_once("../logica/clsPromocionConductor.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objPromocionConductor=new clsPromocionConductor();

	switch ($accion){
		
		case "NUEVO_PROMOCIONCONDUCTOR": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();
					$fechauso = null; $fechahora = null; $vigencia = null;
					
					if ($_POST['fechahora'] !== '') {
						$dat = explode('/', $_POST['fechahora']);
						$fechahora = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['vigencia'] !== '') {
						$dat = explode('/', $_POST['vigencia']);
						$vigencia = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}

					$objPromocionConductor->insertarPromocionConductor($_POST['codigo'],$fechahora,$_POST['mensaje'],'N',$fechauso,$vigencia,$_POST['idconductor'],$_POST['centro_autorizado'],$_POST['direccion']);

					echo "Promocion de Conductor registrada satisfactoriamente";
					

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos Promocion de Conductor no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_PROMOCIONCONDUCTOR": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$fechauso = null; $fechahora = null; $vigencia = null;
					
					if ($_POST['fechahora'] !== '') {
						$dat = explode('/', $_POST['fechahora']);
						$fechahora = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['vigencia'] !== '') {
						$dat = explode('/', $_POST['vigencia']);
						$vigencia = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					
					$objPromocionConductor->actualizarPromocionConductor($_POST['txtIdPromocioncond'],$_POST['codigo'],$fechahora,$_POST['mensaje'],'N',$fechauso,$vigencia,$_POST['idconductor'],$_POST['centro_autorizado'],$_POST['direccion']);
					echo "Promocion de Conductor actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos Promocion de Conductor no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_PROMOCIONCONDUCTOR": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idpromocioncond[]'];
						foreach($ids as $k=>$v){
							$objPromocionConductor->actualizarEstadoPromocionConductor($v,$_POST['estado']);
						}
					}else{
					$objPromocionConductor->actualizarEstadoPromocionConductor($_POST['idpromocioncond'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos la Promocion de Conductor no ha sido removido, intentelo nuevamente";
				}
				break;


		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>