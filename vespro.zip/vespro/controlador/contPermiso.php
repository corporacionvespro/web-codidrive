<?php 
require_once("../logica/clsPermiso.php");
require_once("../logica/clsCiclo.php");
require_once("../logica/clsCompartido.php");
require_once("../logica/clsNotificacion.php");
require_once("../logica/clsAlumno.php");
controlador($_POST['accion']);

function controlador($accion){
	$objPer = new clsPermiso();
	$objCiclo = new clsCiclo();
	$objNot=new clsNotificacion();
	$objAlu = new clsAlumno();

	switch ($accion){
		
		case "NUEVO_PERMISO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$ciclo = $objCiclo->consultarCicloById($_POST["idciclo"])->fetch(PDO::FETCH_NAMED);

					if($_POST["cboTipoPermiso"]=="D"){
						$ini_vigencia=formatoBDFecha($_POST["txtVigenciaPermisoD"]);
						$fin_vigencia=formatoBDFecha($_POST["txtVigenciaPermisoD"]);
					}elseif($_POST["cboTipoPermiso"]=="T"){
						$rango = explode("-", $_POST["txtVigenciaPermisoT"]);
						$ini_vigencia=formatoBDFecha(trim($rango[0]));
						$fin_vigencia=formatoBDFecha(trim($rango[1]));
					}else{
						$ini_vigencia=$ciclo["fecha_inicio"];
						$fin_vigencia=$ciclo["fecha_fin"];
					}

					if(!isset($_POST["txtEspecificarSolicitante"])){
						$_POST["txtEspecificarSolicitante"]="";
					}

					$objPer->insertarPermiso($_POST['idmatricula'], formatoBDFecha($_POST["txtFechaSolicitud"]),  $_POST["cboPara"], $_POST["txtHora"], $_POST["cboTipoPermiso"], $_POST["dias"], $ini_vigencia, $fin_vigencia, $_POST["cboSolicitante"], $_SESSION["idusuario"], $_POST["idciclo"], $_POST["txtObservacionPermiso"], $ciclo["idinstitucion"], $ciclo["idsucursal"], $_POST["cboEstadoPermiso"], $_POST["txtEspecificarSolicitante"]);



					//Envio de notificacion
					if($_POST["cboEstadoPermiso"]=="A"){
						$tipov = array("T"=>"TEMPORAL","D"=>"POR UN DIA","P"=>"PERMANENTE");
						$tipop = array("S"=>"SALIDA", "I"=>"ENTRADA");
						$search=array("-9","0","1","2","3","4","5","6");
						if($_POST["cboTipoPermiso"]=="D"){
							$replace=array("","Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
						}else{
							$replace=array("Todos los días","Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
						}
						$turnos = array("M"=>"MAÑANA","T"=>"TARDE");

						$alumno = $objAlu->consultarAlumnoIdmatricula($_POST['idmatricula'])->fetch(PDO::FETCH_NAMED);
						
						$contenido="<h4 style=\"text-align: center;\" class=\"text-green\">NUEVO PERMISO ".$tipov[$_POST["cboTipoPermiso"]]."</h4>";
						$contenido.="<p>".$_SESSION['persona']." ha registrado un nuevo permiso <strong>".$tipov[$_POST["cboTipoPermiso"]]."</strong> para el alumno <strong>".$alumno["alumno"]."</strong> del aula <strong>".$alumno["aula"]." (TURNO ".$turnos[$alumno["turno"]].")</strong>, cuya <strong>".$tipop[$_POST["cboPara"]]."</strong> será <strong>".$_POST["txtHora"]."</strong> (".str_replace($search, $replace, $_POST["dias"])."). El permiso será vigente del ".formatoCortoFecha($ini_vigencia)." al ".formatoCortoFecha($fin_vigencia)."</p><center><img class=\"img-responsive\" src=\"files/imagenes/alumnos/".$alumno['idciclo']."/carnet/".$alumno['foto'].".JPG\" /></center>";
						$urlInterno="presentacion/adminConsultaPermisos";
						$idperfiles="2,7,10";
						$icono="fa-user-plus";
						$colorIcono="green";
						$objNot->insertarNotificacion("I","0",$contenido, $urlInterno,"", $idperfiles,"0","0","","0","0", $_SESSION['idusuario'], $icono, $colorIcono,0,0);
						$idnotificacion=$objNot->getUltimoIdNotificacion();
						$objNot->registrarNotificacionSegmentado($idnotificacion,$idperfiles,"0","0","0","0","0");
						$objNot->publicarNotificacion($idnotificacion,1);
					}
					//fin de envio de notificacion



  				    $cnx->commit();										
					echo "Datos registrados satisfactoriamente";
						
				}catch(Exception $e){
					$cnx->rollBack();					
					echo "*** Lo sentimos, datos no han podido ser registrado, intentelo nuevamente".$e->getMessage();
				}
				break;

		case "ACTUALIZAR_PERMISO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$ciclo = $objCiclo->consultarCicloById($_POST["idciclo"])->fetch(PDO::FETCH_NAMED);

					if($_POST["cboTipoPermiso"]=="D"){
						$ini_vigencia=formatoBDFecha($_POST["txtVigenciaPermisoD"]);
						$fin_vigencia=formatoBDFecha($_POST["txtVigenciaPermisoD"]);
					}elseif($_POST["cboTipoPermiso"]=="T"){
						$rango = explode("-", $_POST["txtVigenciaPermisoT"]);
						$ini_vigencia=formatoBDFecha(trim($rango[0]));
						$fin_vigencia=formatoBDFecha(trim($rango[1]));
					}else{
						$ini_vigencia=$ciclo["fecha_inicio"];
						$fin_vigencia=$ciclo["fecha_fin"];
					}

					if(!isset($_POST["txtEspecificarSolicitante"])){
						$_POST["txtEspecificarSolicitante"]="";
					}

					$permiso = $objPer->consultarPermisoById($_POST['txtIdPermiso'])->fetch(PDO::FETCH_NAMED);					

					$objPer->actualizarPermiso($_POST['txtIdPermiso'], formatoBDFecha($_POST["txtFechaSolicitud"]), $_POST["cboPara"], $_POST["txtHora"], $_POST["cboTipoPermiso"], $_POST["dias"], $ini_vigencia, $fin_vigencia, $_POST["cboSolicitante"], $_POST["txtObservacionPermiso"], $_POST["cboEstadoPermiso"], $_POST["txtEspecificarSolicitante"]);


					//Envio de notificacion

					if($permiso["estado"]=='A' || $_POST["cboEstadoPermiso"]=='A'){
						$tipov = array("T"=>"TEMPORAL","D"=>"POR UN DIA","P"=>"PERMANENTE");
						$tipop = array("S"=>"SALIDA", "I"=>"ENTRADA");
						$search=array("-9","0","1","2","3","4","5","6");
						if($_POST["cboTipoPermiso"]=="D"){
							$replace=array("","Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
						}else{
							$replace=array("Todos los días","Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
						}						
						$turnos = array("M"=>"MAÑANA","T"=>"TARDE");
						$frase="";
						$contenido="";
						if($permiso["estado"]=='A' && $_POST["cboEstadoPermiso"]=='A'){
							$contenido="<h4 style=\"text-align: center;\" class=\"text-blue\">ACTUALIZACION DE PERMISO ".$tipov[$_POST["cboTipoPermiso"]]."</h4>";
							$frase="ACTUALIZADO";
						}else if($permiso["estado"]=='I' && $_POST["cboEstadoPermiso"]=='A'){
							$contenido="<h4 style=\"text-align: center;\" class=\"text-blue\">ACTIVACION DE PERMISO ".$tipov[$_POST["cboTipoPermiso"]]."</h4>";						
							$frase="ACTIVADO";
						}else if($permiso["estado"]=='A' && $_POST["cboEstadoPermiso"]=='I'){
							$contenido="<h4 style=\"text-align: center;\" class=\"text-red\">DESACTIVACION DE PERMISO ".$tipov[$_POST["cboTipoPermiso"]]."</h4>";						
							$frase="DESACTIVADO";
						}
						$contenido.="<p>".$_SESSION['persona']." ha <strong>".$frase."</strong> el  permiso <strong>".$tipov[$_POST["cboTipoPermiso"]]."</strong> del alumno <strong>".$permiso["alumno"]."</strong> del aula <strong>".$permiso["aula"]." (TURNO ".$turnos[$permiso["turno"]].")</strong>, cuya <strong>".$tipop[$_POST["cboPara"]]."</strong> será <strong>".$_POST["txtHora"]."</strong> (".str_replace($search, $replace, $_POST["dias"])."). El permiso será vigente del ".formatoCortoFecha($ini_vigencia)." al ".formatoCortoFecha($fin_vigencia)."</p><center><img class=\"img-responsive\" src=\"files/imagenes/alumnos/".$permiso['idciclo']."/carnet/".$permiso['foto'].".JPG\" /></center>";
						$urlInterno="presentacion/adminConsultaPermisos";
						$idperfiles="2,7,10";
						$icono="fa-exclamation-circle";
						$colorIcono="blue";
						$objNot->insertarNotificacion("I","0",$contenido, $urlInterno,"", $idperfiles,"0","0","","0","0", $_SESSION['idusuario'], $icono, $colorIcono,0,0);
						$idnotificacion=$objNot->getUltimoIdNotificacion();
						$objNot->registrarNotificacionSegmentado($idnotificacion,$idperfiles,"0","0","0","0","0");
						$objNot->publicarNotificacion($idnotificacion,1);
					}
					//fin de envio de notificacion


  				    $cnx->commit();										
					echo "Datos actualizados satisfactoriamente";
						
				}catch(Exception $e){
					$cnx->rollBack();					
					echo "*** Lo sentimos, datos no han podido ser actualizados, intentelo nuevamente. ".$e->getMessage();
				}
				break;
				
		case "CAMBIAR_ESTADO_PERMISO":
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$objPer->cambiarEstadoPermiso($_POST["idpermiso"],$_POST["estado"]);


				if($_POST["estado"]=="E"){
					//Envio de notificacion
					$tipov = array("T"=>"TEMPORAL","D"=>"POR UN DIA","P"=>"PERMANENTE");
					$tipop = array("S"=>"SALIDA", "I"=>"ENTRADA");
					$search=array("-9","0","1","2","3","4","5","6");
					$permiso = $objPer->consultarPermisoById($_POST['idpermiso'])->fetch(PDO::FETCH_NAMED);
					if($permiso["tipo_vigencia"]=="D"){
						$replace=array("","Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
					}else{
						$replace=array("Todos los días","Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado");
					}					
					$turnos = array("M"=>"MAÑANA","T"=>"TARDE");

					
					$contenido="<h4 style=\"text-align: center;\" class=\"text-red\">ELIMINACION DE PERMISO ".$tipov[$permiso["tipo_vigencia"]]."</h4>";
					$contenido.="<p>".$_SESSION['persona']." ha <strong class=\"text-red\">ELMINADO</strong> el  permiso <strong>".$tipov[$permiso["tipo_vigencia"]]."</strong> del alumno <strong>".$permiso["alumno"]."</strong> del aula <strong>".$permiso["aula"]." (TURNO ".$turnos[$permiso["turno"]].")</strong>, cuya <strong>".$tipop[$permiso["tipo_permiso"]]."</strong> era <strong>".$permiso["hora"]."</strong> (".str_replace($search, $replace, $permiso["dias"]).").</p><center><img class=\"img-responsive\" src=\"files/imagenes/alumnos/".$permiso['idciclo']."/carnet/".$permiso['foto'].".JPG\" /></center>";
					$urlInterno="presentacion/adminConsultaPermisos";
					$idperfiles="2,7,10";
					$icono="fa-user-times";
					$colorIcono="red";
					$objNot->insertarNotificacion("I","0",$contenido, $urlInterno,"", $idperfiles,"0","0","","0","0", $_SESSION['idusuario'], $icono, $colorIcono,0,0);
					$idnotificacion=$objNot->getUltimoIdNotificacion();
					$objNot->registrarNotificacionSegmentado($idnotificacion,$idperfiles,"0","0","0","0","0");
					$objNot->publicarNotificacion($idnotificacion,1);
					//fin de envio de notificacion
				}
  				    $cnx->commit();										
					echo "Datos actualizados satisfactoriamente";
						
				}catch(Exception $e){
					$cnx->rollBack();					
					echo "*** Lo sentimos, datos no han podido ser actualizados, intentelo nuevamente. ".$e->getMessage();
				}
				break;

		case "CAMBIAR_ESTADO_PERMISOC":
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$estados = array("P"=>"PENDIENTE","E"=>"EFECTUADO");
					$permiso = $objPer->obtenerPermisoById($_POST["idpermiso"])->fetch(PDO::FETCH_NAMED);					
					$fecha=$_POST["fecha"];
					
					if($_POST["idpermisoc"]==""){
						$objPer->insertarPermisoCabecera($permiso['idpermiso'], $fecha, $permiso['idciclo'], $permiso['idmatricula'], $_SESSION['idusuario'], $permiso['idinstitucion'], $permiso['idsucursal'], $_POST["estado"]);
						$idpermisoc = $objPer->obtenerUltimoIdPermisoC($permiso['idpermiso']);
					}else{
						$idpermisoc = $_POST["idpermisoc"];
						$objPer->cambiarEstadoPermisoC($_POST["idpermisoc"],$_POST["estado"]);						
					}

					$objPer->insertarPermisoDetalle($idpermisoc, "El usuario ".$_SESSION["persona"]." ha modificado el permiso a ".$estados[$_POST["estado"]], $_SESSION["idusuario"], 1, "N");					

  				    $cnx->commit();										
					echo "Datos actualizados satisfactoriamente";
						
				}catch(Exception $e){
					$cnx->rollBack();					
					echo "*** Lo sentimos, datos no han podido ser actualizados, intentelo nuevamente. ".$e->getMessage();
				}
				break;

		case "CAMBIAR_ESTADO_PERMISOD":
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$objPer->cambiarEstadoPermisoD($_POST["idpermisod"],$_POST["estado"]);

  				    $cnx->commit();										
					echo "Datos actualizados satisfactoriamente";
						
				}catch(Exception $e){
					$cnx->rollBack();					
					echo "*** Lo sentimos, datos no han podido ser actualizados, intentelo nuevamente. ".$e->getMessage();
				}
				break;

		case "NUEVO_COMENTARIO":
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();
					
					$permiso = $objPer->obtenerPermisoById($_POST["idpermiso"])->fetch(PDO::FETCH_NAMED);


					$fecha=$_POST["fecha"];
					if($_POST["idpermisoc"]==""){
						$objPer->insertarPermisoCabecera($permiso['idpermiso'], $fecha, $permiso['idciclo'], $permiso['idmatricula'], $_SESSION['idusuario'], $permiso['idinstitucion'], $permiso['idsucursal'], "P");
						$idpermisoc = $objPer->obtenerUltimoIdPermisoC($permiso['idpermiso']);
					}else{
						$idpermisoc = $_POST["idpermisoc"];
					}

					$objPer->insertarPermisoDetalle($idpermisoc, $_POST["comentario"], $_SESSION["idusuario"], 0, "N");

  				    $cnx->commit();										
					echo $idpermisoc;
						
				}catch(Exception $e){
					$cnx->rollBack();					
					echo "*** Lo sentimos, comentario no ha podido ser registrado. ".$e->getMessage();
				}
				break;
        
		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
}
?>