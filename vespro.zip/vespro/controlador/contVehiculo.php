<?php 
require_once("../logica/clsVehiculo.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objVehiculo=new clsVehiculo();

	switch ($accion){
		
		case "NUEVO_VEHICULO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					
				$objVehiculo->insertarVehiculo($_POST['txtIdConductor'],$_POST['marca'],$_POST['modelo'],$_POST['placa'],$_POST['color'],$_POST['anio'],$_POST['numunidad'],'N',$_POST['actual'],$_POST['tipo'], $_POST['empresa']);
					echo "Vehiculo registrado satisfactoriamente";
					

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos vehiculo no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_VEHICULO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					
				$objVehiculo->actualizarVehiculo($_POST['txtIdVehiculo'],$_POST['txtIdConductor'],$_POST['marca'],$_POST['modelo'],$_POST['placa'],$_POST['color'],$_POST['anio'],$_POST['numunidad'],'N',$_POST['actual'],$_POST['tipo'],$_POST['empresa']);
					echo "Vehiculo actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos vehiculo no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_VEHICULO": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idvehiculo[]'];
						foreach($ids as $k=>$v){
							$objVehiculo->actualizarEstadoVehiculo($v,$_POST['estado']);
						}
					}else{
					$objVehiculo->actualizarEstadoVehiculo($_POST['idvehiculo'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos el vehiculo no ha sido removido, intentelo nuevamente";
				}
				break;

		case "GUARDAR_FOTO":
			try{
					$idvehiculo=$_POST['idvehiculo'];
                    $urlbase="../files/imagenes/vehiculos";

                    $query = $_SERVER['PHP_SELF'];
					$path = pathinfo( $query );

					$urlbase_link='http://'.$_SERVER['HTTP_HOST'].dirname($path['dirname'])."/files/imagenes/vehiculos/";

                    $name=uniqid('conductor_').".JPG";
					$fullname=$urlbase."/".$name;

                    if (!file_exists($urlbase) && !is_dir($urlbase)){
                        mkdir($urlbase,0777);
                    }
					
					if(file_exists($fullname)){
						@unlink($fullname);
					}
														
                    if(isset($_POST['foto'])){
                        $str="data:image/jpeg;base64,"; 
                        $_POST['foto']=str_replace($str,"",$_POST['foto']);
                        file_put_contents($fullname, base64_decode($_POST['foto']));
                    }

                    $objVehiculo->actualizarFotoVehiculo($idvehiculo, $urlbase_link.$name);
					echo "IMAGEN GUARDADA SATISFACTORIAMENTE";
			}catch(Exception $e){
				echo "*** No fue posible guardar, intentelo nuevamente. ".$e->getMessage();
			}
			break;
		

        

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>