<?php 
require_once("../logica/clsTarifario.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objTarifario=new clsTarifario();

	switch ($accion){
		
		case "NUEVO_TARIFARIO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();
					$ubigeo_dir_dist=null;
					$idzona_origen = null;
					$data = explode('-', $_POST['cboDirDistrito']);
					if ($data[0] != 0) {
						$ubigeo = $_POST['text-ubigeo'];
						$ubigeo_dir_dep = $data[0];
						$ubigeo_dir_prov = $data[1];
						$ubigeo_dir_dist = $data[2];
					}

					if ($_POST['idzona_origen'] != '') {
						$idzona_origen = $_POST['idzona_origen'];
					}
					
					$objTarifario->insertarTarifario($_POST['km'],$_POST['importe'],'N',$ubigeo_dir_dist,$idzona_origen);
					echo "Tarifario registrado satisfactoriamente";
					

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos Tarifario no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_TARIFARIO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();
					$ubigeo_dir_dist=null;
					$data = explode('-', $_POST['cboDirDistrito']);
					if ($data[0] != 0) {
						$ubigeo = $_POST['text-ubigeo'];
						$ubigeo_dir_dep = $data[0];
						$ubigeo_dir_prov = $data[1];
						$ubigeo_dir_dist = $data[2];
					}
					
					$objTarifario->actualizarTarifario($_POST['txtIdTarifario'],$_POST['km'],$_POST['importe'],'N',$ubigeo_dir_dist,$idzona_origen);
					echo "Tarifario actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos Tarifario no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_TARIFARIO": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idtarifario[]'];
						foreach($ids as $k=>$v){
							$objTarifario->actualizarEstadoTarifario($v,$_POST['estado']);
						}
					}else{
					$objTarifario->actualizarEstadoTarifario($_POST['idtarifario'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos el Tarifario no ha sido removido, intentelo nuevamente";
				}
				break;

		case "CBO_ZONA": 
				try{
					$data=$objTarifario->consultarZona();
						echo "<option value='0' >Ninguna</option>";
					while($fila=$data->fetch(PDO::FETCH_NAMED)){
						echo "<option value='".$fila['idzona']."' >".$fila['descripcion']."</option>";
					}
				}catch(Exception $e){
					echo "*** Los sentimos, datos no pudieron ser obtenidos";
				}
		break;

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>