<?php 
require_once("../logica/clsPersona.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objPer=new clsPersona();
	switch ($accion){
		
		case "NUEVA_PERSONA_SIMPLE": 
				try{
					$per=$objPer->consultarPersonaDni($_POST['txtNroDocPersona']);
					if($per->rowCount()<=0){
					$objPer->insertarPersona($_POST['txtNombrePersonaNew'],"",$_POST['txtNroDocPersona'],"N","","","","","","","||||");
					$idpersona=$objPer->getUltimaPersona();
					echo "Datos registrados satisfactoriamente%%__".$idpersona."%%__".$_POST['txtNombrePersonaNew'];
					}else{
					//@liza - Inicio
					//$pre=$per->fetch(PDO::FETCH_NAMED);
					$per=$per->fetch(PDO::FETCH_NAMED);
					//@liza - Fin
					echo "Registro de persona ya existe, seran tomados los datos.%%__".$per['idpersona']."%%__".$per['apellidos'].' '.$per['nombres'];	
					}
				}catch(Exception $e){
					echo "***Lo sentimos persona no ha podido ser registrada, intentelo nuevamente";
				}
				break;
		
		default: 
				echo "***Debe especificar alguna accion"; 
				break;
	}
	
}

?>