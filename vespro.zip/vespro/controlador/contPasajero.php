<?php 
require_once("../logica/clsPasajero.php");
require_once("../logica/clsPersona.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objPasajero=new clsPasajero();
    $objPersona = new clsPersona();

	switch ($accion){
		
		case "NUEVO_PASAJERO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$existe=$objPersona->consultarPersonaDni($_POST['nro_documento']);
					if($existe->rowCount()<1){
						$direccion = null; $email = null; $ubigeo = null; $ubigeo = null; $ubigeo_dir_dep = null; 
						$ubigeo_dir_prov = null; $ubigeo_dir_dist = null; $fnacimiento = null; $fregistro = null;
						$imei = null;
						$data = explode('-', $_POST['cboDirDistrito']);
						if ($_POST['direccion'] !== '') {
							$direccion = $_POST['direccion'];
						}
						if ($_POST['email'] !== '') {
							$email = $_POST['email'];
						}
						if ($_POST['imei'] !== '') {
							$imei = $_POST['imei'];
						}
						
						if ($data[0] != 0) {
							$ubigeo = $_POST['text-ubigeo'];
							$ubigeo_dir_dep = $data[0];
							$ubigeo_dir_prov = $data[1];
							$ubigeo_dir_dist = $data[2];
						}

						if ($_POST['fnacimiento'] !== '') {
							$dat = explode('/', $_POST['fnacimiento']);
							$fnacimiento = $dat[2].'-'.$dat[1].'-'.$dat[0];
						}
						if ($_POST['fregistro'] !== '') {
							$dat = explode('/', $_POST['fregistro']);
							$fregistro = $dat[2].'-'.$dat[1].'-'.$dat[0];
						}
					$objPersona->insertarPersona($_POST['apellidos'],$_POST['nombres'],$_POST['nro_documento'], 'N',$email,$direccion, $ubigeo,$ubigeo_dir_dep,$ubigeo_dir_prov,$ubigeo_dir_dist,$_POST['telefono'], $fnacimiento,$_POST['sexo'],$iemi);
					$newperson=$objPersona->consultarPersonaDni($_POST['nro_documento']);
					$persona=$newperson->fetch(PDO::FETCH_NAMED);
					$objPasajero->insertarPasajero($persona['idpersona'],'N',$fregistro);
						echo "Pasajero registrado satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Pasajero NO registrado *****<br/>";
							$rst.= "<br/> -> Dni ya existe registrado ";
						
						echo $rst;
					}

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos pasajero no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_PASAJERO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$direccion = null; $email = null; $ubigeo = null; $ubigeo = null; $ubigeo_dir_dep = null; 
					$ubigeo_dir_prov = null; $ubigeo_dir_dist = null; $fnacimiento = null; $fregistro = null;
					$imei = null;
					$data = explode('-', $_POST['cboDirDistrito']);
					if ($_POST['direccion'] !== '') {
						$direccion = $_POST['direccion'];
					}
					if ($_POST['email'] !== '') {
						$email = $_POST['email'];
					}
					if ($_POST['imei'] !== '') {
							$imei = $_POST['imei'];
						}
					
					if ($data[0] != 0) {
						$ubigeo = $_POST['text-ubigeo'];
						$ubigeo_dir_dep = $data[0];
						$ubigeo_dir_prov = $data[1];
						$ubigeo_dir_dist = $data[2];
					}

					if ($_POST['fnacimiento'] !== '') {
						$dat = explode('/', $_POST['fnacimiento']);
						$fnacimiento = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['fregistro'] !== '') {
						$dat = explode('/', $_POST['fregistro']);
						$fregistro = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
				$objPersona->actualizarPersona($_POST['txtIdPersona'],$_POST['apellidos'],$_POST['nombres'],$_POST['nro_documento'], 'N',$email,$direccion, $ubigeo,$ubigeo_dir_dep,$ubigeo_dir_prov,$ubigeo_dir_dist,$_POST['telefono'], $fnacimiento,$_POST['sexo'],$imei);
				$objPasajero->actualizarPasajero($_POST['txtIdPasajero'],$_POST['txtIdPersona'],'N',$fregistro);
					echo "Pasajero actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos pasajero no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_PASAJERO": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idpasajero[]'];
						foreach($ids as $k=>$v){
							$objPasajero->actualizarEstadoPasajero($v,$_POST['estado']);
						}
					}else{
					$objPasajero->actualizarEstadoPasajero($_POST['idpasajero'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos el pasajero no ha sido removido, intentelo nuevamente";
				}
				break;
				
				
		case "GUARDAR_FOTO":
			try{
					$idpasajero=$_POST['idpasajero'];
                    $urlbase="../files/imagenes/pasajeros";

                    $query = $_SERVER['PHP_SELF'];
					$path = pathinfo( $query );

					$urlbase_link='http://'.$_SERVER['HTTP_HOST'].dirname($path['dirname'])."/files/imagenes/pasajeros/";

                    $name=uniqid('pasajero_').".JPG";
					$fullname=$urlbase."/".$name;

                    if (!file_exists($urlbase) && !is_dir($urlbase)){
                        mkdir($urlbase,0777);
                    }
					
					if(file_exists($fullname)){
						@unlink($fullname);
					}
														
                    if(isset($_POST['foto'])){
                        $str="data:image/jpeg;base64,"; 
                        $_POST['foto']=str_replace($str,"",$_POST['foto']);
                        file_put_contents($fullname, base64_decode($_POST['foto']));
                    }

                    $objPasajero->actualizarFotoPasajero($idpasajero, $urlbase_link.$name);
					echo "IMAGEN GUARDADA SATISFACTORIAMENTE";
			}catch(Exception $e){
				echo "*** No fue posible guardar, intentelo nuevamente. ".$e->getMessage();
			}
			break;
		
		case "DATOS_PASAJERO": 
				try{
					$newperson=$objPersona->consultarPersonaDni($_POST['nro_documento']);
					$persona=$newperson->fetch(PDO::FETCH_NAMED);
					$data = array();
					if (!is_null($persona['idpersona'])) {
						$data[0] = array(
                            'idpersona' => $persona['idpersona'],
                            /*'principio' => $principio,
                            'presentacion' => $nombrepresentacion,
                            'stock' => number_format($stock, 0, '.', ','),
                            'preciokayros' => $value->preciokayros,
                            'precioventa' => $value->precioventa,
                            'idproducto' => $value->id,*/
                            );
					}
					echo json_encode($data);
				}catch(Exception $e){
					echo "*** Lo sentimos el pasajero no ha sido removido, intentelo nuevamente";
				}
				break;	
        

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>