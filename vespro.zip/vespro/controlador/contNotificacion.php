<?php 
require_once("../logica/clsNotificacion.php");
require_once("../logica/clsCompartido.php");
require_once("../logica/clsCiclo.php");
controlador($_POST['accion']);

function controlador($accion){
	$objNot=new clsNotificacion();
    $objCiclo = new clsCiclo();
	switch ($accion){
		
		case "NUEVO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
					$cnx->beginTransaction();					
					if($_POST['cboTipoNotificacion']!='C'){
						$_POST['cboTipoEspecial']='0';
					}				
                    $idinstitucion=0;
                    $idsucursal=0;
                    if($_POST['cboCiclo']>0){
                        $ciclo = $objCiclo->consultarCicloById($_POST['cboCiclo'])->fetch(PDO::FETCH_NAMED);
                        $idinstitucion = $ciclo['idinstitucion'];
                        $idsucursal = $ciclo['idsucursal'];
                    }
					$objNot->insertarNotificacion($_POST['cboTipoNotificacion'], $_POST['cboTipoEspecial'], utf8_decode($_POST['contenido']), utf8_decode($_POST['txtUrlInterno']), utf8_decode($_POST['txtUrlExterno']), $_POST['idperfiles'], $_POST['cboCiclo'], $_POST['cboTurno'], $_POST['idaulas'], $_POST['cboGrupo'], $_POST['cboEscuela'], $_SESSION['idusuario'], $_POST['txtIconoHidden'], $_POST['txtColorIconoHidden'],$idinstitucion, $idsucursal);
					if($_POST['cboTipoNotificacion']=='E'){
						$idnotificacion=$objNot->getUltimoIdNotificacion();
						$data = explode(",",$_POST['idusuarios']);
						foreach($data as $v){
							$objNot->insertarDetalleNotificacion($idnotificacion,$v);
						}
					}
					$cnx->commit();	
					echo "Datos registrados satisfactoriamente";
				}catch(Exception $e){
					$cnx->rollBack();
					echo "***Lo sentimos datos no han podido ser registrados, intentelo nuevamente". $e->getMessage();
				}
				break;
				
		case "ACTUALIZAR": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
					$cnx->beginTransaction();	
					$idnotificacion=$_POST['txtIdNotificacion'];
					if($_POST['cboTipoNotificacion']!='C'){
						$_POST['cboTipoEspecial']='0';	
					}				
                    
                    $idinstitucion=0;
                    $idsucursal=0;
                    if($_POST['cboCiclo']>0){
                        $ciclo = $objCiclo->consultarCicloById($_POST['cboCiclo'])->fetch(PDO::FETCH_NAMED);
                        $idinstitucion = $ciclo['idinstitucion'];
                        $idsucursal = $ciclo['idsucursal'];
                    }
                    
					$objNot->actualizarNotificacion($idnotificacion, $_POST['cboTipoNotificacion'], $_POST['cboTipoEspecial'],utf8_decode($_POST['contenido']), utf8_decode($_POST['txtUrlInterno']), utf8_decode($_POST['txtUrlExterno']), $_POST['idperfiles'],$_POST['cboCiclo'],$_POST['cboTurno'],$_POST['idaulas'],$_POST['cboGrupo'],$_POST['cboEscuela'], $_SESSION['idusuario'],$_POST['txtIconoHidden'],$_POST['txtColorIconoHidden'],$idinstitucion, $idsucursal);
					
					$objNot->eliminarDetalleNotificacion($idnotificacion);					
					
					if($_POST['cboTipoNotificacion']=='E'){
						$data = explode(",",$_POST['idusuarios']);
						foreach($data as $v){
							$objNot->insertarDetalleNotificacion($idnotificacion,$v);
						}
					}
					$cnx->commit();				
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					$cnx->rollBack();
					echo "***Lo sentimos cambios no registrados, intentelo nuevamente. ".$e->getMessage();
				}
				break;
		
		case "CAMBIAR_ESTADO":
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
					$cnx->beginTransaction();
					$objNot->cambiarEstadoNotificacion($_POST['idnotificacion'],$_POST['estado']);
					$cnx->commit();					
					echo "Datos actualizados satisfactoriamente";					
				}catch(Exception $e){
					$cnx->rollBack();
					echo "***Los sentimos, datos no pudieron ser actualizados";
				}
				break;	
					
		case "PUBLICAR": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
					$cnx->beginTransaction();
					$idnotificacion=$_POST['idnotificacion'];
					$datos = $objNot->getNotificacionById($idnotificacion)->fetch(PDO::FETCH_NAMED);
					if($datos['tipo']=='C'){
						$objNot->eliminarDetalleNotificacion($idnotificacion);
						if($datos['tipoespecial']=='D'){
							$objNot->registrarNotificacionDeudores($idnotificacion,$datos['idciclo']);
						}
					}elseif($datos['tipo']=='S'){
						$objNot->eliminarDetalleNotificacion($idnotificacion);
						$objNot->registrarNotificacionSegmentado($idnotificacion,$datos['idperfil'],$datos['idciclo'],$datos['turno'],$datos['idaula'],$datos['idgrupo'],$datos['idescuela']);
					}elseif($datos['tipo']=='E'){
						$objNot->cambiarEstadoDetalleNotificacion($idnotificacion,'P');
					}
					$objNot->publicarNotificacion($idnotificacion,$_SESSION['idusuario']);
					$cnx->commit();		
					echo "Datos actualizados satisfactoriamente";								
				}catch(Exception $e){
					$cnx->rollBack();
					echo "***Los sentimos, datos no pudieron ser actualizados ".$e->getMessage();
				}
				break;
		
		case "NOTIFICACIONES": 
				try{
					$pp=$objNot->getNotificacionesPorEstado($_SESSION['idusuario'],'P','P',0);
					$cpp=$pp->rowCount();
					$pp=$objNot->getNotificacionesPorEstado($_SESSION['idusuario'],'P','',10);
					$cppTodo=$pp->rowCount();
					$resultado="<a href='#' class='dropdown-toggle' data-toggle='dropdown'><i class='fa fa-bell'></i>";
					if($cpp>0){
	                 	$resultado.="<span class='label bg-red'>".$cpp."</span>";
					}
						$resultado.="</a><ul class='dropdown-menu notificacion-border'>";
						$fechanotificacion="";
					if($cppTodo>0){
						if($cpp>0){	
							if($cpp==1){
								$resultado.="<li class='header'><b>Tienes ".$cpp." notificación sin leer</b></li>";
							}else{
								$resultado.="<li class='header'><b>Tienes ".$cpp." notificaciones sin leer</b></li>";
							}
						}else{
							$resultado.="<li class='header'>No tienes nuevas notificaciones</li>";	
						}
						$resultado.="<li><ul class='menu'>";
						while($fila=$pp->fetch(PDO::FETCH_NAMED)){			
							$class='';
							$update='';
							if($fila['estado']=='P'){
								$class='notificacion-sin-leer';
								$update='SetLeidoNotificacion("'.$fila['iddn'].'");';
							}
							if($fila['icon']==''){
								$fila['icon']='fa-info-circle';	
							}
							$contenido=str_replace('"','\"',utf8_encode($fila['contenido']));
							$alert='alert("'.$contenido.'","'.$fila['icon'].'","Notificación","divMensajeMediano");';			
							$setrun='';
							if($fila['urlself']!=''){
								$setrun='setRun("'.$fila['urlself'].'","","divForm","divForm");';
							}
							$openlink='';
							if($fila['urlblank']!=''){
								$openlink='window.open("'.$fila['urlblank'].'","_blank");';
							}					
							
							$fechanotificacion=GetTiempoNotificacion($fila['horaminuto'],$fila['haceminutos'],$fila['hacehoras'],$fila['hacedias'],$fila['dianumero'],$fila['mescorto']);
							$contenidox=strtolower(strip_tags(utf8_encode($fila['contenido'])));
							$contenidox=strtoupper(substr($contenidox,0,1)).substr($contenidox,1);
							$resultado.="<li class='".$class."' onClick='".$alert.$setrun.$openlink.$update."' ><a href='javascript:void(0)'>
									  <i style='font-size:35px; float:left; padding-top:2px' class='fa ".$fila['icon']." text-".$fila['icon_color']."'></i>
									  <div style='padding-top:0px; padding-bottom:0px; padding-left:25px'>".$contenidox."</div>
									  <div style='margin-top:-2px; padding-top:0px; padding-bottom:0px; padding-left:25px' class='text-gray'><small><i class='fa fa-clock-o'></i> ".$fechanotificacion."</small></div>
									  </a></li>";
						}
						$resultado.="</ul></li>";					
					}else{		
						$resultado.="<li class='header'>No tienes notificaciones</li>";	
						
					}
					$resultado.="<li class='footer'><a href='javascript:void(0)' onClick=\"setRun('presentacion/listaNotificacionUsuario','','divForm','divForm')\">Ver todas las notificaciones</a></li></ul>";
					echo $cpp."##||##".$resultado;
				}catch(Exception $e){
					echo "***Los sentimos, datos no pudieron ser obtenidos";
				}
				break;
		
		case "MENSAJE_LEIDO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
					$cnx->beginTransaction();
					$objNot->declararLecturaNotificacion($_POST['iddn']);					
					$cnx->commit();					
					echo "Datos actualizados satisfactoriamente";					
				}catch(Exception $e){
					$cnx->rollBack();
					echo "*** Los sentimos, datos no pudieron ser actualizados";
				}
				break;
		
		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}

?>