<?php 
require_once("../logica/clsUsuario.php");
require_once("../logica/clsAcceso.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objUsu=new clsUsuario();
    $objAcc = new clsAcceso();

	switch ($accion){
		
		case "NUEVO_USUARIO": 
				try{
					$existe=$objUsu->verificarUsuario($_POST['txtIdPersona'], $_POST['cboRegistroPerfil'],$_POST['txtRegistroLogin']);
					if($existe->rowCount()<1){
					$objUsu->registrarUsuario($_POST['txtRegistroLogin'],$_POST['txtPrimerPassword'],$_POST['cboRegistroEstado'], $_POST['txtIdPersona'],$_POST['cboRegistroPerfil']);
						echo "Cuenta registrada satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Cuenta de usuario NO registrada *****<br/>";
						if($existe['idpersona']==$_POST['txtIdPersona'] && $existe['idperfil']==$_POST['cboRegistroPerfil']){
							$rst.= "<br/> -> Cuenta con persona y rol ingresados ya existe ";
						}
						if(strtolower($existe['login'])==strtolower($_POST['txtRegistroLogin'])){
							$rst.= "<br/> -> Login ingresado ya existe";
						}
						
						echo $rst;
					}
				}catch(Exception $e){
					echo "Lo sentimos cuenta no ha podido ser registrada, intentelo nuevamente";
				}
				break;
				
		case "ACTUALIZAR_USUARIO": 
				try{
					$existe=$objUsu->verificarUsuarioActualizacion($_POST['txtIdPersona'],$_POST['cboRegistroPerfil'],$_POST['txtRegistroLogin'],$_POST['txtIdUsuario']);
					if($existe->rowCount()<1){
						
					$objUsu->actualizarUsuario($_POST['txtIdUsuario'],$_POST['txtIdPersona'],$_POST['cboRegistroPerfil'],$_POST['cboRegistroEstado'],$_POST['txtRegistroLogin'],$_POST['txtPrimerPassword']);
					echo "Cuenta actualizada satisfactoriamente";
						
					}else{
						$existe=$existe->fetch();	
							$rst="***** Cuenta de usuario NO registrada *****<br/>";
						if($existe['idpersona']==$_POST['txtIdPersona'] && $existe['idperfil']==$_POST['cboRegistroPerfil']){
							$rst.= "<br/> -> Cuenta con persona y rol ingresados ya existe ";
						}
						if(strtolower($existe['login'])==strtolower($_POST['txtRegistroLogin'])){
							$rst.= "<br/> -> Login ingresado ya existe";
						}
						
						echo $rst;
					}
				}catch(Exception $e){
					echo "Lo sentimos cuenta no ha podido ser actualizada, intentelo nuevamente";
				}
				break;
				
				
		case "ACTUALIZAR_CLAVE": 
				try{
					$existe=$objUsu->verificarUsuarioClave($_POST['txtIdUsuario'], $_POST['txtIdPersona'], $_POST['txtOldPassword']);
					if($existe->rowCount()==1){

						$objUsu->actualizarClaveUsuario($_POST['txtIdUsuario'], $_POST['txtIdPersona'], $_POST['txtPrimerPassword']);
						echo "Cuenta actualizada satisfactoriamente";
						
					}else{
					echo "Clave ingresada es incorrecta.";	
					}
				}catch(Exception $e){
					echo "Lo sentimos cuenta no ha podido ser actualizada, intentelo nuevamente";
				}
				break;
		
		case "NUEVO_PERFIL": 
				try{
					$existe=$objUsu->verificarPerfil($_POST['txtDescripcion']);
					if($existe->rowCount()<1){
					$objUsu->registrarPerfil($_POST['txtDescripcion'],$_POST['cboEstado']); 
						echo "Perfil registrado satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Perfil NO registrado *****<br/>";
						if(strtolower($existe['descripcion'])==strtolower($_POST['txtDescripcion'])){
							$rst.= "<br/> -> Ya existe un perfil con la misma descripcion ";
						}
						
						echo $rst;
					}
				}catch(Exception $e){
					echo "Lo sentimos perfil no ha podido ser registrado, intentelo nuevamente";
				}
				break;
				
		case "ACTUALIZAR_PERFIL": 
				try{
					$existe=$objUsu->verificarPerfil($_POST['txtDescripcion'],$_POST['txtIdPerfil']);
					if($existe->rowCount()<1){
					$objUsu->actualizarPerfil($_POST['txtIdPerfil'],$_POST['txtDescripcion'],$_POST['cboEstado']); 
						echo "Cuenta registrada satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Perfil NO registrado *****<br/>";
						if(strtolower($existe['descripcion'])==strtolower($_POST['txtDescripcion'])){
							$rst.= "<br/> -> Ya existe un perfil con la misma descripcion ";
						}
						
						echo $rst;
					}
				}catch(Exception $e){
					echo "Lo sentimos perfil no ha podido ser registrado, intentelo nuevamente";
				}
				break;
		
		case "NUEVO_OPCION": 
				try{
					$existe=$objUsu->verificarOpcion($_POST['txtDescripcion']);
					if($existe->rowCount()<1){
					if($_POST['id_opcionref']='0'){$_POST['id_opcionref']=NULL;}
					$objUsu->registrarOpcionMenu($_POST['txtDescripcion'],$_POST['txtLink'],$_POST['cboEstado'], $_POST['id_opcionref'],$_POST['txtOrden'],$_POST['txtTitle']); 
						echo "Opcion registrado satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Opcion NO registrado *****<br/>";
						if(strtolower($existe['descripcion'])==strtolower($_POST['txtDescripcion'])){
							$rst.= "<br/> -> Ya existe una opcion con la misma descripcion ";
						}
						
						echo $rst;
					}
				}catch(Exception $e){
					echo "Lo sentimos opcion no ha podido ser registrado, intentelo nuevamente";
				}
				break;
				
		case "ACTUALIZAR_OPCION": 
				try{
					$existe=$objUsu->verificarOpcion($_POST['txtDescripcion'],$_POST['txtIdOpcion']);
					if($existe->rowCount()<1){
					if($_POST['id_opcionref']='0'){$_POST['id_opcionref']=NULL;}
					$objUsu->actualizarOpcionMenu($_POST['idopcion'],$_POST['txtDescripcion'],$_POST['txtLink'],$_POST['cboEstado'], $_POST['id_opcionref'],$_POST['txtOrden'],$_POST['txtTitle']); 
						echo "Opcion registrado satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Opcion NO registrado *****<br/>";
						if(strtolower($existe['descripcion'])==strtolower($_POST['txtDescripcion'])){
							$rst.= "<br/> -> Ya existe una opcion con la misma descripcion ";
						}
						
						echo $rst;
					}
				}catch(Exception $e){
					echo "Lo sentimos opcion no ha podido ser registrado, intentelo nuevamente";
				}
				break;
		
		
		case "CAMBIAR_ESTADO_USUARIO": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['iduser[]'];
						foreach($ids as $k=>$v){
							$objUsu->actualizarEstadoUsuario($v,$_POST['estado']);
						}
					}else{
					$objUsu->actualizarEstadoUsuario($_POST['iduser'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos cuenta de usuario no ha sido anulada, intentelo nuevamente";
				}
				break;
				
		case "CAMBIAR_ESTADO_ACCESO": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idopcion[]'];
						foreach($ids as $k=>$v){
							//$objUsu->actualizarEstadoUsuario($v,$_POST['estado']);
						}
					}else{
						if($_POST['estado']=='N'){
							$objUsu->registrarAcceso($_POST['idperfil'],$_POST['idopcion'],'N'); 
						}else{
							$objUsu->quitarAcceso($_POST['idopcion']); 
							// en este caso se lanzara el idacceso en la variable idopcion
						}
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "***Lo sentimos cuenta de usuario no ha sido anulada, intentelo nuevamente";
				}
				break;
		
		case "CAMBIAR_ESTADO_PERFIL": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idperfil[]'];
						foreach($ids as $k=>$v){
							$objUsu->cambiarEstadoPerfil($v,$_POST['estado']);
						}
					}else{
					$objUsu->cambiarEstadoPerfil($_POST['idperfil'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos cuenta de usuario no ha sido anulada, intentelo nuevamente";
				}
				break;
				
		case "CAMBIAR_ESTADO_OPCION": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idopcion[]'];
						foreach($ids as $k=>$v){
							$objUsu->cambiarEstadoOpcionMenu($v,$_POST['estado']);
						}
					}else{
					$objUsu->cambiarEstadoOpcionMenu($_POST['idopcion'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos cuenta de usuario no ha sido anulada, intentelo nuevamente";
				}
				break;

		case "CBO_PERFIL": 
				try{
					$data=$objUsu->consultarPerfil('','N',0,1000);
					echo "<option value='0'>- Todos -</option>";
					while($fila=$data->fetch(PDO::FETCH_NAMED)){
						echo "<option value='".$fila['idperfil']."' >".$fila['descripcion']."</option>";
					}
				}catch(Exception $e){
					echo "*** Los sentimos, datos no pudieron ser obtenidos";
				}
				break;

		case "CBO_PERFIL_2": 
				try{
					$data=$objUsu->consultarPerfil('','N',0,1000);
					while($fila=$data->fetch(PDO::FETCH_NAMED)){
						echo "<option value='".$fila['idperfil']."' >".$fila['descripcion']."</option>";
					}
				}catch(Exception $e){
					echo "*** Los sentimos, datos no pudieron ser obtenidos";
				}
				break;
				
		case "CBO_USUARIO_ALL": 
				try{
					$data=$objUsu->consultarUsuario("","0","N",0,1000000);
					while($fila=$data->fetch(PDO::FETCH_NAMED)){
						echo "<option value='".$fila['idusuario']."' >".$fila['persona'].' / '.$fila['perfil']."</option>";
					}
				}catch(Exception $e){
					echo "*** Los sentimos, datos no pudieron ser obtenidos";
				}
				break;
				
		case "CBO_PERFIL2": 
				try{
					$data=$objUsu->consultarPerfil('','N',0,1000);
					echo "<option value='0'>- Seleccione uno -</option>";
					while($fila=$data->fetch(PDO::FETCH_NAMED)){
						echo "<option value='".$fila['idperfil']."' >".$fila['descripcion']."</option>";
					}
				}catch(Exception $e){
					echo "*** Los sentimos, datos no pudieron ser obtenidos";
				}
		break;
		
		case "IN": 
				$rst=$objUsu->consultarAcceso($_POST['txtLogin'],$_POST['txtPassword']);
				if($rst->rowCount()>0){
					$user=$rst->fetch();					                    
					
					$_SESSION['idusuario']=$user['idusuario'];
					$_SESSION['idpersona']=$user['idpersona'];
					$_SESSION['idperfil']=$user['idperfil'];
					$_SESSION['persona']=$user['persona'];
					$_SESSION['login']=$user['login'];
                    $_SESSION['nrodoc']=$user['nro_documento'];

					echo 'admin.php';
				}else{
					//Mejora de seguridad
					//echo "<META HTTP-EQUIV=Refresh CONTENT='0;URL= ../index.php?error=1'>";
					echo '*** Usuario o contraseña no válido ***';
				}
				break;
		
		case "OUT": 
		
				echo "<META HTTP-EQUIV=Refresh CONTENT='0;URL= ../index.php'>";	
					$_SESSION['idusuario']=NULL;
					$_SESSION['idpersona']=NULL;
					$_SESSION['idperfil']=NULL;
					$_SESSION['persona']=NULL;
					$_SESSION['login']=NULL;
				session_unset();
				session_destroy();	
				
				
				break;

        case "OBTENER_CLAVE":
                $busqueda=$_POST['busqueda'];

                $dni=$busqueda;
                $idmatricula=$busqueda;

                $usuario= $objUsu->ObtenerDatosUsuarioBuscado($dni,$idmatricula);
                if($usuario->rowCount()>0){
                    $usuario=$usuario->fetch(PDO::FETCH_NAMED);
                    $texto="<table class='table table-bordered'><tr>";
                    $texto.="<th>Interesado</th><td>".$usuario['apellidos']." ".$usuario['nombres']."</td>";
                    $texto.="</tr><tr>";
                    $texto.="<th>Usuario</th><td>".$usuario['login']."</td>";
                    $texto.="</tr><tr>";
                    $texto.="<th>Contraseña</th><td>".$usuario['clave']."</td>";
                    $texto.="</tr></table>";
                    echo $texto;
                }else{
                    echo "<div class='box-body' align='center'><span class='text-red'><li class='fa fa-warning'></li> Cuenta de alumno/apoderado no localizado.</span></div>";
                }
             break;

        case "GET_USUARIO_LOGIN":
        		$user = $objUsu->getUsuarioByLogin($_POST['login']);
        		if($user->rowCount()>0){
        			$user = $user->fetch(PDO::FETCH_ASSOC);
        		}else{
        			$user = array();
        		}
        		echo json_encode($user);
        	break;


        	case "GUARDAR_FOTO":
			try{
					$idusuario=$_POST['idusuario'];
                    $urlbase="../files/imagenes/usuarios";

                    $query = $_SERVER['PHP_SELF'];
					$path = pathinfo( $query );

					$urlbase_link='http://'.$_SERVER['HTTP_HOST'].dirname($path['dirname'])."/files/imagenes/usuarios/";

                    $name=uniqid('usuario_').".JPG";
					$fullname=$urlbase."/".$name;

                    if (!file_exists($urlbase) && !is_dir($urlbase)){
                        mkdir($urlbase,0777);
                    }
					
					if(file_exists($fullname)){
						@unlink($fullname);
					}
														
                    if(isset($_POST['foto'])){
                        $str="data:image/jpeg;base64,"; 
                        $_POST['foto']=str_replace($str,"",$_POST['foto']);
                        file_put_contents($fullname, base64_decode($_POST['foto']));
                    }

                    $objUsu->actualizarFotoUsuario($idusuario, $urlbase_link.$name);
					echo "IMAGEN GUARDADA SATISFACTORIAMENTE";
			}catch(Exception $e){
				echo "*** No fue posible guardar, intentelo nuevamente. ".$e->getMessage();
			}
			break;

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>