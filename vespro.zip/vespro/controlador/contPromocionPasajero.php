<?php 
require_once("../logica/clsPromocionPasajero.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objPromocionPasajero=new clsPromocionPasajero();

	switch ($accion){
		
		case "NUEVO_PROMOCIONPASAJERO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();
					$fechauso = null; $fechahora = null; $vigencia = null;
					
					if ($_POST['fechahora'] !== '') {
						$dat = explode('/', $_POST['fechahora']);
						$fechahora = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['vigencia'] !== '') {
						$dat = explode('/', $_POST['vigencia']);
						$vigencia = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}

					$objPromocionPasajero->insertarPromocionPasajero($_POST['codigo'],$fechahora,$_POST['mensaje'],'N',$fechauso,$vigencia,$_POST['idpasajero']);

					echo "Promocion de Pasajero registrada satisfactoriamente";
					

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos Promocion de Pasajero no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_PROMOCIONPASAJERO": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$fechauso = null; $fechahora = null; $vigencia = null;
					
					if ($_POST['fechahora'] !== '') {
						$dat = explode('/', $_POST['fechahora']);
						$fechahora = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['vigencia'] !== '') {
						$dat = explode('/', $_POST['vigencia']);
						$vigencia = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					
					$objPromocionPasajero->actualizarPromocionPasajero($_POST['txtIdPromocion'],$_POST['codigo'],$fechahora,$_POST['mensaje'],'N',$fechauso,$vigencia,$_POST['idpasajero']);
					echo "Promocion de Pasajero actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos Promocion de Pasajero no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_PROMOCIONPASAJERO": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idpromocion[]'];
						foreach($ids as $k=>$v){
							$objPromocionPasajero->actualizarEstadoPromocionPasajero($v,$_POST['estado']);
						}
					}else{
					$objPromocionPasajero->actualizarEstadoPromocionPasajero($_POST['idpromocion'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos la Promocion de Pasajero no ha sido removido, intentelo nuevamente";
				}
				break;


		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>