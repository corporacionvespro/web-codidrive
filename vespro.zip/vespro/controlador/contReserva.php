<?php 
require_once("../logica/clsReserva.php");
require_once("../logica/clsPersona.php");
require_once("../logica/clsVehiculo.php");
require_once("../logica/clsPasajero.php");
require_once("../logica/clsConductor.php");
controlador($_POST['accion']);

function controlador($accion){
	$ObjReserva=new clsReserva();
	$objPersona=new clsPersona();
	$objVehiculo=new clsVehiculo();
	$objPasajero=new clsPasajero();
	$objConductor=new clsConductor();

	switch ($accion){
		
		case "NUEVA_RESERVA":
    		try{
    			//Persona y pasajero
    			$persona = $objPersona->consultarPersonaDni($_POST['txtDNI']);
    			if($persona->rowCount()<1){
    				$objPersona->RegistrarPersona($_POST['txtApellidos'],$_POST['txtNombre'],$_POST['txtDNI']);
                    $persona = $objPersona->consultarPersonaDni($_POST['txtDNI']);
    			}
	    		
                $idpersona= $objPersona->UltimoPersonaRegistrada();

                $pasajero = $objPasajero->ConsultarPasajeroByPersona($idpersona);
                if($pasajero->rowCount()<1){
                    $pasajero = $objPasajero->RegistrarPasajero($idpersona);
                    $pasajero = $objPasajero->ConsultarPasajeroByPersona($idpersona);
                }
                $idpasajero = $objPasajero->UltimoPasajeroRegistrado();

                $objConductor->actualizarEstadoConductorApp($_POST['txtIdConductor'],'O');
                $ObjReserva->EnviarTaxi($_POST['txtTarifa'],$idpasajero,$_POST['txtIdConductor'],$_POST['txtReferencia'], $_POST['txtCantidadPasajeros'], $_POST['txtIDVehiculo'], $_POST['txtOrigen'], $_POST['txtDestino']);
				echo "Reserva de taxi registrada satisfactoriamente";
			}catch(Exception $e){
				echo "Lo sentimos la reserva no ha podido ser registrado, intentelo nuevamente";
			}
		break;

        case "GET_VEHICULO":
    		$vehiculo = $ObjReserva->getDatosVehiculoConductor($_POST['idvehiculo']);
    		if($vehiculo->rowCount()>0){
    			$vehiculo = $vehiculo->fetch(PDO::FETCH_ASSOC);
            }else{
                $vehiculo = array();
                // $vehiculo=$vehiculo->fetch();    
                // $rst="***** Vehiculo no es el actual *****<br/>";
                // $rst.= "<br/> -> El vehiculo no esta disponible ";
                // echo $rst;

    		}
    		echo json_encode($vehiculo);
		break;

		case "GET_DNI":
    		$user = $ObjReserva->getPasajeroByDNI($_POST['nro_documento']);
    		if($user->rowCount()>0){
    			$user = $user->fetch(PDO::FETCH_ASSOC);
    		}else{
    			$user = array();
    		}
    		echo json_encode($user);
		break;

        case "CAMBIAR_ESTADO_RESERVA":
            try{                                            
                $ObjReserva->cambiarEstadoReserva($_POST['idsolicitud'],$_POST['estado']); 
                    echo "Reserva eliminada satisfactoriamente";
            }catch(Exception $e){
                echo "Lo sentimos cuenta de usuario no ha sido anulada, intentelo nuevamente";
            }
        break;

		default: 
			echo "Debe especificar alguna accion"; 
		break;
	
	}
}
?>