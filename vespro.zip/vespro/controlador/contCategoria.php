<?php 
require_once("../logica/clsCategoria.php");
controlador($_POST['accion']);

function controlador($accion){
	
	$ObjsCategoria=new clsCategoria();

	switch ($accion){
		
		case "NUEVA_CATEGORIA": 
				try{
						$ObjsCategoria->RegistrarCategoria($_POST['txtNombre'],$_POST['txtFoto']);
						echo "Categoria registrada satisfactoriamente";
				}catch(Exception $e){
					echo "Lo sentimos la categoria no ha podido ser registrado, intentelo nuevamente";
				}
				break;	

		case "ACTUALIZAR_CATEGORIA": 
				try{
					$ObjsCategoria->EditarCategoria($_POST['txtIdCategoria'],$_POST['txtNombre'],$_POST['txtFoto']);
						echo "Categoria editada satisfactoriamente";
				}catch(Exception $e){
					echo "Lo sentimos la categoria no ha podido ser actualizada, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_CATEGORIA": 
				try{
					$ObjsCategoria->cambiarEstadoCategoria($_POST['idCategoria'],$_POST['estado']);
						echo "Categoria eliminada satisfactoriamente";
				}catch(Exception $e){
					echo "Lo sentimos la categoria no ha podido ser eliminada, intentelo nuevamente";
				}
				break;

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}
?>