<?php 
require_once("../logica/clsConductor.php");
require_once("../logica/clsPersona.php");
controlador($_POST['accion']);

function controlador($accion){
	//session_start();
	$objConductor=new clsConductor();
    $objPersona = new clsPersona();

	switch ($accion){
		
		case "NUEVO_CONDUCTOR": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$existe=$objPersona->consultarPersonaDni($_POST['nro_documento']);
					if($existe->rowCount()<1){
						$direccion = null; $email = null; $ubigeo = null; $ubigeo = null; $ubigeo_dir_dep = null; 
						$ubigeo_dir_prov = null; $ubigeo_dir_dist = null; $fnacimiento = null; $finscripcion = null;
						$imei = null;
						$data = explode('-', $_POST['cboDirDistrito']);
						if ($_POST['direccion'] !== '') {
							$direccion = $_POST['direccion'];
						}
						if ($_POST['email'] !== '') {
							$email = $_POST['email'];
						}
						
						if ($data[0] != 0) {
							$ubigeo = $_POST['text-ubigeo'];
							$ubigeo_dir_dep = $data[0];
							$ubigeo_dir_prov = $data[1];
							$ubigeo_dir_dist = $data[2];
						}

						if ($_POST['fnacimiento'] !== '') {
							$dat = explode('/', $_POST['fnacimiento']);
							$fnacimiento = $dat[2].'-'.$dat[1].'-'.$dat[0];
						}
						if ($_POST['finscripcion'] !== '') {
							$dat = explode('/', $_POST['finscripcion']);
							$finscripcion = $dat[2].'-'.$dat[1].'-'.$dat[0];
						}

						$apellidos = $_POST['appaterno'].' '.$_POST['apmaterno'];
					$objPersona->insertarPersona($apellidos,$_POST['nombres'],$_POST['nro_documento'], 'N',$email,$direccion, $ubigeo,$ubigeo_dir_dep,$ubigeo_dir_prov,$ubigeo_dir_dist,$_POST['telefono'], $fnacimiento,$_POST['sexo'],$imei);
					$newperson=$objPersona->consultarPersonaDni($_POST['nro_documento']);
					$persona=$newperson->fetch(PDO::FETCH_NAMED);
					$objConductor->insertarConductor($persona['idpersona'],'N',$finscripcion,$_POST['appaterno'],$_POST['apmaterno'],$_POST['nombres']);

					//CONECTARLO CON CONDUCTOR TEMPORAL
					if($_POST['txtIdSolicitud']>0){
						$idconductor = $objConductor->getUltimoConductor();
						$objConductor->actualizarIdContuctorTMP($_POST['txtIdSolicitud'], $idconductor);
					}

						echo "Conductor registrado satisfactoriamente";
					}else{
						$existe=$existe->fetch();	
							$rst="***** Conductor NO registrado *****<br/>";
							$rst.= "<br/> -> Dni ya existe registrado ";
						
						echo $rst;
					}

					$cnx->commit();		
				}catch(Exception $e){
					$cnx->rollBack();	
					echo "Lo sentimos conductor no ha podido ser registrado, intentelo nuevamente ".$e;
				}
				break;
				
		case "ACTUALIZAR_CONDUCTOR": 
				try{
					global $cnx;
					$cnx->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
					$cnx->beginTransaction();

					$direccion = null; $email = null; $ubigeo = null; $ubigeo = null; $ubigeo_dir_dep = null; 
					$ubigeo_dir_prov = null; $ubigeo_dir_dist = null; $fnacimiento = null; $finscripcion = null;
					$imei = null;
					$data = explode('-', $_POST['cboDirDistrito']);
					if ($_POST['direccion'] !== '') {
						$direccion = $_POST['direccion'];
					}
					if ($_POST['email'] !== '') {
						$email = $_POST['email'];
					}
					
					if ($data[0] != 0) {
						$ubigeo = $_POST['text-ubigeo'];
						$ubigeo_dir_dep = $data[0];
						$ubigeo_dir_prov = $data[1];
						$ubigeo_dir_dist = $data[2];
					}

					if ($_POST['fnacimiento'] !== '') {
						$dat = explode('/', $_POST['fnacimiento']);
						$fnacimiento = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					if ($_POST['finscripcion'] !== '') {
						$dat = explode('/', $_POST['finscripcion']);
						$finscripcion = $dat[2].'-'.$dat[1].'-'.$dat[0];
					}
					$apellidos = $_POST['appaterno'].' '.$_POST['apmaterno'];
				$objPersona->actualizarPersona($_POST['txtIdPersona'],$apellidos,$_POST['nombres'],$_POST['nro_documento'], 'N',$email,$direccion, $ubigeo,$ubigeo_dir_dep,$ubigeo_dir_prov,$ubigeo_dir_dist,$_POST['telefono'], $fnacimiento,$_POST['sexo'],$imei);
				$objConductor->actualizarConductor($_POST['txtIdConductor'],$_POST['txtIdPersona'],'N',$finscripcion,$_POST['appaterno'],$_POST['apmaterno'],$_POST['nombres']);
					echo "Conductor actualizado satisfactoriamente";

						$cnx->commit();	
				}catch(Exception $e){
					$cnx->rollBack();
					echo "Lo sentimos conductor no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_CONDUCTOR": 
				try{
					if($_POST['bloque']=='S'){
						$ids=$_POST['idconductor[]'];
						foreach($ids as $k=>$v){
							$objConductor->actualizarEstadoConductor($v,$_POST['estado']);
						}
					}else{
					$objConductor->actualizarEstadoConductor($_POST['idconductor'],$_POST['estado']); 
					}
					echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "*** Lo sentimos el conductor no ha sido removido, intentelo nuevamente";
				}
				break;
				
		case "CBO_EMPRESA": 
				try{
					$data=$objConductor->consultarEmpresa();
					while($fila=$data->fetch(PDO::FETCH_NAMED)){
						echo "<option value='".$fila['idempresa']."' >".$fila['nombre']."</option>";
					}
				}catch(Exception $e){
					echo "*** Los sentimos, datos no pudieron ser obtenidos";
				}
		break;

		case "GUARDAR_FOTO":
			try{
					$idconductor=$_POST['idconductor'];
                    $urlbase="../files/imagenes/conductores";

                    $query = $_SERVER['PHP_SELF'];
					$path = pathinfo( $query );

					$urlbase_link='http://'.$_SERVER['HTTP_HOST'].dirname($path['dirname'])."/files/imagenes/conductores/";

                    $name=uniqid('conductor_').".JPG";
					$fullname=$urlbase."/".$name;

                    if (!file_exists($urlbase) && !is_dir($urlbase)){
                        mkdir($urlbase,0777);
                    }
					
					if(file_exists($fullname)){
						@unlink($fullname);
					}
														
                    if(isset($_POST['foto'])){
                        $str="data:image/jpeg;base64,"; 
                        $_POST['foto']=str_replace($str,"",$_POST['foto']);
                        file_put_contents($fullname, base64_decode($_POST['foto']));
                    }

                    $objConductor->actualizarFotoConductor($idconductor, $urlbase_link.$name);
					echo "IMAGEN GUARDADA SATISFACTORIAMENTE";
			}catch(Exception $e){
				echo "*** No fue posible guardar, intentelo nuevamente. ".$e->getMessage();
			}
			break;
		

        

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}


?>