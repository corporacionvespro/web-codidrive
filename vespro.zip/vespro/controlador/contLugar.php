<?php 
require_once("../logica/clsLugar.php");
controlador($_POST['accion']);

function controlador($accion){
	
	$objLugar=new clsLugar();

	switch ($accion){
		
		case "NUEVO_LUGAR": 
				try{
						$objLugar->RegistrarLugar($_POST['txtNombreLugar'],$_POST['txtDescripcion'],$_POST['txtLatitud'],$_POST['txtLongitud'],$_POST['optCategoria'],$_POST['txtFoto'],$_POST['txtDireccion']);
						echo "Lugar registrado satisfactoriamente";
				}catch(Exception $e){
					echo "Lo sentimos el lugar no ha podido ser registrado, intentelo nuevamente";
				}
				break;	

		case "ACTUALIZAR_LUGAR": 
				try{
					$objLugar->EditarLugar($_POST['txtidLugar'],$_POST['txtNombreLugar'],$_POST['txtDescripcion'],$_POST['txtLatitud'],$_POST['txtLongitud'],$_POST['optCategoria'],$_POST['txtFoto'],$_POST['txtDireccion']);
						echo "Lugar editado satisfactoriamente";
				}catch(Exception $e){
					echo "Lo sentimos el lugar no ha podido ser actualizado, intentelo nuevamente";
				}
				break;

		case "CAMBIAR_ESTADO_LUGAR": 
				try{											
					$objLugar->cambiarEstadoLugar($_POST['idlugar'],$_POST['estado']); 
						echo "Datos actualizados satisfactoriamente";
				}catch(Exception $e){
					echo "Lo sentimos cuenta de usuario no ha sido anulada, intentelo nuevamente";
				}
				break;

		// case "GUARDAR_PUNTOS":
		// 		try{			
		// 			global $cnx;
		// 			$cnx->beginTransaction();

		// 			$idlugar=$_POST['idlugar'];
		// 			$puntos=explode(";",$_POST['puntos']);
		// 			$objLugar->eliminarCoordenada($idlugar);
		// 			foreach($puntos as $k=>$v){
		// 				if($v!=''){
		// 					$punto = explode(",",$v);
		// 					$objLugar->insertarCoordenada($idlugar, $punto[0],$punto[1],$k);
		// 				}
		// 			}

		// 			$cnx->commit();
		// 			echo "Datos actualizados satisfactoriamente";
		// 		}catch(Exception $e){
		// 			$cnx->rollBack();
		// 			echo "Lo sentimos cambios no fueron efectuados, intentelo nuevamente";
		// 		}
		// 		break;		

		default: 
				echo "Debe especificar alguna accion"; 
				break;
	}
	
}
?>