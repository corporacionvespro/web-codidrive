<?php
 

class Firebase {
 
    public function send($to, $notification, $data, $sendConductor, $sendPasajero) {
        $fields = array(
            'to' => $to,
            'data' => $data,
        );
        if(isset($notification)){
            if($notification!=''){
                $fields['notification']=$notification;
            }
        }
        return $this->sendPushNotification($fields, $sendConductor, $sendPasajero);
    }
 
    public function sendToTopic($tema,$notification, $data, $sendConductor, $sendPasajero) {
        $fields = array(
            'to' => '/topics/' . $tema,
            'data' => $data,
        );
        if(isset($notification)){
            if($notification!=''){
                $fields['notification']=$notification;
            }
        }
        return $this->sendPushNotification($fields, $sendConductor, $sendPasajero);
    }
 
    public function sendMultiple($registration_ids,$notification, $data, $sendConductor, $sendPasajero) {
        $fields = array(
            'registration_ids' => $registration_ids,
            'data' => $data,
        );
         if(isset($notification)){
            if($notification!=''){
                $fields['notification']=$notification;
            }
        }
        return $this->sendPushNotification($fields, $sendConductor, $sendPasajero);
    }
 
    private function sendPushNotification($fields, $sendConductor, $sendPasajero) {
         
        require_once __DIR__ . '/config.php';
 
        $url = 'https://fcm.googleapis.com/fcm/send';
 
        $key = '';

        if($sendConductor){
            $key=FIREBASE_API_KEY_CONDUCTOR;
        }
        if($sendPasajero){
            $key=FIREBASE_API_KEY_PASAJERO;
        }

        $headers = array(
            'Authorization: key=' . $key,
            'Content-Type: application/json'
        );
        $ch = curl_init();
 
        curl_setopt($ch, CURLOPT_URL, $url);
 
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
 
        $result = curl_exec($ch);
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
 
        curl_close($ch);
 
        return $result;
    }
}
?>