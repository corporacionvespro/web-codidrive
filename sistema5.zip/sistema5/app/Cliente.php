<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    protected $table ='clientes';
    protected $fillable = ['nombre', 'dni', 'telefono', 'celular', 'direccion', 'unidad', 'empresa_id'];


    public function costo(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->hasMany('App\Costo_fijo');
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        // return $this->belongsTo('App\Roles');

    }

    public function ingreso(){
        // hasMany -> tiene muchos 
        // un cliente tiene muchos pagos
        return $this->hasMany('App\Ingreso');
    }
    public function egreso(){
        // hasMany -> tiene muchos 
        // un cliente tiene muchos pagos
        return $this->hasMany('App\egreso');
    }

}