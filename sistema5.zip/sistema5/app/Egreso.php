<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Egreso extends Model
{
    
    protected $table='egresos';
    protected $fillable = ['numdoc','fecha','total', 'tipo','descripcion','concepto_id','cliente_id','user_id','empresa_id'];
    
    public function user(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->belongsTo('App\User');
    }

    public function proveedor(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->belongsTo('App\Proveedor');
    }
}
