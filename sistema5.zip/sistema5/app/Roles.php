<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Roles extends Model
{
    protected $table='roles';
    protected $fillable = [
        'nombre'
    ];

    public function user(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->hasMany('App\User');
        // return $this->hasMany(User::class);
    }
}
