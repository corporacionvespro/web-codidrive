<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Otro_concepto extends Model
{
    
    protected $table='otro_conceptos';
    protected $fillable = [
        'nombre','costo', 'saldo','estado','cliente_id','user_id','empresa_id'
    ];
    
}
