<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class storeIngreso extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'numdoc'=>'required',
            'cliente'=>'required',
            'cliente2'=>'',
            'idcliente'=>'',
            'concepto'=>'',
            'descripcion2'=>'', 
            'total'=>'required | numeric',
            'tipo'=>'required',
            // 'cliente_id'=>'',
            // 'concepto_id'=>'',
        ];
    }

    public function messages()
    {
        return [
            'cliente2.required' => 'Por favor buscar otra vez la unidad',            
        ];
    }
}
