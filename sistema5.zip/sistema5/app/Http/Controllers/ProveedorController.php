<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Proveedor;

class ProveedorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('roles');

    }
    
    public function index()
    {
        $proveedores = new Proveedor();
        $proveedores = Proveedor::all();
        return view('proveedor.index',compact('proveedores'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('proveedor.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'nombre'=>'required|min:6',
        ]); 
        $proveedores = new Proveedor();
        $proveedores->nombre=strtoupper($request->get('nombre'));
        $proveedores->telefono=$request->get('telefono');
        $proveedores->empresa_id=2;
        $proveedores->save();

        return redirect()->route('proveedor.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $proveedor=Proveedor::where('id',$id)
        ->first();

        return view('proveedor.edit',compact('proveedor'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'nombre'=>'required|min:6',
        ]); 
        $proveedor = new Proveedor();

        $proveedor= Proveedor::where('id',$id)
                        ->first();

        $proveedor->nombre=strtoupper($request->get('nombre'));
        $proveedor->telefono=$request->get('telefono');
        $proveedor->save();

        return redirect()->route('proveedor.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    
    public function buscarproveedor(Request $request)
    {
        if($request->get('query')){
            $query = $request->get('query');
            $data = Proveedor::select('nombre','id')
                ->where('nombre', 'LIKE', "%{$query}%")
                ->get();

            $output = '';
            if ($data->count()>0) {
                $output = '<ul class="" 
                    style="    
                    display: block;
                    position: relative;
                ">';
                foreach($data as $row){
                    $output .= '
                    <li nombre="'.$row->nombre.'" id="'.$row->id.'"><a href="#">'.$row->nombre.'</a></li>                    
                    ';
                }
                $output .= '</ul>';
            }   
            echo $output;
        }
    }

}
