<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('roles');
    }
    
    public function index()
    {
        $users= new User();
        $users=User::all();
        // dd($users);

        return view('user.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('user.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user=new User();

        $user->name=strtoupper($request->get('nombre'));
        $user->apellido=strtoupper($request->get('apellido'));
        $user->password=$request->get('contrasenia');
        $user->dni=$request->get('dni');
        $user->email=$request->get('email');
        $user->telefono=$request->get('telefono');
        $user->celular=$request->get('celular');
        $user->direccion=strtoupper($request->get('direccion'));
        $user->rol_id=$request->get('tipo_usuario');
        $user->empresa_id=2;
        $user->estado='Activo';
        // $user->rol_id=1;
        $user->save();

        return redirect()->route('user.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $user = User::where('id', $id)
        ->first();

        return view('user.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $user = User::where('id', $id)
        ->first();

        return view('user.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $user = User::where('id', $id)
        ->first();
        $user->name=strtoupper($request->get('nombre'));
        $user->apellido=strtoupper($request->get('apellido'));
        $user->password=$request->get('contrasenia');
        $user->dni=$request->get('dni');
        $user->email=$request->get('email');
        $user->telefono=$request->get('telefono');
        $user->celular=$request->get('celular');
        $user->direccion=strtoupper($request->get('direccion'));
        $user->rol_id=$request->get('tipo_usuario');
        $user->empresa_id=2;
        $user->estado=$request->get('estado');
        $user->save();

        return redirect()->route('user.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function empresa($id){
        $user = Empresa::where('id',$id);

        return view('user.admin',compact('user'));
    }
}
