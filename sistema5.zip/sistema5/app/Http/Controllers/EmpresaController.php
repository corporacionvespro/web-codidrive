<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Empresa;
use Illuminate\Support\Facades\Storage;

class EmpresaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('roles');
    }
    
    public function index()
    {
        $empresas = new Empresa();

        $empresas=Empresa::all();
        
        return view('admin.index', compact('empresas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $empresa = new Empresa();

        $empresa->nombre=$request->get('nombre');
        $empresa->telefono=$request->get('telefono');
        $empresa->direccion=$request->get('direccion');
        $empresa->email=$request->get('email');
        // $empresa->estado='Activado';

        $id=str_random(3);
        if($request->file('file')!=""){
            $file = $request->file('file');
            $extension=$file->getClientOriginalExtension();
            $nombre='item'.$id.'.'.$extension;            
            Storage::disk('local')->put($nombre,  \File::get($file));
            $empresa->logo=$nombre;
        }
        $empresa->save();

        return redirect()->route('empresa.index'); 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $empresa = Empresa::where('id', $id)
                    ->first();

        return view('admin.show',compact('empresa'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $empresa = Empresa::where('id', $id)
                    ->first();

        return view('admin.edit',compact('empresa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $empresa = Empresa::where('id', $id)
        ->first();

        $empresa->nombre=$request->get('nombre');
        $empresa->telefono=$request->get('telefono');
        $empresa->direccion=$request->get('direccion');
        $empresa->email=$request->get('email');
        // $empresa->estado='Activado';

        $id=str_random(3);
        if($request->file('file')!=""){
            $file = $request->file('file');
            $extension=$file->getClientOriginalExtension();
            $nombre='item'.$id.'.'.$extension;            
            Storage::disk('local')->put($nombre,  \File::get($file));
            $empresa->logo=$nombre;
        }
        $empresa->save();

        return redirect()->route('empresa.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
