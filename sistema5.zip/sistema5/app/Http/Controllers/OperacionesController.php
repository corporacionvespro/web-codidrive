<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ingreso;
use App\Egreso;
use Carbon\Carbon;


class OperacionesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('roles', ['only' => ['cajafecha', 'ingresofecha', 'egresofecha', 'depositofecha', 'transferenciafecha']]);
    }
    
    /* informes diarios */
    public function ingreso()
    {
        $ingresos=Ingreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->get();
        return view('ingreso.index', compact('ingresos'));
        
    }

    public function deposito()
    {
        $depositos=Ingreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->get();
        return view('ingreso.deposito', compact('depositos'));
    }

    public function egreso()
    {
        $egresos=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Egreso')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->get();
        return view('egreso.index', compact('egresos'));
    }

    public function transferencia()
    {
        $transferencias=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Transferencia')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->get();
        return view('egreso.transferencia', compact('transferencias'));
    }

    public function hoy()
    {
        $egresos=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'));
                        // ->get();

        $ingresos=Ingreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->union($egresos)
                        ->orderBy('created_at','desc')
                        ->get();

        return view('operaciones', compact('ingresos'));
    }

    /* informes con fechas  */

    public function ingresofecha(Request $request){

        $inicio=$request->get('inicio');
        $fin=$request->get('fin');
        $i= new Carbon($inicio);
        $f=new Carbon($fin);

        $ingresos=Ingreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->get();

        return view('ingreso.index', compact('ingresos','inicio', 'fin'));
    }
    public function egresofecha(Request $request){ 

        $inicio= $request->get('inicio');
        $fin=$request->get('fin');
        $i= new Carbon($inicio);
        $f=new Carbon($fin);

        $egresos=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->get();
        return view('egreso.index', compact('egresos','inicio', 'fin'));
    }
    public function depositofecha(Request $request){

        $inicio= $request->get('inicio');
        $fin=$request->get('fin');
        $i= new Carbon($inicio);
        $f=new Carbon($fin);

        $depositos=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->get();
        return view('ingreso.deposito', compact('depositos','inicio', 'fin'));
    }
    public function transferenciafecha(Request $request){

        $inicio= $request->get('inicio');
        $fin=$request->get('fin');
        $i= new Carbon($inicio);
        $f=new Carbon($fin);

        $transferencias=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->get();
        return view('egreso.transferencia', compact('transferencias','inicio', 'fin'));
    }
    public function totales(Request $request){
       
        $inicio= $request->get('inicio');
        $fin=$request->get('fin');
        $i= new Carbon($inicio);
        $f=new Carbon($fin);

       $egresos=Egreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->whereBetween('fecha',[$i,$f]);
                        // ->get();

        $ingresos=Ingreso::where('numdoc','<>','0')
                        ->where('empresa_id','2')
                        ->whereBetween('fecha',[$i,$f])
                        ->union($egresos)
                        ->orderBy('created_at','desc')
                        ->get();

        return view('operaciones', compact('ingresos','inicio', 'fin'));
    }

    /* caja */

    public function cajahoy()
    {
        $ingreso=Ingreso::where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->sum('total');
                        // dd($ingresos);
        $egreso=Egreso::where('empresa_id','2')
                        ->where('tipo', 'Egreso')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->sum('total');
        $deposito=Ingreso::where('empresa_id','2')
                        ->where('tipo', 'Deposito')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->sum('total');
        $transferencia=Egreso::where('empresa_id','2')
                        ->where('tipo', 'Transferencia')                            
                        ->whereDate('fecha','=',Carbon::now()->format('Y-m-d'))
                        ->sum('total');
        $caja=$ingreso-$egreso;
        $banco=$deposito-$transferencia;
        $combinado=$caja+$banco;

        return view('caja', compact('ingreso', 'egreso', 'transferencia', 'deposito', 'caja', 'banco', 'combinado'));
    }

    public function cajafecha(Request $request)
    {
        // dd($request);
        $inicio= $request->get('inicio');
        $fin=$request->get('fin');
        $i= new Carbon($inicio);
        $f=new Carbon($fin);

        $ingreso=Ingreso::where('empresa_id','2')
                        ->where('tipo', 'Ingreso')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->sum('total');
                        // dd($ingresos);
        $egreso=Egreso::where('empresa_id','2')
                        ->where('tipo', 'Egreso')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->sum('total');
        $deposito=Ingreso::where('empresa_id','2')
                        ->where('tipo', 'Deposito')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->sum('total');
        $transferencia=Egreso::where('empresa_id','2')
                        ->where('tipo', 'Transferencia')                            
                        ->whereBetween('fecha',[$i,$f])
                        ->sum('total');
        $caja=$ingreso-$egreso;
        $banco=$deposito-$transferencia;
        $combinado=$caja+$banco;

        return view('caja', compact('ingreso', 'egreso', 'transferencia', 'deposito', 'inicio', 'fin', 'caja', 'banco', 'combinado'));
    }
}
