<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ingreso;
use App\Cliente;
use Carbon\Carbon;
use App\Otro_concepto;
use App\Egreso;
use App\Http\Requests\storeIngreso;

class IngresoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
    } 
    
    public function index()
    {
        // $ingresos=Ingreso::all();
        $ingresos=Ingreso::where('numdoc','<>','0')
                            ->get();
        return view('ingreso.index', compact('ingresos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){
                      
        return view('ingreso.create');
    }


    // $numeroConCeros = 
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function store(storeIngreso $request){

        /* $this->validate($request, [
            'numdoc'       => 'required| min:13',
            'unidad'       => '',
            'idcliente'    => '',
            'concepto'     => '',
            'descripcion2' => '', 
            'total'        => '',
            'tipo'         => 'required',
        ]); */

        Carbon::setLocale('es');
        
        // dd($request);
        $cliente_id=$request->get('idcliente');
        $total=$request->get('total');
       
        $precio_otros=$request->get('total2');
        $descripcion_otros=$request->get('descripcion2');
        $fecha_actual=Carbon::now('America/Lima');
        $observacion=$request->get('descripcion2');

        if($request->get('tipo')=='Ingreso' || $request->get('tipo')=='Deposito'){
            
            $this->validate($request, [
                'concepto'     => 'required',
            ], [
                'concepto.required' => 'Campo obligario, por favor buscar otra vez la unidad',
            ]); 
           
            $concepto=explode("?", $request->get('concepto'));
            $concepto_id=$concepto[0];
            $precio=$concepto[1];
            $periodo=$concepto[2];
            $nombre_concepto=$concepto[4];
            if($nombre_concepto=='OTROS'){
                $nombre_concepto=$descripcion_otros;
                $observacion='';
            }
            
            $ingreso= new Ingreso();
            $ingreso->numdoc=$request->get('numdoc');
            $ingreso->fecha=$fecha_actual;
            $ingreso->total=$total;
            $ingreso->tipo=$request->get('tipo');  
            $ingreso->descripcion=$nombre_concepto;
            // $ingreso->observacion=$observacion;
            $ingreso->cliente_id=$request->get('idcliente');
            $ingreso->concepto_id=$concepto_id;
            $ingreso->user_id=auth()->user()->id;
            $ingreso->empresa_id=auth()->user()->empresa_id;
            $ingreso->save();

            $resumen='<div class="modal fade" id="modal-resumen" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="mx-4 text-center">
                            <div class="alert alert-success mt-2" role="alert">
                                Se registro correctamente
                            </div>
                            <label class="pt-2">Resumen del registro </label> 
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="card-body pt-0" >                                
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Tipo</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$ingreso->tipo.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Unidad</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> '.$ingreso->cliente->unidad.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Afiliado</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> '.$ingreso->cliente->nombre.' '.$ingreso->cliente->apellido. '</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">N° Doc</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$ingreso->numdoc.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Concepto</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$ingreso->descripcion.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Total</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$ingreso->total.'</label>
                                </div>
                            </div>    
                        </div>
                    </div>
                </div>
            </div>';

        }elseif($request->get('tipo')=='Egreso' || $request->get('tipo')=='Tranferencia'){

            $this->validate($request, [
                'descripcion2' => 'required', 
            ]); 

            $egreso=new Egreso();
            $egreso->numdoc=$request->get('numdoc');
            $egreso->fecha=$fecha_actual;
            $egreso->total=$request->get('total');
            $egreso->tipo=$request->get('tipo');
            $egreso->descripcion=$request->get('descripcion2');
            // $egreso->concepto_id=$request->get('');
            $egreso->concepto_id=3;
            $egreso->proveedor_id=$request->get('idcliente');
            $egreso->user_id=2;
            $egreso->empresa_id=2;
            $egreso->save();

            $resumen='<div class="modal fade" id="modal-resumen" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="mx-4 text-center">
                            <div class="alert alert-success mt-2" role="alert">
                                Se registro correctamente
                            </div>
                            <label class="pt-2">Resumen del registro </label> 
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="card-body pt-0" >                                
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Tipo</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$egreso->tipo.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Unidad</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> '.$egreso->proveedor->nombre.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Afiliado</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> palomino vega </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">N° Doc</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$egreso->numdoc.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Concepto</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$egreso->descripcion.'</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="mombre">Total</span>
                                    </div>
                                    <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">'.$egreso->total.'</label>
                                </div>
                            </div>    
                        </div>
                    </div>
                </div>
            </div>';
        }

        /* if($request->get('tipo')=='Ingreso' || $request->get('tipo')=='Deposito'){
            $concepto=explode("?", $request->get('concepto'));
            $concepto_id=$concepto[0];
            $precio=$concepto[1];
            $periodo=$concepto[2];
            $nombre_concepto=$concepto[4];

            $ultimopago=Ingreso::select('descripcion')
                            ->where('cliente_id',$cliente_id)
                            ->where('concepto_id',$concepto_id)
                            ->orderBy('id','desc')
                            ->first();
            
            
            $fechaultima=explode('?',$ultimopago['descripcion']);
            
        
            $a=1;
            $b=1; //contadores

            if($nombre_concepto=='OTROS'){
                $ingreso= new Ingreso();
                $ingreso->numdoc=$request->get('numdoc');
                $ingreso->fecha=$fecha_actual;
                $ingreso->total=$precio_otros;
                $ingreso->tipo=$request->get('tipo');  
                $ingreso->descripcion=$descripcion_otros;
                $ingreso->cliente_id=$request->get('idcliente');
                $ingreso->concepto_id=$concepto_id;
                $ingreso->user_id=3;
                $ingreso->empresa_id=2;
                $ingreso->save();
                
                $total_otro=$request->get('montototal');
                $saldo=$request->get('saldo');

                if ($saldo!=0) {
                    $otros=new Otro_concepto();
                    $otros->nombre=$descripcion_otros;
                    $otros->costo=$total_otro;
                    $otros->saldo=$saldo;
                    $otros->estado='Debe';
                    $otros->cliente_id=$request->get('idcliente');
                    $otros->user_id=3;
                    $otros->empresa_id=3;
                    $otros->save();
                }
            }elseif ($precio!=$total && $precio!=0){
                
                $veces=$total/$precio;

                for ($i=0; $i <$veces; $i++) { 
                
                    if ($periodo=='Diario') {
                        // descripcion= nombreconcepto?fechapago -> del dia q lo toca pagar 
                        $fechapagoanterior=$fechaultima[1];
                        $fechapagada=Carbon::parse($fechapagoanterior);     
                        $fechapago=$fechapagada->addDays($a)->toDateString();
                        $descripcion=$nombre_concepto.'?'.$fechapago;
                    }
                    if ($periodo=='Mensual') {
                        // descripcion= nombreconcepto? n ?fechapago -> del dia q lo toca pagar 
                        $fechapagoanterior=$fechaultima[2];
                        $array=explode('-',$fechapagoanterior);
                        $mespago=$array[0]+$a;                
                        if($mespago<13 && $mespago>1){
                            $aniopago=$array[1];          
                        }else{
                            $aniopago=$array[1]+1;
                            $mespago=$b;
                            $b++; 
                        };
                        $numcuota=$fechaultima[1]+$a;
                        $descripcion= $nombre_concepto.'?'.$numcuota.'?'.$mespago.'-'.$aniopago;
                    }
                    $ingreso= new Ingreso();
                    $ingreso->numdoc=$request->get('numdoc');
                    $ingreso->fecha=$fecha_actual;
                    $ingreso->total=$precio;
                    $ingreso->tipo=$request->get('tipo');  
                    $ingreso->descripcion=$descripcion;
                    $ingreso->cliente_id=$request->get('idcliente');
                    $ingreso->concepto_id=$concepto_id;
                    $ingreso->user_id=3;
                    $ingreso->empresa_id=2;
                    $ingreso->save();
                    $a++;
                    echo $a;
                }
            }elseif ($precio==$total){
                
                if ($periodo=='Diario') {
                    $fechapagoanterior=$fechaultima[1];
                    $fechapagada=Carbon::parse($fechapagoanterior);     
                    $fechapago=$fechapagada->addDays($a)->toDateString();
                    $descripcion=$nombre_concepto.'?'.$fechapago;
                }
                if ($periodo=='Mensual') {
                    $fechapagoanterior=$fechaultima[2];
                    $array=explode('-',$fechapagoanterior);
                    $mespago=$array[0]+$a;                
                    if($mespago<13 && $mespago>1){
                        $aniopago=$array[1];          
                    }else{
                        $aniopago=$array[1]+1;
                        $mespago=$b;
                        $b++; 
                    };
                    $numcuota=$fechaultima[1]+$a;
                    $descripcion= $nombre_concepto.'?'.$numcuota.'?'.$mespago.'-'.$aniopago;
                }

                
                
                $ingreso= new Ingreso();
                $ingreso->numdoc=$request->get('numdoc');
                $ingreso->fecha=$fecha_actual;
                $ingreso->total=$precio;
                $ingreso->tipo=$request->get('tipo');  
                $ingreso->descripcion=$descripcion;
                $ingreso->cliente_id=$request->get('idcliente');
                $ingreso->concepto_id=$concepto_id;
                $ingreso->user_id=3;
                $ingreso->empresa_id=2;
                $ingreso->save();
            }
        }elseif($request->get('tipo')=='Egreso' || $request->get('tipo')=='Tranferencia'){

            $egreso=new Egreso();
            $egreso->numdoc=$request->get('numdoc');
            $egreso->fecha=$fecha_actual;
            $egreso->total=$request->get('total2');
            $egreso->tipo=$request->get('tipo');
            $egreso->descripcion=$request->get('descripcion2');
            // $egreso->concepto_id=$request->get('');
            $egreso->proveedor_id=$request->get('idcliente');
            $egreso->user_id=2;
            $egreso->empresa_id=2;
            $egreso->save();
        } */

        // return redirect()->route('ingreso.createresumen', compact('ingreso'));
        // ($ingreso);
        // return view('ingreso.detalles', compact('ingreso'));

       
        // return redirect()->back()->with('mensaje', $resumen);;
        return redirect()->route('ingreso.create')->with('mensaje', $resumen);;
    }

    // public function create_resumen(Ingreso $egreso)
    // {
                      
    //     return view('ingreso.create',compact('ingreso'));
    // }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ingreso = Ingreso::where('id', $ingreso)
        ->first();

        return view('ingreso.edit',compact('ingreso'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        /* $ingreso = Ingreso::where('id', $ingreso)
        ->first();

        $fecha_actual=Carbon::now('America/Lima');
        $ingreso->numdoc=$request->get('numdoc');
        $ingreso->fecha=$fecha_actual->toDateTimeString();
        // 
        $ingreso->total=$request->get('total');
        // $ingreso->saldo=4;
        // $ingreso->acuenta=4;
        $ingreso->tipo=$request->get('tipo2');  
        $ingreso->descripcion=$descripcion;
        $ingreso->cliente_id=$request->get('idcliente');
        $ingreso->concepto_id=$request->get('idconcepto');
        $ingreso->user_id=3;
        $ingreso->empresa_id=2;
        $ingreso->user_id=3;

        $ingreso->save(); */
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function concepto_cliente(Request $request)
    {
            $query = $request->get('query');
            $data=Cliente::select('conceptos.id', 'conceptos.nombre','conceptos.precio', 'conceptos.periodo','costo_fijos.cliente_id' )
                ->join('costo_fijos','clientes.id','=','costo_fijos.cliente_id')
                ->join('conceptos','costo_fijos.concepto_id','=','conceptos.id')
                ->where('clientes.id',$query)
                ->get();

            return $data;
            
        }

    public function buscarotro(Request $request){ //buscar cliente
        
        if($request->get('query')){
            $query = $request->get('query');
            $id=$request->get('id');
            $data = Otro_concepto::select('nombre', 'costo','saldo','id')
                ->where('nombre', 'LIKE', "%{$query}%")
                ->where('cliente_id', $id)
                ->get();
            $output = '';
            if ($data->count()>0) {
                $output = '<ul class="" 
                    style="    
                    display: block;
                    position: relative;
                ">';
                foreach($data as $row){
                    $output .= '
                    <li nombre="'.$row->costo.'?'.$row->saldo.'" id="'.$row->id.'"><a href="#">'.$row->nombre.'</a></li>                    
                    ';
                }
                $output .= '</ul>';
            }   
            echo $output;
        }
    }

    public function numdoc()
    {
        $numing=Ingreso::select('numdoc')
                        ->where("numdoc", "LIKE", "N°-I%")
                        ->orderBy('id','desc')
                        ->first();
        
        if ($numing==null) {
            $numdoci='N°-I 000001';
        }else{
            $array=explode(" ",$numing['numdoc']);
            $num=$array[1]+1;
            $numdoci='N°-I '.str_pad($num,6, "0", STR_PAD_LEFT);
        }

        $numegr=Egreso::select('numdoc')
                        ->where("numdoc", "LIKE", "N°-E%")
                        ->orderBy('id','desc')
                        ->first();
        
        if ($numegr==null) {
            $numdoce='N°-E 000001';
        }else{
            $array=explode(" ",$numegr['numdoc']);
            $num=$array[1]+1;
            $numdoce='N°-E '.str_pad($num,6, "0", STR_PAD_LEFT);
        }
        // return $numdoce; $numdoci;
       return response()->json(array('success' => true, 'numdoce'=>$numdoce, 'numdoci'=>$numdoci)); 
    }
}
