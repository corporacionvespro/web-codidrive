<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cliente;
use App\Concepto;
use App\Costo_fijo;
use App\Ingreso;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Http\Requests\ClienteValidation;

class ClienteController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        // $this->middleware('roles');
        $this->middleware('auth');

        $this->middleware('roles', ['only' => ['create', 'edit', 'showcostofijo']]);
        // $this->middleware('roles')->only('index');

        // $this->middleware('roles')->except('show');
    }

    
     
    public function index()
    {
        $afiliados=new Cliente();

        $afiliados=Cliente::all();
        return view('cliente.index', compact('afiliados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('cliente.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ClienteValidation $request)
    {
        $this->validate($request, [
            'dni' => 'unique:clientes,dni',
            'unidad'=>'unique:clientes,unidad',
        ]);
        
        $afiliado=new Cliente();
        $afiliado->nombre=strtoupper($request->get('nombre'));
        $afiliado->apellido=strtoupper($request->get('apellido'));
        $afiliado->dni=$request->get('dni');
        $afiliado->telefono=$request->get('telefono');
        $afiliado->celular=$request->get('celular');
        $afiliado->direccion=$request->get('direccion');
        $afiliado->unidad=strtoupper($request->get('unidad'));
        $afiliado->empresa_id='2';

        $afiliado->save();
        $id=$afiliado->id;

        // return redirect()->route('afiliado.index');
        return redirect()->route('concepto_cliente', compact('id'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $afiliado=Cliente::where('id',$id)
                        ->first();

        $concepto=Cliente::select('conceptos.id','conceptos.nombre', 'conceptos.precio', 'conceptos.periodo')
                            ->join('costo_fijos','clientes.id','=','costo_fijos.cliente_id')
                            ->join('conceptos','costo_fijos.concepto_id','=','conceptos.id')
                            ->where('clientes.id',$id)
                            ->where('conceptos.nombre','<>','OTROS')
                            ->get();
        // dd($concepto);
        return view('cliente.show',compact('afiliado','concepto'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $afiliado=Cliente::where('id',$id)
                        ->first();

        return view('cliente.edit',compact('afiliado'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ClienteValidation $request, $id)
    {
       
        $afiliado=new Cliente();

        $afiliado= Cliente::where('id',$id)
                        ->first();

        if($afiliado->unidad!==strtoupper($request->get('unidad'))){
            $this->validate($request, [
                // 'dni' => 'unique:clientes,dni',
                'unidad'=>'unique:clientes,unidad',
            ]); 
        }

        $afiliado->nombre=strtoupper($request->get('nombre'));
        $afiliado->apellido=strtoupper($request->get('apellido'));
        $afiliado->dni=$request->get('dni');
        $afiliado->telefono=$request->get('telefono');
        $afiliado->celular=$request->get('celular');
        $afiliado->direccion=strtoupper($request->get('direccion'));
        $afiliado->unidad=strtoupper($request->get('unidad'));
        $afiliado->empresa_id='2';
        $afiliado->save();

        return redirect()->route('afiliado.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function costofijo($id){
        $afiliado=Cliente::select('nombre', 'apellido', 'id')
                        ->where('id',$id)
                        ->first();
        $conceptos=Concepto::all();

        return view('concepto.hola', compact('afiliado', 'conceptos'));
    }

    /*  public function concepto(Request $request, $id){
        
        $datos=$request->get('concepto');
        // $datos=$request->get('precios');
        // $datos2=$_POST['precios'];

        // dd($datos);
        $tamaño=0;
        if($datos!=null){
            $tamaño=count($datos);
        }
        // dd($request->get('1')); 

        $descripcion='';

        for ($i=0; $i <$tamaño ; $i++) {
            $concepto=new Costo_fijo(); 
            $concepto->cliente_id=$id;
            $concepto->precio=10;
            $concepto->concepto_id=$datos[$i];
            $concepto->empresa_id=2;            
            $concepto->save();
            
            $ingreso=new Ingreso();
            $ingreso->numdoc=$concepto->id;

            // $ingreso->descripcion=$request->get('');
            // $ingreso->fecha=
            $ingreso->total=0;
            $ingreso->tipo="Ingreso";
            $ingreso->cliente_id=$id;
            $ingreso->user_id=2;
            $ingreso->empresa_id=2;
            $ingreso->concepto_id=$datos[$i];

            // $ingreso->descripcion=$request->get('');
            $fecha_actual=Carbon::now('America/Lima')->toDateTimeString();
            $ingreso->fecha=$fecha_actual;
            $descripcion=$request->get('concepto2').'?'.$fecha_actual;

            $ingreso->descripcion=$descripcion;
            $ingreso->save();
        } 

        // $view=view('afiliado.index')->render()
        $view=redirect()->route('afiliado.index');
        // return $view;
        //  $returnHTML = view('cliente.index')->render(); 
        //  return response()->json(array('success' => true, 'html'=>$returnHTML)); 
    } */

    public function showcostofijo($id){
        $afiliado=Cliente::select('nombre', 'apellido', 'id')
                        ->where('id',$id)
                        ->first();
        
        $idcliente=Costo_fijo::SELECT('costo_fijos.concepto_id as id ' , 'costos_fijos.cliente_id')
                            ->where('cliente_id',$id);

        $conceptos =Concepto::select('conceptos.id','cliente_id','nombre', 'concepto_id', 'precio')
                            ->leftJoin(DB::raw("(SELECT cos.concepto_id, cos.cliente_id from costo_fijos cos where cos.cliente_id=".$id.") sub"),'conceptos.id','=','sub.concepto_id')
                            ->where('nombre','<>','OTROS')
                            ->get(); 
        
       
        /* $conceptos=Concepto::SELECT('conceptos.id', 'conceptos.nombre') 
            ->leftJoin('costo_fijos', function($join){
                $join->on('conceptos.id','=','costo_fijos.concepto_id')
            })->get(); 
 
             $conceptos =DB::table('conceptos')
            ->leftJoin($idcliente, 'sub', function ($join) {
                $join->on('conceptos.id', '=', 'sub.id');
            })->get();                    
     
                             

                            dd($conceptos);
            SELECT con.id idconcepto, con.nombre concepto, sub.cliente_id from conceptos con
            left join (SELECT cos.concepto_id, cos.cliente_id from costo_fijos cos where cos.cliente_id=6) as sub on sub.concepto_id=con.id
        dd($conceptos); */

        return view('concepto.costo_update',compact('afiliado', 'conceptos'));
    }

    /*   public function concepto_update(Request $request){
        $datos=$request->get('precios');
        $fecha_actual=Carbon::now('America/Lima');
        // dd($datos);
        $tamaño=0;
        if($datos!=null){
            $tamaño=count($datos);
        }
       
        for ($i=0; $i <$tamaño ; $i++) { 
            $item=$datos[$i];
            $array=explode("?", $item);
            $concepto=new Costo_fijo(); 
            $concepto->precio=$array[0];
            $concepto->concepto_id=$array[1];
            $concepto->cliente_id=$array[2];
            $concepto->empresa_id=2;             
            $concepto->save();
            
            
            $array2=explode("-", $array[3]);
            $periodo=$array2[0];
            dd($array);
            $nombre_concepto=$array2[1];

            $ingreso=new Ingreso();
            $ingreso->numdoc='0';
            $ingreso->fecha=$fecha_actual->toDateString();
            $ingreso->total=0;
            $ingreso->tipo="Ingreso";
            $ingreso->cliente_id=$array[2];
            $ingreso->user_id=2;
            $ingreso->empresa_id=2;
            $ingreso->concepto_id=$array[1];

            if ($periodo=='Diario') {
                $descripcion=$nombre_concepto.'?'.$fecha_actual->toDateString();
            }
    
            if ($periodo=='Mensual') {
                $mespago=$fecha_actual->month;
                $aniopago=$fecha_actual->year;
                $descripcion= $nombre_concepto.'?'.'0'.'?'.$mespago.'-'.$aniopago;
            }
            if ($periodo=='Unico') {
                $descripcion=$nombre_concepto;
            }

            $ingreso->descripcion=$descripcion;            
            $ingreso->save();
        }
        
       
        $afiliados=Cliente::all();
        
        $returnHTML = view('cliente.index', compact('afiliados'))->renderSections()['content'];; 
        return response()->json(array('success' => true, 'html'=>$returnHTML)); 
        //  $view=view('afiliado.index')->render();
        //  $view=redirect()->route('afiliado.index');
        //  return $view;
        // return redirect()->route('afiliado.index');
        // return redirect()->route('afiliado.index');
        // return view('home')->renderSections()['content'];;
        // return view('home')->render();
    }   */
    
    public function buscarafiliado(Request $request){ //buscar cliente
        
        if($request->get('query')){
            $query = $request->get('query');
            $data = Cliente::select('unidad', 'nombre','apellido', 'id')
                ->where('unidad', 'LIKE', "%{$query}%")
                ->get();
            $output = '';
            if ($data->count()>0) {
                $output = '<ul class="" 
                    style="    
                    display: block;
                    position: relative;
                ">';
                foreach($data as $row){
                    $output .= '
                    <li nombre="'.$row->nombre.' '.$row->apellido.'" id="'.$row->id.'"><a href="#">'.$row->unidad.'</a></li>                    
                    ';
                }
                $output .= '</ul>';
            }   
            echo $output;
        }
    }

    public function concepto(Request $request, $id){
        
        $datos=$request->get('concepto');
        // $datos=$request->get('precios');
        // $datos2=$_POST['precios'];

        // dd($datos);
        $tamaño=0;
        if($datos!=null){
            $tamaño=count($datos);
        }

        $descripcion='';

        for ($i=0; $i <$tamaño ; $i++) {
            $concepto=new Costo_fijo(); 
            $concepto->cliente_id=$id;
            // $concepto->precio=10;
            $concepto->concepto_id=$datos[$i];
            $concepto->empresa_id=2;            
            $concepto->save();
        } 

        return redirect()->route('afiliado.index');
    }

    public function deuda(){
        $conceptos=Concepto::select('nombre')
                        ->where('empresa_id','2')
                        ->get();
                        // DB::raw('SUM(total) as total'),
                        $concepto=Ingreso::select('ingresos.cliente_id','ingresos.concepto_id',DB::raw('sum(total) as monto'))
                        ->groupBy('ingresos.cliente_id')
                        ->groupBy('ingresos.concepto_id')
                        ->get();


                       /*  >select(DB::raw('count(*) as user_count, status'))
                     ->where('status', '<>', 1)
                     ->groupBy('status')
                     ->get(); */

                        dd($concepto);
                            // select i.cliente_id i_cliente, cos.cliente_id cos_cliente, i.concepto_id concepto, cos.created_at, sum(total) from ingresos i
                            // inner join costo_fijos cos on cos.cliente_id=i.cliente_id 
                            // GROUP BY i.cliente_id, i.concepto_id

        return view('cliente.deuda', compact('conceptos'));
    }

    // public function login(){
    //     return view('login');
    // }
}
 