<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Concepto;
use App\Http\Requests\ConceptoValidation;

class ConceptoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('roles');
    }
    
    public function index()
    {
        $conceptos = new Concepto();
        $conceptos=Concepto::all();
        return view('concepto.index',compact('conceptos'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('concepto.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ConceptoValidation $request)
    {
        $concepto= new Concepto();
        $concepto->nombre=$request->get('nombre');
        $concepto->precio=$request->get('precio');
        $concepto->periodo=$request->get('periodo');
        $concepto->empresa_id=2;
        $concepto->save();

        return  redirect()->route('concepto.index');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $concepto=Concepto::where('id',$id)
                         ->first();
        
        return view('concepto.edit', compact('concepto'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(ConceptoValidation $request, $id)
    {
        // dd($request);
        $concepto= new Concepto();
        $concepto=Concepto::where('id',$id)
                            ->first();

        $concepto->nombre=$request->get('nombre');
        $concepto->precio=$request->get('precio');
        $concepto->periodo=$request->get('periodo');
        // dd($request);
        $concepto->save();

        return  redirect()->route('concepto.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function egresos(Request $request)
    {
        $concepto= new Concepto();
        $concepto->nombre=$request->get('nombre');
        $concepto->precio=$request->get('precio');
        $concepto->periodo=$request->get('periodo');
        $concepto->empresa_id=2;
        $concepto->save();

        return  redirect()->route('concepto.index');
    }
}
