<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

use Symfony\Component\HttpKernel\Exception\HttpException;

class Roles
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // dd(Auth::user());
        if(Auth::check() && Auth::user()->rol_id==1){
            return $next($request);
        }
       
        // throw new HttpException(503);
        return redirect()->back()->with('acceso', 'ACCESO NO DISPONIBLE');
        // return redirect()->back()->with('mensaje', Mensaje::success('Se registro producto, subir imagen.'));
        // abort(403, "No tienes autorización para ingresar");
        // return 'hola';
    }
}
