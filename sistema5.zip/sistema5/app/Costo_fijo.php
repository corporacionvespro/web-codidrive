<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Costo_fijo extends Model
{
    protected $table='costo_fijos';
    protected $fillable = ['cliente_id','concepto_id','precio', 'empresa_id'];

    public function afiliado(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->belongsTo('App\Costo_fijo');
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        // return $this->belongsTo('App\Roles');

    }
}
