<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table='users';
    protected $fillable = [
        'name', 'apellido','email', 'password', 'dni','telefono','celular','direccion','estado', 'rol_id', 'empresa_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

     public function rol(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->belongsTo('App\Roles');
        // return $this->belongsTo(Roles::class);
    }

    public function ingreso(){
        // hasMany -> tiene muchos 
        // un usuario tiene muchos pagos
        return $this->hasMany('App\Ingreso');
    }

    public function egreso(){
        // hasMany -> tiene muchos 
        // un usuario tiene muchos pagos
        return $this->hasMany('App\Egreso');
    }
}
