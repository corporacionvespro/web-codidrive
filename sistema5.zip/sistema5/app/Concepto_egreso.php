<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Concepto_egreso extends Model
{
    protected $table='concepto_egresos';
    protected $fillable = ['nombre','precio','periodico'];
}
