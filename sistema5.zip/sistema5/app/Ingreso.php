<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ingreso extends Model
{
    protected $table='ingresos';
    protected $fillable = [
        'numdoc','descripcion', 'fecha', 'total','tipo','cliente_id','user_id','empresa_id','concepto_id'
    ];

    public function user(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->belongsTo('App\User');
    }

    public function cliente(){
        // belongsTo -> pertenece a 
        // un pago pertenece a un usuario
        return $this->belongsTo('App\Cliente');
    }
}
