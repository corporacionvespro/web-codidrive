<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sistema web </title>

  {{-- Booststrap  --}}
  <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet"> 
  {{-- icon fontawesome--}}
  <link href="{{asset('css/all-fontawesome.min.css')}}" rel="stylesheet">  
  {{-- datatable booststrap --}}
  <link href="{{asset('css/dataTables.bootstrap4.css')}}" rel="stylesheet">
  {{-- css app --}}
  <link href="{{asset('css/sb-admin.css')}}" rel="stylesheet">
  {{-- calendario --}}
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.print.css">

  
  {{-- agregar esto para enviar el token en ajax --}}
  <meta name="csrf_token" content="{{csrf_token()}}"/>

</head>

<body id="#" class="" >
  <!-- Navigation-->
  <div class="login">
    <div class="modal-dialog text-center">
        <div class="col-sm-9 main-section">
            <div class="modal-content">
                <div class="col-12 user-img">
                    <img src="{{asset('img/logo3.png')}}" alt="">
                </div>
                <div class="col-12 form-input">
                    <form action="">
                        <div class="form-group">
                            <input type="text"  class="form-control" placeholder="Ingrese su DNI">
                        </div>
                        <div class="form-group">
                            <input type="text"  class="form-control" placeholder="Ingrese su contraseñia">
                        </div>

                        <button type="submit" class="btn btn-lg btn-success"> Login</button>                        
                    </form>
                </div>
              {{--   <div class="col-12 forgot">
                    <a href="#">Me olvide mi contraseñia</a>
                </div> --}}
            </div>
        </div>

    </div>
</div>
  {{-- booststrap y jquery --}}
  <script src="{{asset('js/jquery.min.js')}}"></script>
  <script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
  {{-- datateble--}}
  {{-- <script src="{{asset('js/jquery.dataTables.js')}}"></script>
  <script src="{{asset('js/dataTables.bootstrap4.js')}}"></script>
  <script src="{{asset('js/sb-admin-datatables.js')}}"></script> --}}

  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>

  {{-- scripts app --}}
  <script src="{{asset('js/sb-admin.js')}}"></script>




   
</body>

</html>
