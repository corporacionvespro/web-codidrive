{{-- @extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Login</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="{{ route('login') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password" required>

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember Me
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Login
                                </button>

                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    Forgot Your Password?
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
 --}}

 <!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sistema web </title>

  {{-- Booststrap  --}}
  <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet"> 
  {{-- icon fontawesome--}}
  <link href="{{asset('css/all-fontawesome.min.css')}}" rel="stylesheet">  
  {{-- datatable booststrap --}}
  <link href="{{asset('css/dataTables.bootstrap4.css')}}" rel="stylesheet">
  {{-- css app --}}
  <link href="{{asset('css/sb-admin.css')}}" rel="stylesheet">
  {{-- calendario --}}
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.print.css">

  
  {{-- agregar esto para enviar el token en ajax --}}
  <meta name="csrf_token" content="{{csrf_token()}}"/>

</head>

<body id="#" class="" >
  <!-- Navigation-->
  <div class="login">
    <div class="modal-dialog h text-center">
        <div class="col-sm-9 main-section">
            <div class="modal-content h">
                <div class="col-12 user-img">
                    <img src="{{asset('img/logo3.png')}}" alt="">
                </div>
                <div class="col-12 form-input">
                    <form  method="POST" action="{{ route('login') }}" id="login">
                        {{ csrf_field() }}
                        {{-- <div class="form-group">
                            <input type="text"  name="dni" class="form-control" placeholder="Ingrese su DNI">
                        </div>
                        <div class="form-group">
                            <input type="text" name="password" class="form-control" placeholder="Ingrese su contraseñia">
                        </div> --}}

                         <div class="form-group{{ $errors->has('login') ? ' input-error' : '' }}">
                            {{-- <label for="email" class="col-md-4 control-label">E-Mail o Usuario</label> --}}

                            {{-- <div class="col-md-6"> --}}
                                    <input id="login" type="login" class="form-control" name="login" value="{{ old('login') }}" required  placeholder="Ingrese DNI"> {{-- autofocus --}}
                                    @if ($errors->has('login'))
                                        <span class='error'>
                                            <strong>{{ $errors->first('login') }}</strong>
                                        </span>
                                    @endif
                            {{-- </div> --}}
                        </div>

                        {{-- <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}" required autofocus>

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div> --}}

                       
                        <div class="form-group{{ $errors->has('password') ? ' input-error' : '' }}">
                            {{-- <label for="password" class="col-md-4 control-label">Password</label> --}}

                            {{-- <div class="col-md-6"> --}}
                                <input id="password" type="password" class="form-control" name="password" required placeholder="Ingrese contraseña">

                                @if ($errors->has('password'))
                                    <span class="error">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            {{-- </div> --}}
                        </div>

                        <button type="submit" class="btn btn-lg btn-success"> Login</button>                        
                    </form>
                </div>
              {{--   <div class="col-12 forgot">
                    <a href="#">Me olvide mi contraseñia</a>
                </div> --}}
            </div>
        </div>

    </div>
</div>
  {{-- booststrap y jquery --}}
  <script src="{{asset('js/jquery.min.js')}}"></script>
  <script src="{{asset('js/bootstrap.bundle.min.js')}}"></script>
  {{-- datateble--}}
  {{-- <script src="{{asset('js/jquery.dataTables.js')}}"></script>
  <script src="{{asset('js/dataTables.bootstrap4.js')}}"></script>
  <script src="{{asset('js/sb-admin-datatables.js')}}"></script> --}}

  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>

  {{-- scripts app --}}
  <script src="{{asset('js/sb-admin.js')}}"></script>




   
</body>

</html>
