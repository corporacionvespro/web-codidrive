@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar  afiliado</div>
      <div class="card-body">
        <form method="POST" action=" {{ route('afiliado.store')}} "> 
                    {{ csrf_field() }} 
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                            </div>
                            <input type="text" class="form-control {{ $errors->has('nombre') ? 'input-error' : '' }}" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required  value="{{ old('nombre') }}">
                        </div>
                        @if ($errors->has('nombre'))
                            <span class="error"><strong>{{ $errors->first('nombre') }}</strong></span>
                        @endif
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                            </div>
                            <input class="form-control {{ $errors->has('apellido') ? 'input-error' : '' }}" id="apellido" name="apellido" type="text" placeholder="apellidos"  value="{{ old('apellido') }}">
                        </div>
                        @if ($errors->has('apellido'))
                            <span class="error"><strong>{{ $errors->first('apellido') }}</strong></span>
                        @endif    
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                        </div>
                        <input class="form-control {{ $errors->has('dni') ? 'input-error' : '' }}" id="dni" type="text" name="dni" placeholder="DNI"  value="{{ old('dni') }}">
                    </div>
                    @if ($errors->has('dni'))
                        <span class="error"><strong>{{ $errors->first('dni') }}</strong></span>
                    @endif 
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                    </div>
                    <input class="form-control {{ $errors->has('unidad') ? 'input-error' : '' }}" id="email" type="text" name="unidad"   placeholder="N° de unidad " value="{{ old('unidad') }}">
                     
                </div>
                @if ($errors->has('unidad'))
                    <span class="error"><strong>{{ $errors->first('unidad') }}</strong></span>
                @endif   
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <input class="form-control {{ $errors->has('telefono') ? 'input-error' : '' }}" id="telefono" type="text" name="telefono"   placeholder="teléfono" value="{{ old('telefono') }}">
                    
                </div>
                @if ($errors->has('telefono'))
                <span class="error"><strong>{{ $errors->first('telefono') }}</strong></span>
            @endif  
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                    </div>
                    <input class="form-control {{ $errors->has('celular') ? 'input-error' : '' }}h" id="celular" type="text" name="celular"  placeholder="celular" value="{{ old('celular') }}">
                       
                </div>
                @if ($errors->has('celular'))
                    <span class="error"><strong>{{ $errors->first('celular') }}</strong></span>
                @endif 
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                </div>
                <input class="form-control {{ $errors->has('direccion') ? 'input-error' : '' }}" id="direccion" name="direccion" type="text"   placeholder="dirección" value="{{ old('direccion') }}">
                  
            </div>
            @if ($errors->has('direccion'))
                <span class="error"><strong>{{ $errors->first('direccion') }}</strong></span>
            @endif  
            </div>
            {{-- <div class="form-group">
                <div class="form-row">
                <div class="col-md-12">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                    </div>
                    <input class="form-control" id="contrasenia" name="contrasenia" type="password"  placeholder="contraseña " >
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                    </div>
                    <input class="form-control" id="confcontrasenia" name="confcontrasenia" type="password"  placeholder="Confirmar contraseña" >
                    </div>
                </div>
                </div>

            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                            <label for="estado">Tipo de Usuario</label>
                        <select class="form-control" name="tipo_usuario" id="tipo_usuario" required="">
                            @php
                                $variable = array( array('id'=>1,'nombre'=>'Administrador'),array('id'=>'2','nombre'=>'Gerente'),array('id'=>'3','nombre'=>'Operador'));
                                
                                foreach ($variable as $tipo) {
                                    echo '<option value="' .$tipo['id']. '" ';
                                    if( $afiliado->rol->nombre == $tipo['nombre']){
                                        echo 'selected';
                                    } 
                                    echo ' > ' . $tipo['nombre'] . '</option>';
                                    }
                            @endphp
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="estado">Estado</label>
                        <select class="form-control" name="estado" id="estado" required="">
                            @php
                            $variable = array('Activo','Inactivo');
                    
                            foreach ($variable as $tipo) {
                                echo '<option value="' .$tipo. '" ';
                                if( $afiliado->estado == $tipo){
                                    echo 'selected';
                                } 
                                echo ' > ' . $tipo . '</option>';
                                }
                        @endphp
                        </select>
                    </div>
                </div>
    
            </div> --}}
            
            <button type="submit" class="form-control btn-primary">Guardar cambios</button>
        </form>
      </div>
    </div>
  </div>
@endsection