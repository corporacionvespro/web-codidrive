@extends('layouts.admin')

@section('content')
<div class="container">
    {{-- <button type="submit"  class="btn btn-primary mb-3" ><i class="fas fa-plus-circle"></i> Registrar nuevo</button> --}}
<a href="{{route('afiliado.create')}}" class="btn btn-primary mb-3" role="button"><i class="fas fa-plus-circle"></i> Registrar nuevo</a>
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de afiliados</div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Afiliado</th>
                        <th scope="col">DNI </th>
                        <th scope="col">Telefono - Celular</th>
                        <th scope="col">Direccion</th>
                        <th scope="col">Unidad</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($afiliados as $afiliado) 
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$afiliado->nombre}} {{$afiliado->apellido}}</td>
                        <td>{{$afiliado->dni}}</td>
                        <td>{{$afiliado->telefono}} - {{$afiliado->celular}} </td>
                        <td>{{$afiliado->direccion}} </td>
                        <td>{{$afiliado->unidad}} </td>
                        <td>
                            <a class="btn btn-primary text-white" href=" {{ route('afiliado.show', $afiliado->id)}} " >
                            Ver
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-success text-white" href=" {{ route('afiliado.edit', $afiliado->id)}} " role="button">
                            Editar
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-danger text-white" href=" {{ route('afiliado.show', $afiliado->id)}} " role="button">
                                Eliminar
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-danger text-white" href=" {{ route('afiliado.showcosto', $afiliado->id)}} " role="button">
                                adeudo
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
@endsection