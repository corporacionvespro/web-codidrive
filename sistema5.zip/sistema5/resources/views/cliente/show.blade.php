@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
            <div class="card-header "><i class="fas fa-user-tie"></i> AFILIADO: <span class="user">{{$afiliado->nombre}} {{$afiliado->apellido}}</span></div>
      <div class="card-body">
        <form method="POST" action=" {{ route('afiliado.show',$afiliado->id)}} ">
                    {{ csrf_field() }}
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                        </div>
                        <label type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required >{{$afiliado->nombre}}</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                    </div>
                    <label class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos" >{{$afiliado->apellido}}</label>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                    </div>
                    <label class="form-control" id="dni" type="text" name="dni" placeholder="DNI">{{$afiliado->dni}}</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                    </div>
                    <label class="form-control" id="email" type="text" name="unidad"   placeholder="N° de unidad "> {{$afiliado->unidad}}</label>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <label class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono">{{$afiliado->telefono}}</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                    </div>
                    <label class="form-control" id="celular" type="text" name="celular"  placeholder="celular">{{$afiliado->celular}}</label>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                </div>
                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$afiliado->direccion}}</label>
                </div>
            </div>
            {{-- <div class="form-group">
                <div class="form-row">
                <div class="col-md-12">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                    </div>
                    <label class="form-control" id="contrasenia" name="contrasenia" type="password"  placeholder="contraseña ">{{$afiliado->password}}</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                    </div>
                    <label class="form-control" id="confcontrasenia" name="confcontrasenia" type="password"  placeholder="Confirmar contraseña">{{$afiliado-> }}</label>
                    </div>
                </div>
                </div>

            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                            <label for="estado">Tipo de Usuario</label>
                        <select class="form-control" name="tipo_usuario" id="tipo_usuario" required="">
                            @php
                                $variable = array( array('id'=>1,'nombre'=>'Administrador'),array('id'=>'2','nombre'=>'Gerente'),array('id'=>'3','nombre'=>'Operador'));
                                
                                foreach ($variable as $tipo) {
                                    echo '<option value="' .$tipo['id']. '" ';
                                    if( $afiliado->rol->nombre == $tipo['nombre']){
                                        echo 'selected';
                                    } 
                                    echo ' > ' . $tipo['nombre'] . '</option>';
                                    }
                            @endphp
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="estado">Estado</label>
                        <select class="form-control" name="estado" id="estado" required="">
                            @php
                            $variable = array('Activo','Inactivo');
                    
                            foreach ($variable as $tipo) {
                                echo '<option value="' .$tipo. '" ';
                                if( $afiliado->estado == $tipo){
                                    echo 'selected';
                                } 
                                echo ' > ' . $tipo . '</option>';
                                }
                        @endphp
                        </select>
                    </div>
                </div>
    
            </div> --}}
            
            {{-- <button type="submit" class="form-control btn-primary">Guardar cambios</button> --}}

            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th scope="col">Concepto</th>
                            <th scope="col">Precio </th>
                            <th scope="col">Periodo</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($concepto as $item) 
                        <tr>
                            <td>{{$loop->iteration}}</td>
                            <td>{{$item->nombre}}</td>
                            <td>{{$item->precio}} </td>
                            <td>{{$item->periodo}} </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
        </form>

        <div>

                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">DERECHO</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">GPS</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">CAMISA</a>
                        </li>
                      </ul>
                      <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">.
                        hola josep 
                            ..</div>
                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...
                            hola elias 
                        </div>
                        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...
                            klldjfldsfkjdsf
                        </div>
                      </div>
        </div>
      </div>
    </div>
  </div>
@endsection