@extends('layouts.admin')

@section('content')
<div class="container">
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de afiliados con deuda </div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Afiliado</th>
                        @foreach ($conceptos as $concepto)
                    <th scope="col">{{$concepto->nombre}}</th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    {{-- @foreach ($afiliados as $afiliado)  --}}
                    <tr>
                        {{-- <td>{{$loop->iteration}}</td> --}}
                        {{-- <td>{{$afiliado->nombre}} {{$afiliado->apellido}}</td>
                        <td>{{$afiliado->dni}}</td>
                        <td>{{$afiliado->telefono}} - {{$afiliado->celular}} </td>
                        <td>{{$afiliado->direccion}} </td>
                        <td>{{$afiliado->unidad}} </td> --}}
                        <td>1</td>
                        <td>palomino vega </td>
                        <td>S/. 10</td>
                        <td>S/. 10</td>
                        <td>S/. 10</td>
                    </tr>
                    {{-- @endforeach --}}
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
@endsection