@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Modificar afiliado</div>
      <div class="card-body">
        <form method="POST" action=" {{ route('afiliado.update',$afiliado)}} "> 
                    {{ csrf_field() }} {{ method_field('PUT') }}
                {{-- @if (count($errors))
                    @foreach ($errors->all() as $item)
                        <p>{{$item}}</p>
                    @endforeach
                @endif --}}
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                            </div>
                            <input type="text" class="form-control {{ $errors->has('nombre') ? 'input-error' : '' }}" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required  value={{$afiliado->nombre}}  value="{{ old('nombre') }}">
                        </div>
                        @if ($errors->has('nombre'))
                            <span class="error"><strong>{{ $errors->first('nombre') }}</strong></span>
                        @endif   
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                            </div>
                                <input class="form-control{{ $errors->has('apellido') ? 'input-error' : '' }}"  id="apellido"  name="apellido" type="text" placeholder="apellidos"  value={{$afiliado->apellido}}{{--  value="{{old('apellido')}}" --}}>
                        </div>
                        @if ($errors->has('apellido'))
                            <span class="error"><strong>{{ $errors->first('apellido') }}</strong></span>
                        @endif   
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                            </div>
                            <input class="form-control {{ $errors->has('dni') ? 'input-error' : '' }}" id="dni" type="text" name="dni" placeholder="DNI" value="{{$afiliado->dni}}" {{--  value="{{old('dni')}}" --}}>
                        </div>
                        @if ($errors->has('dni'))
                            <span class="error"><strong>{{ $errors->first('dni') }}</strong></span>
                        @endif   
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                            </div>
                            <input class="form-control {{ $errors->has('unidad') ? 'input-error' : '' }}" id="email" type="text" name="unidad"   placeholder="N° de unidad " value="{{$afiliado->unidad}}"{{--  value="{{old('unidad')}}" --}}>
                        </div>
                        @if ($errors->has('unidad'))
                            <span class="error"><strong>{{ $errors->first('unidad') }}</strong></span>
                        @endif   
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <input class="form-control {{ $errors->has('telefono') ? 'input-error' : '' }}" id="telefono" type="text" name="telefono"   placeholder="telefono" value={{$afiliado->telefono}} >
                    </div>
                    @if ($errors->has('telefono'))
                    <span class="error"><strong>{{ $errors->first('telefono') }}</strong></span>
                @endif   
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                    </div>
                    <input class="form-control {{ $errors->has('celular') ? 'input-error' : '' }}" id="celular" type="text" name="celular"  placeholder="celular" value={{$afiliado->celular}}{{--  value="{{old('celular')}}" --}}>
                    </div>
                    @if ($errors->has('celular'))
                    <span class="error"><strong>{{ $errors->first('celular') }}</strong></span>
                @endif   
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                    </div>
                    <input class="form-control {{ $errors->has('direccion') ? 'input-error' : '' }}" id="direccion" name="direccion" type="text"   placeholder="dirección" value={{$afiliado->direccion}}{{--  value="{{old('direccion')}}" --}}>
                </div>
                @if ($errors->has('direccion'))
                    <span class="error"><strong>{{ $errors->first('direccion') }}</strong></span>
                @endif   
            </div>
            <button type="submit" class="form-control btn-primary">Guardar</button>
        </form>
      </div>
    </div>
  </div>
@endsection