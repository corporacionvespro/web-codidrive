
@extends('layouts.admin')

@section('content')
<div class="row my-2 justify-content-center">
    <div class="col-sm-12 col-md-6 ">
        <form method="POST" action=" {{ route('ingreso.store')}} "> 
            {{ csrf_field() }}
            <div class="row">
                <div class="form-group col-12 col-sm-12 col-md-12" id="divtipo">
                    <label for="tipo">Tipo operación</label>
                    <select class="form-control" name="tipo" id="tipo" required="">
                        <option selected value="">Tipo operación</option>
                        <option value="Ingreso">Ingreso</option>
                        <option value="Egreso">Egreso</option>
                        <option value="Deposito">Deposito</option>
                        <option value="Transferencia">Transferencia</option>
                    </select>
                    {{-- <input type="text"hola name="tipo2" class="form-control" id="tipo2"> --}}
                </div>
                <div class="col-12 col-sm-12 col-md-4" hola  id="divunidad" >
                    <div class="form-group">
                        <label id="alias" for="cliente">Unidad</label>
                        <input type="text" name="cliente" class="form-control" id="cliente" autocomplete="off">
                        <div class="dropdown-menu combo"  id="clienteList"></div>                            
                    </div>
                    
                </div> 
                <div class="col-12 col-sm-12 col-md-8" hola  id="divcliente">
                    <div class="form-group">
                        <label for="cliente">Afiliado</label>
                        <input type="text" name="cliente2" class="form-control" id="cliente2" autocomplete="off" disabled>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-8"hola hidden >
                    <div class="form-group">
                        <input type="text" name="idcliente" class="form-control" id="idcliente">
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-12"hola   id="divnumdoc" >
                    <div class="form-group">
                        <label for="nombre">N° Documento</label>
                    <input type="text" name="numdoc"  class="form-control" id="numdoc" required="" value="{{$numdoc}}">
                    </div>
                </div>
                {{-- <div class="form-group col-12 col-sm-12 col-md-12"hola   id="divdescripcion">
                    <label for="tipo">descripcion</label>
                    <select class="form-control" name="descripcion" id="descripcion">
                        <option selected value="">Elija</option>
                        @foreach ($conceptos as $concepto)
                        <option value="{{$concepto->id}}">{{$concepto->nombre}}</option>
                        @endforeach
                        <option value="Diario">Diario</option>
                        <option value="Camisa">Camisa</option>
                        <option value="GPS">GPS</option>
                        <option value="Otros">Otros</option>
                    </select>
                </div> --}}
                <div class="col-12 col-sm-12 col-md-12"hola  hidden id="divdescripcion2">
                    <div class="form-group">
                        <label for="descripcion">Descripción</label>
                        <textarea class="form-control" rows="2" name="descripcion2" aria-label="With textarea"></textarea>
                    </div>
                </div> 
                <div class="col-12 col-sm-12 col-md-12"hola   id="divconcepto">
                    
                </div> 
                {{-- <div class="col-12 col-sm-12 col-md-12"hola   id="divdestinatario">
                    <div class="form-group">
                        <label for="descripcion">Destinatario</label>
                        <input type="text" class="form-control" name="cliente" id="cliente">
                    </div>
                </div>   --}}
                <div class="col-12 col-sm-12 col-md-12"hola   id="divmonto">
                    <div class="form-group">
                        <label for="descripcion">total</label>
                        <input class="form-control" id="total" name="total">
                    </div>
                </div>                          
                                        
                {{-- <div class="col-12 col-sm-12 col-md-12"hola  >
                    <div class="form-group">
                        <label for="user">Usuario</label>
                        <input type="text" name="user" class="form-control" id="user" required="" value=" palomino"autocomplete="off">
                    </div>
                    <div class=""  id="userList"></div>
                </div> 
                <div class="col-12 col-sm-12 col-md-12"hola >
                    <div class="form-group">
                        <label for="date">Fecha</label>
                    <input type="date" name="fecha" class="form-control" id="date" required="" >
                    </div>
                </div>--}} 
            </div>
            {{-- {{-- <div class="row">
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="total">Total</label>
                    <input type="text" name="total" class="form-control" id="total" placeholder="S/. 0.00" required="">
                </div>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="acuenta">A_cuenta</label>
                    <input type="text" name="acuenta" class="form-control" id="acuenta" placeholder="S/. 0.00"  required="">
                </div>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="saldo">Saldo</label>
                    <input type="text" name="saldo" class="form-control" id="saldo" placeholder="S/. 0.00"  required="">
                </div> 
            </div> --}}
            <div class="row justify-content-center"hola  id="button">
                <div class="col-11 col-sm-11 col-md-11">
                    <button type="submit" class="btn btn-success my-3 btn-lg btn-block" data-toggle="modal" data-target="#fecha">Guardar</button>
                </div>
                
            </div>
        </form>
    </div>
</div>
@endsection