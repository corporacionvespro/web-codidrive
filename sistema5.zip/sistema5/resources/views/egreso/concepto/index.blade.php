@extends('layouts.admin')

@section('content')
<div class="container">
    {{-- <button type="submit"  class="btn btn-primary mb-3" ><i class="fas fa-plus-circle"></i> Registrar nuevo</button> --}}
<a href="{{route('concepto_egreso.create')}}" class="btn btn-primary mb-3" role="button"><i class="fas fa-plus-circle"></i> Registrar nuevo</a>
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de concepto de egresos</div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Nombre </th>
                        <th scope="col">Precio</th>
                        <th scope="col">Periodo</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($conceptos as $concepto) 
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$concepto->nombre}}</td>
                        <td>S/. {{$concepto->precio}}</td>
                        <td>{{$concepto->periodo}}</td>
                        {{-- <td>
                            <a class="btn btn-primary text-white" href=" {{ route('afiliado.show', $afiliado->id)}} " >
                            Ver
                            </a>
                        </td> --}}
                        <td>
                            <a class="btn btn-success text-white" href=" {{ route('concepto_egreso.edit', $concepto->id)}} " role="button">
                            Editar
                            </a>
                        </td>
                        {{-- <td>
                            <a class="btn btn-danger text-white" href=" {{ route('afiliado.show', $afiliado->id)}} " role="button">
                                Eliminar
                            </a>
                        </td> --}}
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
@endsection