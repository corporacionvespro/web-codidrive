@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Actualizar concepto de egreso</div>
      <div class="card-body">
        <form method="POST" action=" {{ route('concepto_egreso.update',$concepto)}} "> 
                    {{ csrf_field() }} {{ method_field('PUT') }}
            <div class="form-group ">
                <div class="input-group {{ $errors->has('nombre') ? 'input-error' : '' }}">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user"></i></span>
                    </div>
                    <input class="form-control" id="nombre" name="nombre" type="text"   value="{{$concepto->nombre}}" >
                </div>
                @if ($errors->has('nombre'))
                    <span class="error"><strong>{{ $errors->first('nombre') }}</strong></span>
                @endif 
            </div>
            <div class="form-group ">
                <div class="input-group {{ $errors->has('precio') ? 'input-error' : '' }}">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <input class="form-control" id="precio" name="precio" type="text"   placeholder="telefono" value="{{$concepto->precio}}" >
                </div>
                @if ($errors->has('precio'))
                    <span class="error"><strong>{{ $errors->first('precio') }}</strong></span>
                @endif 
            </div>            
            <div class="form-group">
                    <label for="estado">Estado</label>
                    <select class="form-control {{ $errors->has('periodo') ? 'input-error' : '' }}" name="periodo" id="periodo" required="">
                        @php
                        $variable = array('Diario','Semanal','Quinsenal','Mensual','Unico');
                      
                        foreach ($variable as $tipo) {
                            echo '<option value="' .$tipo. '" ';
                            if( $concepto->periodo == $tipo){
                                echo 'selected';
                            } 
                            echo ' > ' . $tipo . '</option>';
                            }
                    @endphp
                    </select>
                    @if ($errors->has('periodo'))
                        <span class="error"><strong>{{ $errors->first('periodo') }}</strong></span>
                    @endif 
            </div>

            <button type="submit" class="form-control btn-primary">Guardar cambios</button>
        </form>
      </div>
    </div>
  </div>
@endsection