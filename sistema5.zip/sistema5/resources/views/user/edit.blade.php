@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Modificar usuario</div>
      <div class="card-body">
        <form method="POST" action=" {{ route('user.update',$user)}} "> 
                    {{ csrf_field() }} {{ method_field('PUT') }}
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                        </div>
                        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipUsernamePrepend" required  value={{$user->name}}>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                    </div>
                    <input class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos"  value={{$user->apellido}}>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-4">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                    </div>
                    <input class="form-control" id="dni" type="text" name="dni" placeholder="DNI"  value={{$user->dni}}>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-at"></i></span>
                    </div>
                    <input class="form-control" id="email" type="email" name="email"   placeholder="email " value={{$user->email}}>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <input class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono" value={{$user->telefono}}>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                    </div>
                    <input class="form-control" id="celular" type="text" name="celular"  placeholder="celular" value={{$user->celular}}>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                </div>
                <input class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección" value={{$user->direccion}}>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-12">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                    </div>
                    <input class="form-control" id="contrasenia" name="contrasenia" type="password"  placeholder="contraseña " value={{$user->password}}>
                    </div>
                </div>
                {{-- <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                    </div>
                    <input class="form-control" id="confcontrasenia" name="confcontrasenia" type="password"  placeholder="Confirmar contraseña" value={{$user-> }}>
                    </div>
                </div> --}}
                </div>

            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                            <label for="estado">Tipo de Usuario</label>
                        <select class="form-control" name="tipo_usuario" id="tipo_usuario" required="">
                            @php
                                $variable = array( array('id'=>1,'nombre'=>'Administrador'),array('id'=>'2','nombre'=>'Gerente'),array('id'=>'3','nombre'=>'Operador'));
                                
                                foreach ($variable as $tipo) {
                                    echo '<option value="' .$tipo['id']. '" ';
                                    if( $user->rol->nombre == $tipo['nombre']){
                                        echo 'selected';
                                    } 
                                    echo ' > ' . $tipo['nombre'] . '</option>';
                                    }
                            @endphp
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="estado">Estado</label>
                        <select class="form-control" name="estado" id="estado" required="">
                            @php
                            $variable = array('Activo','Inactivo');
                    
                            foreach ($variable as $tipo) {
                                echo '<option value="' .$tipo. '" ';
                                if( $user->estado == $tipo){
                                    echo 'selected';
                                } 
                                echo ' > ' . $tipo . '</option>';
                                }
                        @endphp
                        </select>
                    </div>
                </div>
    
            </div>
            
            <button type="submit" class="form-control btn-primary">Guardar cambios</button>
        </form>
      </div>
    </div>
  </div>
@endsection