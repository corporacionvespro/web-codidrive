@extends('layouts.admin')

@section('content')
<div class="container">
    {{-- <button type="submit"  class="btn btn-primary mb-3" ><i class="fas fa-plus-circle"></i> Registrar nuevo</button> --}}
    <a href="{{route('user.create')}}" class="btn btn-primary mb-3" role="button"><i class="fas fa-plus-circle"></i> Registrar nuevo</a>
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de usuarios</div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Usuario</th>
                        <th scope="col">Email </th>
                        <th scope="col">Contraseñia</th>
                        <th scope="col">DNI</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Celular</th>
                        <th scope="col">Direccion</th>
                        <th scope="col">Rol</th>
                        <th scope="col">Estado</th>
                        <th scope="col" colspan="3">Acciones</th>

                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user) 
                    <tr>
                        <td>{{$loop->iteration}}</td>
                    <td>{{$user->name}} {{$user->apellido}}</td>
                        <td>{{$user->email}} </td>
                        <td>{{$user->password}} </td>
                        <td>{{$user->dni}}</td>
                        <td>{{$user->telefono}}</td>
                        <td>{{$user->celular}} </td>
                        <td>{{$user->direccion}} </td>
                        <td>{{$user->rol->nombre}} </td>
                        <td>{{$user->estado}} </td>
                        <td>
                            <a class="btn btn-primary text-white" href="{{route('user.show',$user->id)}}" >
                            Ver
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-success text-white" href=" {{ route('user.edit', $user->id)}} " role="button">
                            Editar
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-danger text-white" href=" # " role="button">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
@endsection