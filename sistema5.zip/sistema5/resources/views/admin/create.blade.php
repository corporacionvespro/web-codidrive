@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar Empresa</div>
      <div class="card-body">
          <form method="POST" action=" {{ route('empresa.store')}}" enctype="multipart/form-data"> 
              {{ csrf_field() }}
               @if (count($errors))
                @foreach ($errors->all() as $item)
                    <p>{{$item}}</p>
                @endforeach
                @endif
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="mombre"><i class="fas fa-hotel"></i></span>
                    </div>
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="nombre  de la empresa" aria-describedby="validationTooltipUsernamePrepend" required>
                  </div>
              </div>
              {{-- <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                  </div>
                  <input class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos" >
                </div>
              </div> --}}
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                  </div>
                  <input class="form-control" id="" type="text" name="email" placeholder="email" >
                </div>
              </div>
              {{-- <div class="col-md-8">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-at"></i></span>
                  </div>
                  <input class="form-control" id="email" type="email" name="email"   placeholder="email ">
                </div>
              </div> --}}
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                  </div>
                  <input class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono">
                </div>
              </div>
              {{-- <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                  </div>
                  <input class="form-control" id="celular" type="text" name="celular"  placeholder="celular">
                </div>
              </div> --}}
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
              </div>
              <input class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">
            </div>
          </div>
          <div class="form-group">
            <div><span>subir imgane para logo</span></div>
            {{-- <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
              </div>
              <input class="form-control" id="logo" name="logo" type="text"   placeholder="dirección">
              <input class="mt-3" name="file" id="file" type="file"  > 
            </div> --}}
            <input class="" name="file" id="file" type="file"  > 
            <img hidden id="imgSalida" width="50%" height="50%" src="" alt=" no ha cargado imagen" />
            {{-- <div id="imgSalida"></div> --}}
          </div>
          
          <button type="submit" class="form-control btn-primary">Registrar</button>
        </form>
      </div>
    </div>
  </div>
   
@endsection  

@section('scripts')
    <script>
      // $(window).load(function(){

        $(function() {
          $('#file').change(function(e) {
            addImage(e); 
          });

          function addImage(e){
            var file = e.target.files[0],
            imageType = /image.*/;
          
            if (!file.type.match(imageType))
              return;
        
            var reader = new FileReader();
            reader.onload = fileOnload;
            reader.readAsDataURL(file);
          }
        
          function fileOnload(e) {
            $('#imgSalida').removeAttr('hidden');
            var result=e.target.result;
            $('#imgSalida').attr("src",result);
            }
          });
        // });

    </script>
@endsection