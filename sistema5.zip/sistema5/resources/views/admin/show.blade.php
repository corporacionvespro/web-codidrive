@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
            <div class="card-header "><i class="fas fa-hotel"></i> empresa: <span class="user">{{$empresa->nombre}}</span></div>
      <div class="card-body">
        <form method="POST" action=" {{ route('empresa.show',$empresa->id)}} ">
                    {{ csrf_field() }}
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-12">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-hotel"></i></span>
                        </div>
                        <label type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required >{{$empresa->nombre}}</label>
                    </div>
                </div>
                
                </div>
            </div>
            
            
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                </div>
                <label class="form-control" id="telefono" name="telefono" type="text"   placeholder="telefono">{{$empresa->telefono}}</label>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                </div>
                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$empresa->direccion}}</label>
                </div>
            </div>
            <div class="form-group">
                {{-- <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-hotel"></i></span>
                </div>
                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$empresa->direccion}}</label>
                </div> --}}
                <div><label for="">Logo de la empresa</label></div>
                <img src="{{asset('storage').'/'.$empresa->logo}}" alt="no hay ">
            </div>
        </form>

        <div>

        </div>
      </div>
    </div>
  </div>
@endsection