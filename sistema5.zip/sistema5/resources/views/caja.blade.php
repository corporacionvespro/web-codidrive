@extends('layouts.admin')

@section('content')

    <div class="col-sm-12 col-md-12 col-12">
        <div class="row mt-3">
            <div class="col-12">
                <div class="card ">
                    <div class="card-header">
                        {{-- <div class="row">
                            <div class="col-sm-6 col-md-6 col-12">
                                <button class="btn" data-toggle="modal" data-target="#fecha"><span><i class="fas fa-calendar-alt"></i></button>
                                <h5 class=" titulo-resumen"><span><i class="fas fa-calendar-alt"></i></h5>
                                <h5 class="titulo-resumen"> </span> Resumen</h5>
                            </div>
                            <div class="col-sm-6 col-md-6 col-12">
                                <label class=" titulo-resumen ">{{ isset($inicio) ? $inicio : date("Y-m-d") }}  :: {{ isset($fin) ? $fin :"" }} </label>
                                <h6 class="card-header  text-right">21-12-2019 a 33-12-2018</h6>
                                <a href="" class="m-3"><i class="fas fa-check"></i></a>
                            </div>
                        </div> --}}
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-12">
                                    <button class="btn" data-toggle="modal" data-target="#fecha"><span><i class="fas fa-calendar-alt"></i></button>
                            </div>
                            <div class="col-md-4 col-sm-4 col-12 text-center">
                                    <strong>Resumen del dia</strong> 
                            </div>
                            <div class="col-md-4 col-sm-4 col-12 text-right">
                                    <label class=" titulo-resumen">{{ isset($inicio) ? $inicio : date("Y-m-d") }}  :: {{ isset($fin) ? $fin :"" }} </label>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">                                   
                        <div class="row justify-content-center text-center">
                            <div class="col-12 col-md-4 col-lg-4 ">
                                <div class="card bg">
                                    <h5 class="text-datos">Caja</h5>
                                    <h2 class="dato">S/. {{$caja}}</h2>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-4 ">
                                <div class="card bg">
                                    <h5 class="text-datos">Ctas Bancarias</h5>
                                    <h2 class="dato">S/. {{$banco}}</h2>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-4 ">
                                <div class="card bg">
                                    <h5 class="text-datos">Combinado</h5>
                                    <h2 class="dato">S/. {{$combinado}} </h2>
                                </div>
                            </div>
                        </div>
                        {{-- <hr> --}}
                        <div class="row mt-2" id="datos">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-right"> Ingresos:</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">S/. {{$ingreso}}</label>
                                    </div>
                                </div>
                            </div> 
                            
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-right"> Depositos:</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">S/.{{$deposito}}</label>
                                    </div>
                                </div>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">                                                                
                                                <i class="fas fa-angle-double-left"> Egreso</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">S/. {{$egreso}}</label>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-left"> Transferencias:</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">
                                            S/. {{$transferencia}}
                                        {{-- S/. 12345678 --}}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
        
    <div class="modal fade" id="fecha" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title titulo" id="exampleModalCenterTitle">Fechas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                {{-- <input type="text" name="daterange" value="" /> --}}
                    <form method="POST" action="{{route('operaciones.cajafecha')}}"> 
                            {{ csrf_field() }}
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 ">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">                                                                
                                                <i class="fas fa-angle-double-left">fecha inicio</i>
                                            </span>
                                        </div>
                                        <input type="date" class="form-control" name="inicio" id="" value="{{ isset($inicio) ? $inicio : date("Y-m-d") }}">
                                    </div>
                                </div>
                            </div> 
                            <div class="col-12 col-sm-12 col-md-12 ">               
                                <div class="form-group">
                                    <div class="input-group" >
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-left"> fecha final:</i>
                                            </span>
                                        </div>
                                        <input type="date" class="form-control" name="fin" id="" value="{{ isset($fin) ? $fin : date("Y-m-d") }}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">OK</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
@endsection