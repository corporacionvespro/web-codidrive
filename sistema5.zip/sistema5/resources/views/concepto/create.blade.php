@extends('layouts.admin')

@section('content')
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar  empresas proveedoras</div>
      <div class="card-body">
        <form method="POST" action=" {{ route('concepto.store')}} "> 
                    {{ csrf_field() }} 
            {{-- <div class="form-group"> --}}
                <div class="form-group ">
                    <div class="input-group {{ $errors->has('nombre') ? 'input-error' : '' }}">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre"><i class="fas fa-user"></i></span>
                        </div>
                    <input class="form-control" id="nombre" name="nombre" type="text"  placeholder="nombre" value="{{old('nombre')}}" >
                    </div>
                    @if ($errors->has('nombre'))
                        <span class="error"><strong>{{ $errors->first('nombre') }}</strong></span>
                    @endif 
                </div>
                <div class="form-group ">
                    <div class="input-group {{ $errors->has('precio') ? 'input-error' : '' }}">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                        </div>
                        <input class="form-control" id="precio" name="precio" type="text"   placeholder="telefono" value="{{old('precio')}}" >
                    </div>
                    @if ($errors->has('precio'))
                        <span class="error"><strong>{{ $errors->first('precio') }}</strong></span>
                    @endif 
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-4">
                            <select class="form-control {{ $errors->has('periodo') ? 'input-error' : '' }}" name="periodo" id="periodo" required="">
                                <option selected value="">Escoger periodo</option>
                                <option value="Diario" {{ old('periodo')=='Diario' ? 'selected' : '' }}>Diario</option>
                                <option value="Semanal"  {{ old('periodo')=='Semanal' ? 'selected' : '' }}>Semanal</option>
                                <option value="Quinsenal" {{ old('periodo')=='Quinsenal' ? 'selected' : '' }}>Quincenal</option>
                                <option value="Mensual" {{ old('periodo')=='Mensual' ? 'selected' : '' }}>Mensual</option>
                                <option value="Unico" {{ old('periodo')=='Unico' ? 'selected' : '' }}>Único</option>
                            </select>
                            @if ($errors->has('periodo'))
                                <span class="error"><strong>{{ $errors->first('periodo') }}</strong></span>
                            @endif 
                        </div>
                    </div>
                </div>
            <button type="submit" class="form-control btn-primary">Registrar</button>
        </form>
      </div>
    </div>
  </div>
@endsection