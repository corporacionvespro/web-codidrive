@extends('layouts.admin')

@section('content')
    <div class="container">
        <div class="card card-register mx-auto">
            <div class="card-header">
                {{$afiliado->nombre}} {{$afiliado->apellido}}
            </div>
            <div class="card-body">
                <form method="POST" action=" {{ route('afiliado.adeudo',$afiliado->id)}} "> 
                        {{ csrf_field() }}
                    <h5 class="card-title">Conceptos a pagar</h5>
                    <input class="form-control" hidden type="text" id="idcliente" name="idcliente" value="{{$afiliado->id}}">
                    @foreach ($conceptos as $concepto )
                        <div class="form-check form-check-inline" id="combo">
                        <input class="form-check-input" type="checkbox" name="concepto[]" id="{{$concepto->id}}" value="{{$concepto->id}}">
                            <label class="form-check-label" for="{{$concepto->id}}">{{$concepto->nombre}}</label>
                            <input class="" type="text" hidden readonly name="concepto2" id="name-{{$concepto->id}}" value="{{$concepto->nombre}}">
                        </div>
                    @endforeach
                    <button type="submit" class="form-control btn-primary">Guardar</button>
                </form>
            </div>
            </div>
    </div>
    hola
@endsection