@extends('layouts.admin')
@section('content')
    <div class="container">
        <div class="card card-register mx-auto">
            <div class="card-header">
                {{$afiliado->nombre}} {{$afiliado->apellido}}
            </div>
            <div class="card-body">
            <form id="formcosto" action="{{route('cliente.concepto',$afiliado->id)}}" method="POST">
                        {{ csrf_field() }} {{-- {{ method_field('PUT') }} --}}
                    <h5 class="card-title">Conceptos a pagar</h5>
                    <input class="form-control" hidden type="text" id="idcliente" name="idcliente" value="{{$afiliado->id}}">
                    @foreach ($conceptos as $concepto )
                        <div class="form-check " id="div-{{$concepto->id}}">
                            @if ($concepto->nombre=='OTROS')
                                <input class="form-check-input chk-concepto" type="checkbox" name="concepto[]" id="check-{{$concepto->id}}" value="{{$concepto->id}}" hidden  checked >
                                <label class="form-check-label " hidden for="{{$concepto->id}}">{{$concepto->nombre}}</label>
                            {{-- <input class="form-control form-control-sm precio" hidden type="text" id="precio-{{$concepto->id}}" name="{{$concepto->periodo}}-{{$concepto->nombre}}"  value="{{ number_format($concepto->precio,2)}}"> --}}
                            @else
                                <input class="form-check-input chk-concepto" type="checkbox" name="concepto[]" id="check-{{$concepto->id}}" value="{{$concepto->id}}">
                                <label class="form-check-label " for="{{$concepto->id}}">{{$concepto->nombre}}</label>
                            {{-- <input hidden class="form-control form-control-sm precio" type="text" id="precio-{{$concepto->id}}" name="{{$concepto->periodo}}-{{$concepto->nombre}}"  value="{{ number_format($concepto->precio,2)}}"> --}}
                            @endif
                        </div>
                    @endforeach
                    <button type="submit" class="form-control btn-primary">Registrar</button>
                </form>
            </div>
            </div>
    </div>
@endsection