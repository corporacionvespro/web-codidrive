@extends('layouts.admin')
@section('content')
{{-- <div class="container"> --}}
    <div class="img">

            <div class="modal-dialog h text-center">
                    <div class="col-sm-7 main-section">
                        <div class="modal-content h">
                            <div class="col-12 user-img">
                                <img src="{{asset('img/user.png')}}" alt="">
                            </div>
                            <h1 class="home b">Bienvenido </h1>
                            <h1 class="home"> {{ Auth::user()->name }}  {{ Auth::user()->apellido }}</h1>
                        </div>
                    </div>
            
                </div>


        {{-- <div class="row justify-content-md-left">
            <div class="col-6 mt-5">
                <h1 class="home">Bienvenido </h1>
                <h1 class="home"> {{ Auth::user()->name }}  {{ Auth::user()->apellido }}</h1>
            </div>
            
        </div> --}}
        {{-- <div class="row">
            <div class="col-6">
                <img class="img-logo " src="{{asset('img/logo3.png')}}" alt="">
            </div>
        </div> --}}
    </div>
{{-- </div> --}}
    
@endsection