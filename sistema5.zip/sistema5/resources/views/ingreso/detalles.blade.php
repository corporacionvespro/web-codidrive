{{-- <form method="POST" action="{{route('operaciones.cajafecha')}}">  --}}
        {{ csrf_field() }}
        {{-- <div class="card mx-auto mt-2"> --}}
            <div class="card-body pt-0" >                                
               {{-- <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                                </div>
                                <label type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required > hola palo</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                                </div>
                                <label class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos" > hola palo</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                                </div>
                                <label class="form-control" id="dni" type="text" name="dni" placeholder="DNI"> hola palo</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                                </div>
                                <label class="form-control" id="email" type="text" name="unidad"   placeholder="N° de unidad ">  hola palo</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                                </div>
                                <label class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono"> hola palo</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                                </div>
                                <label class="form-control" id="celular" type="text" name="celular"  placeholder="celular"> hola palo</label>
                            </div>
                        </div>
                    </div>
               </div> --}}
               @if (isset($ingreso))
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Tipo</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$ingreso->tipo}}</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Unidad</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> {{$ingreso->cliente->nombre}} {{$ingreso->cliente->apellido}}</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Afiliado</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> palomino vega </label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">N° Doc</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$ingreso->numdoc}}</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Concepto</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$ingreso->descripcion}}</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Total</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{$ingreso->total}}</label>
                    </div>
                </div>    
               @else
            @endif

            </div>
        {{-- </div> --}}
        {{-- </form> --}}