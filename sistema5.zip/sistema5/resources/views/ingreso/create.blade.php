
@extends('layouts.admin')

@section('content')
<div class="">


<div class="row my-2 justify-content-center">
        <?=session('mensaje','')?>
    <div class="col-sm-12 col-md-6 ingreso">
        <form method="POST" action=" {{ route('ingreso.store')}} "> 
            {{ csrf_field() }}
            <div class="row">
               {{--  @if (count($errors))
                @foreach ($errors->all() as $item)
                    <p>{{$item}}</p>
                @endforeach
                @endif --}}
                <div class="form-group col-12 col-sm-12 col-md-12" id="divtipo">
                    <label for="tipo">Tipo operación</label>
                    <select class="form-control {{ $errors->has('tipo') ? 'input-error' : '' }}" name="tipo" id="tipo"  value="{{ old('tipo') }}">
                        <option selected value="">Tipo operación</option>
                        <option value="Ingreso" {{ old('tipo')=='Ingreso' ? 'selected' : '' }}>Ingreso</option>
                        <option value="Egreso" {{ old('tipo')=='Egreso' ? 'selected' : '' }} >Egreso</option>
                        <option value="Deposito" {{ old('tipo')=='Deposito' ? 'selected' : '' }} >Depósito</option>
                        <option value="Transferencia" {{ old('tipo')=='Transferencia' ? 'selected' : '' }}>Transferencia</option>
                    </select>
                    @if ($errors->has('tipo'))
                        <span class="error">
                            <strong>{{ $errors->first('tipo') }}</strong>
                        </span>
                    @endif
                </div>
                <div class="col-12 col-sm-12 col-md-4 " hola  id="divunidad" >
                    <div class="form-group">
                        <label id="alias" for="cliente">Unidad</label>
                        <input type="text" name="cliente" class="form-control {{ $errors->has('cliente') ? 'input-error' : '' }}" id="cliente" autocomplete="off" value="{{ old('cliente') }}">
                        <div class="dropdown-menu combo"  id="clienteList"></div>                            
                    </div>
                    @if ($errors->has('cliente'))
                        <span class = "error"><strong>{{ $errors->first('cliente') }}</strong></span>
                    @endif
                </div> 

                 {{-- <p>Start typing:</p> --}}

                    <!--Make sure the form has the autocomplete function switched off:-->
                    {{-- <form autocomplete="off" action="/action_page.php"> --}}
                    {{-- <div class="autocomplete" style="width:300px;">
                        <input id="myInput" type="text" name="myCountry" placeholder="Country">
                    </div> --}}
                    {{-- <input type="submit"> --}}
                {{-- </form> --}}

                <div class="col-12 col-sm-12 col-md-8" hola  id="divcliente">
                    <div class="form-group">
                        <label for="cliente">Afiliado</label>
                        <input type="text" name="cliente2"  class="form-control {{ $errors->has('cliente2') ? 'input-error' : '' }}" id="cliente2" autocomplete="off" readonly value="{{ old('cliente2') }}">
                        @if ($errors->has('cliente2'))
                            <span class="error"><strong>{{ $errors->first('cliente2') }}</strong></span>
                        @endif
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-8" hidden>
                    <div class="form-group">
                        <input type="text" name="idcliente" class="form-control" id="idcliente" readonly value="{{ old('idcliente') }}">
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-12"hola   id="divnumdoc" >
                    <div class="form-group ">
                        <label for="nombre">N° Documento</label>
                        <input type="text" name="numdoc"  class="form-control {{ $errors->has('numdoc') ? 'input-error' : '' }}" id="numdoc" value="{{ old('numdoc') }}">
                        @if ($errors->has('numdoc'))
                            <span class="error"><strong>{{ $errors->first('numdoc') }}</strong></span>
                        @endif
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-12"hola   id="divconcepto">
                    <div class="form-group" >
                        <label for="tipo">Conceptos a pagar</label>
                        <select class="form-control {{ $errors->has('concepto') ? 'input-error' : '' }}" name="concepto" id="select-concepto">
                            <option selected value="">Elija concepto</option>
                        </select>
                        @if ($errors->has('concepto'))
                            <span class="error">
                                <strong>{{ $errors->first('concepto') }}</strong>
                            </span>
                        @endif
                    </div>    
                </div> 
                <div class="col-12 col-sm-12 col-md-12" j  id="divdescripcion2">
                    <div class="form-group">
                        <label for="descripcion">Descripción</label>
                        {{-- <textarea class="form-control" rows="2" name="descripcion2" aria-label="With textarea"></textarea> --}}
                        <input class="form-control {{ $errors->has('descripcion2') ? 'input-error' : '' }}" id="descripcion2" name="descripcion2" autocomplete="off" value="{{ old('descripcion2') }}" >
                    </div>
                    @if ($errors->has('descripcion2'))
                        <span class="error"><strong>{{ $errors->first('descripcion2') }}</strong></span>
                    @endif
                </div> 
                <div class="col-12 col-sm-12 col-md-12"hola   id="otro_concepto"></div> 
                <div class="col-12 col-sm-12 col-md-12 "hola  j id="divmonto">
                    <div class="form-group">
                        <label for="descripcion">total</label>
                        <input class="form-control {{ $errors->has('total') ? 'input-error' : '' }}" id="total" name="total" value="{{ old('total') }}">
                    </div>
                    @if ($errors->has('total'))
                        <span class="error"><strong>{{ $errors->first('total') }}</strong></span>
                    @endif
                </div>                          
            </div>
            {{-- <div class="row" id="precio-otros" hidden>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="total">Total a Pagar</label>
                    <input type="text" name="montototal" class="form-control" id="montototal" placeholder="S/. 0.00" >
                </div>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="acuenta">Pagó </label>
                    <input type="text" name="total2" class="form-control" id="total2" value="0.00"  >
                </div>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="saldo">Saldo</label>
                    <input type="text" name="saldo" class="form-control" id="saldo" placeholder="S/. 0.00" readonly >
                </div> 
            </div> --}}
            <div class="row justify-content-center"hola  id="button">
                <div class="col-11 col-sm-11 col-md-11">
                    <button type="submit" class="btn btn-success my-3 btn-lg btn-block">Guardar</button>
                    {{-- <button type="submit" class="btn btn-success my-3 btn-lg btn-block" data-toggle="modal" data-target="#fecha">Guardar</button> --}}
                </div>                
            </div>
        </form>
    </div>
</div>
{{-- <button class="btn" data-toggle="modal" data-target="#fecha"><span><i class="fas fa-calendar-alt"></i></button> --}}
<div class="modal fade" id="fecha" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="mx-4 text-center">
                <label class="pt-2">Resumen del registro </label> 
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
                {{-- <form method="POST" action="{{route('operaciones.cajafecha')}}">  --}}
                        {{ csrf_field() }}
                {{-- <div class="card mx-auto mt-2"> --}}
                    <div class="card-body pt-0" >                                
                        {{-- <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                                        </div>
                                        <label type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required > hola palo</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                                        </div>
                                        <label class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos" > hola palo</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                                        </div>
                                        <label class="form-control" id="dni" type="text" name="dni" placeholder="DNI"> hola palo</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                                        </div>
                                        <label class="form-control" id="email" type="text" name="unidad"   placeholder="N° de unidad ">  hola palo</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="form-row">
                                <div class="col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                                        </div>
                                        <label class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono"> hola palo</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                                        </div>
                                        <label class="form-control" id="celular" type="text" name="celular"  placeholder="celular"> hola palo</label>
                                    </div>
                                </div>
                            </div>
                        </div> --}}
                        {{-- <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Tipo</span>
                                </div>
                            <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">{{ isset($ingreso) ? $ingreso : '' }}</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Unidad</span>
                                </div>
                                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> 0002</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Afiliado</span>
                                </div>
                                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> palomino vega </label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">N° Doc</span>
                                </div>
                                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> N°-E 00001</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Concepto</span>
                                </div>
                                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> Gps</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Total</span>
                                </div>
                                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">S/. 12</label>
                            </div>
                        </div> --}}
                    </div>
                {{-- </div> --}}
                {{-- </form> --}}
                @include('ingreso.detalles');
        </div>
    </div>
</div>
</div>
@endsection
@section('scripts')
<script>
    $(document).ready(function(){

        if($('#tipo').val()==''){
            $('#divcliente').attr('hidden','hidden');
            $('#divunidad label').text('Distinatario');
            $('#divunidad').removeClass('col-md-4');
        }
        if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
            $('#divcliente').attr('hidden','hidden');
            $('#divunidad label').text('Proveedor');
            $('#divunidad').removeClass('col-md-4');
            $('#divunidad').addClass('col-md-12');
            $('#divconcepto').attr('hidden', 'hidden');
            
            console.log($('#divunidad label').text());
        }

        
    });

     $("#tipo").change(function(){
        if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
            $('#divcliente').attr('hidden','hidden');
            $('#divunidad label').text('Proveedor');
            $('#divunidad').removeClass('col-md-4');
            $('#divunidad').addClass('col-md-12');
            $('#divconcepto').attr('hidden', 'hidden');
            $('#unidad').val('');
            $('cliente2').val('');

            console.log($('#divunidad label').text());
        }
        if($('#tipo').val()=='Ingreso' || $('#tipo').val()=='Deposito'){
            $('#divcliente').removeAttr('hidden');
            $('#divunidad label').text('Afiliado');
            $('#divunidad').removeClass('col-md-12');
            $('#divunidad').addClass('col-md-4');
            $('#divconcepto').removeAttr('hidden');
            console.log($('#divunidad label').text());
        }
    })

    $("#tipo").change(function(){
        var _token = $('input[name="_token"]').val();
        $.ajax({
            url:"{{route('numdoc.buscar')}}", 
            method:"POST",
            data:{
                _token:_token
                // '_token':'{{ Session::token() }}'
            },
            success:function(data){
                console.log(data);
                if($('#tipo').val()=='Deposito' || $('#tipo').val()=='Ingreso'){
                    $('#numdoc').val(data['numdoci']);
                }
                if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
                    $('#numdoc').val(data['numdoce']);
                }
            }
        });

      /*   if($('#tipo').val()=='Deposito' || $('#tipo').val()=='Ingreso'){

            $("#divconcepto").change(function(){

                var option=($('#concepto option:selected').html());
                if(option=='OTROS'){
                    $('#precio-otros').removeAttr('hidden');
                    $('#divdescripcion2').removeAttr('hidden');
                    $('#divmonto').attr('hidden', 'hidden');
                }       

                if(option!='OTROS'){
                    $('#precio-otros').attr('hidden', 'hidden');
                    $('#divdescripcion2').attr('hidden', 'hidden');
                    $('#divmonto').removeAttr('hidden');
                }
            })
        
            $("#precio-otros").change(function(){
                var montototal=parseFloat($('#montototal').val()); 
                var total=parseFloat($('#total2').val());
                $('#saldo').val(montototal-total);
                if (total>montototal) {
                    $('#saldo').val(montototal);
                    ($('#total2').val('0.00'));
                    $('#saldo').val(montototal);
                }
            })
        }if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
            $('#precio-otros').removeAttr('hidden');
            $('#divdescripcion2').removeAttr('hidden');
            $('#divmonto').attr('hidden', 'hidden');
        } */
    });

/* buscar afiliados o proveedores */ 
    $('#cliente').keyup(function(event){ 
        var query = $(this).val();
        console.log(query);
        var url="{{route('afiliado.buscar') }}";
        ;
        if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
            url="{{route('proveedor.buscar') }}"
            console.log('hola egreso');
        }

        if(query != ''){
          var _token = $('input[name="_token"]').val();
          $.ajax({
              url:url, 
              method:"POST",
              data:{
                  query:query, 
                  _token:_token
                  // '_token':'{{ Session::token() }}'
              },
              success:function(data){
                  $('#clienteList').fadeIn();  
                  $('#clienteList').html(data);
              }
          });
        }
    });

    $('#clienteList').on('click', 'li', function(){  
        $('#cliente').val($(this).text());                  
        $('#clienteList').fadeOut();
        var cliente = $(this).attr("nombre");
        $('#cliente2').val(cliente);
        $('#idcliente').val($(this).attr('id'));
    }); 

   /*  $('#descripcion2').keyup(function(event){ 
        var query = $(this).val();
        var id= $('#idcliente').val();
        // console.log(query);
        // console.log(id);
        if(query != ''){
          var _token = $('input[name="_token"]').val();
          $.ajax({
              url:"{{route('otros_concepto.buscar') }}", 
              method:"POST",
              data:{
                  query:query, 
                  _token:_token,
                  id:id,
                  // '_token':'{{ Session::token() }}'
              },
              success:function(data){
                  $('#otro_concepto').fadeIn();  
                  $('#otro_concepto').html(data);
                //   console.log(data);
              }
          });
        }
    });

    $('#otro_concepto').on('click', 'li', function(){  
        $('#descripcion2').val($(this).text());                  
        $('#otro_concepto').fadeOut();

        var array = $(this).attr("nombre");
        var array2= array.split('?');
        var total=array2[0];
        var saldo=array2[1];
        $('#montototal').val(total);
        $('#montototal').attr('disabled','disabled');
        $('#saldo').val(saldo);
        
    });

    $('#descripcion2').change(function(){
        $('#montototal').val('');
        $('#montototal').removeAttr('disabled');
        $('#saldo').val('');
        $('#total2').val('');
    }); */

$('#modal-resumen').modal('show');
$('#modal-resumen').on('hidden.bs.modal', function () { location.reload(); }) 
</script>

<script>
        function autocomplete(inp, arr) {
          /*the autocomplete function takes two arguments,
          the text field element and an array of possible autocompleted values:*/
          var currentFocus;
          /*execute a function when someone writes in the text field:*/
          inp.addEventListener("input", function(e) {
              var a, b, i, val = this.value;
              /*close any already open lists of autocompleted values*/
              closeAllLists();
              if (!val) { return false;}
              currentFocus = -1;
              /*create a DIV element that will contain the items (values):*/
              a = document.createElement("DIV");
              a.setAttribute("id", this.id + "autocomplete-list");
              a.setAttribute("class", "autocomplete-items");
              /*append the DIV element as a child of the autocomplete container:*/
              this.parentNode.appendChild(a);
              /*for each item in the array...*/
              for (i = 0; i < arr.length; i++) {
                /*check if the item starts with the same letters as the text field value:*/
                if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                  /*create a DIV element for each matching element:*/
                  b = document.createElement("DIV");
                  /*make the matching letters bold:*/
                  b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
                  b.innerHTML += arr[i].substr(val.length);
                  /*insert a input field that will hold the current array item's value:*/
                  b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
                  /*execute a function when someone clicks on the item value (DIV element):*/
                  b.addEventListener("click", function(e) {
                      /*insert the value for the autocomplete text field:*/
                      inp.value = this.getElementsByTagName("input")[0].value;
                      /*close the list of autocompleted values,
                      (or any other open lists of autocompleted values:*/
                      closeAllLists();
                  });
                  a.appendChild(b);
                }
              }
          });
          /*execute a function presses a key on the keyboard:*/
          inp.addEventListener("keydown", function(e) {
              var x = document.getElementById(this.id + "autocomplete-list");
              if (x) x = x.getElementsByTagName("div");
              if (e.keyCode == 40) {
                /*If the arrow DOWN key is pressed,
                increase the currentFocus variable:*/
                currentFocus++;
                /*and and make the current item more visible:*/
                addActive(x);
              } else if (e.keyCode == 38) { //up
                /*If the arrow UP key is pressed,
                decrease the currentFocus variable:*/
                currentFocus--;
                /*and and make the current item more visible:*/
                addActive(x);
              } else if (e.keyCode == 13) {
                /*If the ENTER key is pressed, prevent the form from being submitted,*/
                e.preventDefault();
                if (currentFocus > -1) {
                  /*and simulate a click on the "active" item:*/
                  if (x) x[currentFocus].click();
                }
              }
          });
          function addActive(x) {
            /*a function to classify an item as "active":*/
            if (!x) return false;
            /*start by removing the "active" class on all items:*/
            removeActive(x);
            if (currentFocus >= x.length) currentFocus = 0;
            if (currentFocus < 0) currentFocus = (x.length - 1);
            /*add class "autocomplete-active":*/
            x[currentFocus].classList.add("autocomplete-active");
          }
          function removeActive(x) {
            /*a function to remove the "active" class from all autocomplete items:*/
            for (var i = 0; i < x.length; i++) {
              x[i].classList.remove("autocomplete-active");
            }
          }
          function closeAllLists(elmnt) {
            /*close all autocomplete lists in the document,
            except the one passed as an argument:*/
            var x = document.getElementsByClassName("autocomplete-items");
            for (var i = 0; i < x.length; i++) {
              if (elmnt != x[i] && elmnt != inp) {
                x[i].parentNode.removeChild(x[i]);
              }
            }
          }
          /*execute a function when someone clicks in the document:*/
          document.addEventListener("click", function (e) {
              closeAllLists(e.target);
          });
        }
        
        /*An array containing all the country names in the world:*/
        var countries = ["Afghanistan","Albania","Algeria","Andorra","Angola","Anguilla","Antigua & Barbuda","Argentina","Armenia","Aruba","Australia","Austria","Azerbaijan","Bahamas","Bahrain","Bangladesh","Barbados","Belarus","Belgium","Belize","Benin","Bermuda","Bhutan","Bolivia","Bosnia & Herzegovina","Botswana","Brazil","British Virgin Islands","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Cayman Islands","Central Arfrican Republic","Chad","Chile","China","Colombia","Congo","Cook Islands","Costa Rica","Cote D Ivoire","Croatia","Cuba","Curacao","Cyprus","Czech Republic","Denmark","Djibouti","Dominica","Dominican Republic","Ecuador","Egypt","El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Falkland Islands","Faroe Islands","Fiji","Finland","France","French Polynesia","French West Indies","Gabon","Gambia","Georgia","Germany","Ghana","Gibraltar","Greece","Greenland","Grenada","Guam","Guatemala","Guernsey","Guinea","Guinea Bissau","Guyana","Haiti","Honduras","Hong Kong","Hungary","Iceland","India","Indonesia","Iran","Iraq","Ireland","Isle of Man","Israel","Italy","Jamaica","Japan","Jersey","Jordan","Kazakhstan","Kenya","Kiribati","Kosovo","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Luxembourg","Macau","Macedonia","Madagascar","Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Micronesia","Moldova","Monaco","Mongolia","Montenegro","Montserrat","Morocco","Mozambique","Myanmar","Namibia","Nauro","Nepal","Netherlands","Netherlands Antilles","New Caledonia","New Zealand","Nicaragua","Niger","Nigeria","North Korea","Norway","Oman","Pakistan","Palau","Palestine","Panama","Papua New Guinea","Paraguay","Peru","Philippines","Poland","Portugal","Puerto Rico","Qatar","Reunion","Romania","Russia","Rwanda","Saint Pierre & Miquelon","Samoa","San Marino","Sao Tome and Principe","Saudi Arabia","Senegal","Serbia","Seychelles","Sierra Leone","Singapore","Slovakia","Slovenia","Solomon Islands","Somalia","South Africa","South Korea","South Sudan","Spain","Sri Lanka","St Kitts & Nevis","St Lucia","St Vincent","Sudan","Suriname","Swaziland","Sweden","Switzerland","Syria","Taiwan","Tajikistan","Tanzania","Thailand","Timor L'Este","Togo","Tonga","Trinidad & Tobago","Tunisia","Turkey","Turkmenistan","Turks & Caicos","Tuvalu","Uganda","Ukraine","United Arab Emirates","United Kingdom","United States of America","Uruguay","Uzbekistan","Vanuatu","Vatican City","Venezuela","Vietnam","Virgin Islands (US)","Yemen","Zambia","Zimbabwe"];
        
        /*initiate the autocomplete function on the "myInput" element, and pass along the countries array as possible autocomplete values:*/
        autocomplete(document.getElementById("myInput"), countries);
        </script>

@endsection