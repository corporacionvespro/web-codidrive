<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar Empresa</div>
      <div class="card-body">
          <form method="POST" action=" <?php echo e(route('empresa.store')); ?>" enctype="multipart/form-data"> 
              <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="mombre"><i class="fas fa-hotel"></i></span>
                    </div>
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="nombre  de la empresa" aria-describedby="validationTooltipUsernamePrepend" required>
                  </div>
              </div>
              
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                  </div>
                  <input class="form-control" id="" type="text" name="email" placeholder="email" >
                </div>
              </div>
              
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                  </div>
                  <input class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono">
                </div>
              </div>
              
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
              </div>
              <input class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">
            </div>
          </div>
          <div class="form-group">
            <div><span>subir imgane para logo</span></div>
            
            <input class="" name="file" id="file" type="file"  > 
            <img hidden id="imgSalida" width="50%" height="50%" src="" alt=" no ha cargado imagen" />
            
          </div>
          
          <button type="submit" class="form-control btn-primary">Registrar</button>
        </form>
      </div>
    </div>
  </div>
   
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('scripts'); ?>
    <script>
      // $(window).load(function(){

        $(function() {
          $('#file').change(function(e) {
            addImage(e); 
          });

          function addImage(e){
            var file = e.target.files[0],
            imageType = /image.*/;
          
            if (!file.type.match(imageType))
              return;
        
            var reader = new FileReader();
            reader.onload = fileOnload;
            reader.readAsDataURL(file);
          }
        
          function fileOnload(e) {
            $('#imgSalida').removeAttr('hidden');
            var result=e.target.result;
            $('#imgSalida').attr("src",result);
            }
          });
        // });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>