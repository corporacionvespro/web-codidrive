<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Actualizar concepto de egreso</div>
      <div class="card-body">
        <form method="POST" action=" <?php echo e(route('concepto_egreso.update',$concepto)); ?> "> 
                    <?php echo e(csrf_field()); ?> <?php echo e(method_field('PUT')); ?>

            <div class="form-group">
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-user"></i></span>
                </div>
                <input class="form-control" id="nombre" name="nombre" type="text"   value="<?php echo e($concepto->nombre); ?>" >
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                </div>
                <input class="form-control" id="precio" name="precio" type="text"   placeholder="telefono" value="<?php echo e($concepto->precio); ?>" >
                </div>
            </div>
            <div class="form-group">
                    <label for="estado">Estado</label>
                    <select class="form-control" name="periodo" id="periodo" required="">
                        <?php
                        $variable = array('Diario','Semanal','Quinsenal','Mensual','Unico');
                      
                        foreach ($variable as $tipo) {
                            echo '<option value="' .$tipo. '" ';
                            if( $concepto->periodo == $tipo){
                                echo 'selected';
                            } 
                            echo ' > ' . $tipo . '</option>';
                            }
                    ?>
                    </select>
            </div>

            <button type="submit" class="form-control btn-primary">Guardar cambios</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>