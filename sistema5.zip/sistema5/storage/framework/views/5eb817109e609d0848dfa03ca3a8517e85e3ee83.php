<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar  concepto de egreso</div>
      <div class="card-body">
        <form method="POST" action=" <?php echo e(route('concepto_egreso.store')); ?> "> 
            <?php echo e(csrf_field()); ?> 
            <div class="form-group ">
                <div class="input-group <?php echo e($errors->has('nombre') ? 'input-error' : ''); ?>">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user"></i></span>
                    </div>
                <input class="form-control" id="nombre" name="nombre" type="text"  placeholder="nombre" value="<?php echo e(old('nombre')); ?>" >
                </div>
                <?php if($errors->has('nombre')): ?>
                    <span class="error"><strong><?php echo e($errors->first('nombre')); ?></strong></span>
                <?php endif; ?> 
            </div>
            <div class="form-group ">
                <div class="input-group <?php echo e($errors->has('precio') ? 'input-error' : ''); ?>">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <input class="form-control" id="precio" name="precio" type="text"   placeholder="telefono" value="<?php echo e(old('precio')); ?>" >
                </div>
                <?php if($errors->has('precio')): ?>
                    <span class="error"><strong><?php echo e($errors->first('precio')); ?></strong></span>
                <?php endif; ?> 
            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-4">
                        <select class="form-control <?php echo e($errors->has('periodo') ? 'input-error' : ''); ?>" name="periodo" id="periodo" required="">
                            <option selected value="">Escoger periodo</option>
                            <option value="Diario" <?php echo e(old('periodo')=='Diario' ? 'selected' : ''); ?>>Diario</option>
                            <option value="Semanal"  <?php echo e(old('periodo')=='Semanal' ? 'selected' : ''); ?>>Semanal</option>
                            <option value="Quinsenal" <?php echo e(old('periodo')=='Quinsenal' ? 'selected' : ''); ?>>Quincenal</option>
                            <option value="Mensual" <?php echo e(old('periodo')=='Mensual' ? 'selected' : ''); ?>>Mensual</option>
                            <option value="Unico" <?php echo e(old('periodo')=='Unico' ? 'selected' : ''); ?>>Único</option>
                        </select>
                        <?php if($errors->has('periodo')): ?>
                            <span class="error"><strong><?php echo e($errors->first('periodo')); ?></strong></span>
                        <?php endif; ?> 
                    </div>
                </div>
            </div>
            <button type="submit" class="form-control btn-primary">Registrar</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>