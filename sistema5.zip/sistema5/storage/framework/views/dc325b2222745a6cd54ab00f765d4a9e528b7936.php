<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Modificar afiliado</div>
      <div class="card-body">
        <form method="POST" action=" <?php echo e(route('afiliado.update',$afiliado)); ?> "> 
                    <?php echo e(csrf_field()); ?> <?php echo e(method_field('PUT')); ?>

                
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                            </div>
                            <input type="text" class="form-control <?php echo e($errors->has('nombre') ? 'input-error' : ''); ?>" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required  value=<?php echo e($afiliado->nombre); ?>  value="<?php echo e(old('nombre')); ?>">
                        </div>
                        <?php if($errors->has('nombre')): ?>
                            <span class="error"><strong><?php echo e($errors->first('nombre')); ?></strong></span>
                        <?php endif; ?>   
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                            </div>
                                <input class="form-control<?php echo e($errors->has('apellido') ? 'input-error' : ''); ?>"  id="apellido"  name="apellido" type="text" placeholder="apellidos"  value=<?php echo e($afiliado->apellido); ?>>
                        </div>
                        <?php if($errors->has('apellido')): ?>
                            <span class="error"><strong><?php echo e($errors->first('apellido')); ?></strong></span>
                        <?php endif; ?>   
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                            </div>
                            <input class="form-control <?php echo e($errors->has('dni') ? 'input-error' : ''); ?>" id="dni" type="text" name="dni" placeholder="DNI" value="<?php echo e($afiliado->dni); ?>" >
                        </div>
                        <?php if($errors->has('dni')): ?>
                            <span class="error"><strong><?php echo e($errors->first('dni')); ?></strong></span>
                        <?php endif; ?>   
                    </div>
                    <div class="col-md-6">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                            </div>
                            <input class="form-control <?php echo e($errors->has('unidad') ? 'input-error' : ''); ?>" id="email" type="text" name="unidad"   placeholder="N° de unidad " value="<?php echo e($afiliado->unidad); ?>">
                        </div>
                        <?php if($errors->has('unidad')): ?>
                            <span class="error"><strong><?php echo e($errors->first('unidad')); ?></strong></span>
                        <?php endif; ?>   
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <input class="form-control <?php echo e($errors->has('telefono') ? 'input-error' : ''); ?>" id="telefono" type="text" name="telefono"   placeholder="telefono" value=<?php echo e($afiliado->telefono); ?> >
                    </div>
                    <?php if($errors->has('telefono')): ?>
                    <span class="error"><strong><?php echo e($errors->first('telefono')); ?></strong></span>
                <?php endif; ?>   
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                    </div>
                    <input class="form-control <?php echo e($errors->has('celular') ? 'input-error' : ''); ?>" id="celular" type="text" name="celular"  placeholder="celular" value=<?php echo e($afiliado->celular); ?>>
                    </div>
                    <?php if($errors->has('celular')): ?>
                    <span class="error"><strong><?php echo e($errors->first('celular')); ?></strong></span>
                <?php endif; ?>   
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                    </div>
                    <input class="form-control <?php echo e($errors->has('direccion') ? 'input-error' : ''); ?>" id="direccion" name="direccion" type="text"   placeholder="dirección" value=<?php echo e($afiliado->direccion); ?>>
                </div>
                <?php if($errors->has('direccion')): ?>
                    <span class="error"><strong><?php echo e($errors->first('direccion')); ?></strong></span>
                <?php endif; ?>   
            </div>
            <button type="submit" class="form-control btn-primary">Guardar</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>