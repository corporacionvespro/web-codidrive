<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar usuario</div>
      <div class="card-body">
          <form method="POST" action=" <?php echo e(route('user.store')); ?> "> 
              <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                    </div>
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipUsernamePrepend" required>
                  </div>
              </div>
              <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                  </div>
                  <input class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos" >
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                  </div>
                  <input class="form-control" id="dni" type="text" name="dni" placeholder="DNI" >
                </div>
              </div>
              <div class="col-md-8">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-at"></i></span>
                  </div>
                  <input class="form-control" id="email" type="email" name="email"   placeholder="email ">
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                  </div>
                  <input class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono">
                </div>
              </div>
              <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                  </div>
                  <input class="form-control" id="celular" type="text" name="celular"  placeholder="celular">
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="input-group">
              <div class="input-group-prepend">
                <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
              </div>
              <input class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección">
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                  </div>
                  <input class="form-control" id="contrasenia" name="contrasenia" type="password"  placeholder="contraseña ">
                </div>
              </div>
              <div class="col-md-6">
                <div class="input-group">
                  <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-key"></i></span>
                  </div>
                <input class="form-control" id="confcontrasenia" name="confcontrasenia" type="password"  placeholder="Confirmar contraseña">
                </div>
              </div>
            </div>

          </div>
          <div class="form-group">
            <select class="form-control" name="tipo_usuario" id="tipo_usuario" required="">
              <option selected value="">Escoger tipo de usuario</option>
              <option value="1">Administrador</option>
              <option value="2">Gerente</option>
              <option value="3">Operador</option>
            </select>
          </div>
          <button type="submit" class="form-control btn-primary">Registrar</button>
        </form>
      </div>
    </div>

    
  </div>
   
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>