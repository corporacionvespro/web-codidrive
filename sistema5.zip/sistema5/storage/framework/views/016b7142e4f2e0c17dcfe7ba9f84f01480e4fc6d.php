<?php $__env->startSection('content'); ?>
<div class="container">
    
    
    <div class="card mb-3">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-4 col-sm-4 col-12">
                            <button class="btn" data-toggle="modal" data-target="#fecha"><span><i class="fas fa-calendar-alt"></i></button>
                    </div>
                    <div class="col-md-4 col-sm-4 col-12 text-center">
                            <strong>Lista de transferencias bancarias</strong> 
                    </div>
                    <div class="col-md-4 col-sm-4 col-12 text-right">
                            <label class=" titulo-resumen"><?php echo e(isset($inicio) ? $inicio : date("Y-m-d")); ?>  :: <?php echo e(isset($fin) ? $fin :""); ?> </label>
                    </div>
                </div>
            </div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Num Doc</th>
                        <th scope="col">Fecha </th>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Total</th>
                        <th scope="col">Tipo</th>
                        <th scope="col">Afiliado</th>
                        <th scope="col">Usuario</th>
                        

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $transferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transferencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($transferencia->numdoc); ?></td>
                        <td><?php echo e($transferencia->fecha); ?> </td>
                        <td class="concepto"><?php echo e($transferencia->descripcion); ?> </td>
                        <td><?php echo e($transferencia->total); ?></td>
                        <td><?php echo e($transferencia->tipo); ?></td>
                        <td><?php echo e($transferencia->proveedor->nombre); ?></td>
                        
                        <td><?php echo e($transferencia->user_id); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="fecha" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title titulo" id="exampleModalCenterTitle">Fechas</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            
                <form method="POST" action="<?php echo e(route('operaciones.transferenciasfecha')); ?>"> 
                        <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-12 ">               
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text ">                                                                
                                            <i class="fas fa-angle-double-left">fecha inicio</i>
                                        </span>
                                    </div>
                                    <input type="date" class="form-control" name="inicio" id="" value="<?php echo e(isset($inicio) ? $inicio : date("Y-m-d")); ?>">
                                </div>
                            </div>
                        </div> 
                        <div class="col-12 col-sm-12 col-md-12 ">               
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text ">
                                            <i class="fas fa-angle-double-left"> fecha final:</i>
                                        </span>
                                    </div>
                                    <input type="date" class="form-control" name="fin" id="" value="<?php echo e(isset($fin) ? $fin : date("Y-m-d")); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">OK</button>
                    </div>
                </form>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
     $( document ).ready(function() {
        $('.concepto').each(function() {
        var text = $(this).text();
        text=text.replace(/\?/g," ");
        $(this).text(text);
        // console.log(text);
    });
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>