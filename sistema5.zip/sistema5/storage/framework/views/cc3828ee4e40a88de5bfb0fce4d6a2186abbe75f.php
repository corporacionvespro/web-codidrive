<?php $__env->startSection('content'); ?>

    <div class="img">

            <div class="modal-dialog h text-center">
                    <div class="col-sm-7 main-section">
                        <div class="modal-content h">
                            <div class="col-12 user-img">
                                <img src="<?php echo e(asset('img/user.png')); ?>" alt="">
                            </div>
                            <h1 class="home b">Bienvenido </h1>
                            <h1 class="home"> <?php echo e(Auth::user()->name); ?>  <?php echo e(Auth::user()->apellido); ?></h1>
                        </div>
                    </div>
            
                </div>


        
        
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>