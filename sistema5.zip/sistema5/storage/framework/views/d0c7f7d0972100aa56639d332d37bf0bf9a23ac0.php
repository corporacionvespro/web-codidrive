<?php $__env->startSection('content'); ?>
<div class="row my-2 justify-content-center">
    <div class="col-sm-12 col-md-6 ">
        <form method="POST" action=" <?php echo e(route('ingreso.store')); ?> "> 
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="form-group col-12 col-sm-12 col-md-12" id="divtipo">
                    <label for="tipo">Tipo operación</label>
                    <select class="form-control" name="tipo" id="tipo" required="">
                        <option selected value="">Tipo operación</option>
                        <option value="Ingreso">Ingreso</option>
                        <option value="Egreso">Egreso</option>
                        <option value="Deposito">Deposito</option>
                        <option value="Transferencia">Transferencia</option>
                    </select>
                </div>
                <div class="col-12 col-sm-12 col-md-4" hola  id="divunidad" >
                    <div class="form-group">
                        <label id="alias" for="cliente">Unidad</label>
                        <input type="text" name="cliente" class="form-control" id="cliente" autocomplete="off">
                        <div class="dropdown-menu combo"  id="clienteList"></div>                            
                    </div>
                </div> 
                <div class="col-12 col-sm-12 col-md-8" hola  id="divcliente">
                    <div class="form-group">
                        <label for="cliente">Afiliado</label>
                        <input type="text" name="cliente2" class="form-control" id="cliente2" autocomplete="off" disabled>
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-8"hola hidden >
                    <div class="form-group">
                        <input type="text" name="idcliente" class="form-control" id="idcliente">
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-12"hola   id="divnumdoc" >
                    <div class="form-group">
                        <label for="nombre">N° Documento</label>
                        
                        <input type="text" name="numdoc"  class="form-control" id="numdoc" required="">
                    </div>
                </div>
                <div class="col-12 col-sm-12 col-md-12"hola   id="divconcepto"></div> 
                <div class="col-12 col-sm-12 col-md-12" j  id="divdescripcion2">
                    <div class="form-group">
                        <label for="descripcion">Descripción</label>
                        
                        <input class="form-control" id="descripcion2" name="descripcion2" autocomplete="off">                        
                    </div>
                </div> 
                <div class="col-12 col-sm-12 col-md-12"hola   id="otro_concepto"></div> 
                <div class="col-12 col-sm-12 col-md-12"hola  j id="divmonto">
                    <div class="form-group">
                        <label for="descripcion">total</label>
                        <input class="form-control" id="total" name="total">
                    </div>
                </div>                          
            </div>
            <div class="row" id="precio-otros" hidden>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="total">Total a Pagar</label>
                    <input type="text" name="montototal" class="form-control" id="montototal" placeholder="S/. 0.00" >
                </div>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="acuenta">Pagó </label>
                    <input type="text" name="total2" class="form-control" id="total2" value="0.00"  >
                </div>
                <div class="form-group col-12 col-sm-4 col-md-4">
                    <label for="saldo">Saldo</label>
                    <input type="text" name="saldo" class="form-control" id="saldo" placeholder="S/. 0.00" readonly >
                </div> 
            </div>
            <div class="row justify-content-center"hola  id="button">
                <div class="col-11 col-sm-11 col-md-11">
                    <button type="submit" class="btn btn-success my-3 btn-lg btn-block" data-toggle="modal" data-target="#fecha">Guardar</button>
                </div>                
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

    $("#tipo").change(function(){
        var _token = $('input[name="_token"]').val();
        $.ajax({
            url:"<?php echo e(route('numdoc.buscar')); ?>", 
            method:"POST",
            data:{
                _token:_token
                // '_token':'<?php echo e(Session::token()); ?>'
            },
            success:function(data){
                console.log(data);
                if($('#tipo').val()=='Deposito' || $('#tipo').val()=='Ingreso'){
                    $('#numdoc').val(data['numdoci']);
                }
                if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
                    $('#numdoc').val(data['numdoce']);
                }
            }
        });

      /*   if($('#tipo').val()=='Deposito' || $('#tipo').val()=='Ingreso'){

            $("#divconcepto").change(function(){

                var option=($('#concepto option:selected').html());
                if(option=='OTROS'){
                    $('#precio-otros').removeAttr('hidden');
                    $('#divdescripcion2').removeAttr('hidden');
                    $('#divmonto').attr('hidden', 'hidden');
                }       

                if(option!='OTROS'){
                    $('#precio-otros').attr('hidden', 'hidden');
                    $('#divdescripcion2').attr('hidden', 'hidden');
                    $('#divmonto').removeAttr('hidden');
                }
            })
        
            $("#precio-otros").change(function(){
                var montototal=parseFloat($('#montototal').val()); 
                var total=parseFloat($('#total2').val());
                $('#saldo').val(montototal-total);
                if (total>montototal) {
                    $('#saldo').val(montototal);
                    ($('#total2').val('0.00'));
                    $('#saldo').val(montototal);
                }
            })
        }if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
            $('#precio-otros').removeAttr('hidden');
            $('#divdescripcion2').removeAttr('hidden');
            $('#divmonto').attr('hidden', 'hidden');
        } */
    });

    $('#cliente').keyup(function(event){ 
        var query = $(this).val();
        console.log(query);
        var url="<?php echo e(route('afiliado.buscar')); ?>";
        ;
        if($('#tipo').val()=='Egreso' || $('#tipo').val()=='Transferencia'){
            url="<?php echo e(route('proveedor.buscar')); ?>"
            console.log('hola egreso');
        }

        if(query != ''){
          var _token = $('input[name="_token"]').val();
          $.ajax({
              url:url, 
              method:"POST",
              data:{
                  query:query, 
                  _token:_token
                  // '_token':'<?php echo e(Session::token()); ?>'
              },
              success:function(data){
                  $('#clienteList').fadeIn();  
                  $('#clienteList').html(data);
              }
          });
        }
    });

    $('#clienteList').on('click', 'li', function(){  
        $('#cliente').val($(this).text());                  
        $('#clienteList').fadeOut();
        var cliente = $(this).attr("nombre");
        $('#cliente2').val(cliente);
        $('#idcliente').val($(this).attr('id'));
    }); 



   /*  $('#descripcion2').keyup(function(event){ 
        var query = $(this).val();
        var id= $('#idcliente').val();
        // console.log(query);
        // console.log(id);
        if(query != ''){
          var _token = $('input[name="_token"]').val();
          $.ajax({
              url:"<?php echo e(route('otros_concepto.buscar')); ?>", 
              method:"POST",
              data:{
                  query:query, 
                  _token:_token,
                  id:id,
                  // '_token':'<?php echo e(Session::token()); ?>'
              },
              success:function(data){
                  $('#otro_concepto').fadeIn();  
                  $('#otro_concepto').html(data);
                //   console.log(data);
              }
          });
        }
    });

    $('#otro_concepto').on('click', 'li', function(){  
        $('#descripcion2').val($(this).text());                  
        $('#otro_concepto').fadeOut();

        var array = $(this).attr("nombre");
        var array2= array.split('?');
        var total=array2[0];
        var saldo=array2[1];
        $('#montototal').val(total);
        $('#montototal').attr('disabled','disabled');
        $('#saldo').val(saldo);
        
    });

    $('#descripcion2').change(function(){
        $('#montototal').val('');
        $('#montototal').removeAttr('disabled');
        $('#saldo').val('');
        $('#total2').val('');
    }); */


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>