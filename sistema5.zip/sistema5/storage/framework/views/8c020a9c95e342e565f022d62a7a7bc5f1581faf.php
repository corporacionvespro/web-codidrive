<?php $__env->startSection('content'); ?>
<div class="container">
    
<a href="<?php echo e(route('afiliado.create')); ?>" class="btn btn-primary mb-3" role="button"><i class="fas fa-plus-circle"></i> Registrar nuevo</a>
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de afiliados</div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Afiliado</th>
                        <th scope="col">DNI </th>
                        <th scope="col">Telefono - Celular</th>
                        <th scope="col">Direccion</th>
                        <th scope="col">Unidad</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $afiliados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $afiliado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($afiliado->nombre); ?> <?php echo e($afiliado->apellido); ?></td>
                        <td><?php echo e($afiliado->dni); ?></td>
                        <td><?php echo e($afiliado->telefono); ?> - <?php echo e($afiliado->celular); ?> </td>
                        <td><?php echo e($afiliado->direccion); ?> </td>
                        <td><?php echo e($afiliado->unidad); ?> </td>
                        <td>
                            <a class="btn btn-primary text-white" href=" <?php echo e(route('afiliado.show', $afiliado->id)); ?> " >
                            Ver
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-success text-white" href=" <?php echo e(route('afiliado.edit', $afiliado->id)); ?> " role="button">
                            Editar
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-danger text-white" href=" <?php echo e(route('afiliado.show', $afiliado->id)); ?> " role="button">
                                Eliminar
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-danger text-white" href=" <?php echo e(route('afiliado.showcosto', $afiliado->id)); ?> " role="button">
                                adeudo
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>