<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card card-register mx-auto">
            <div class="card-header">
                <?php echo e($afiliado->nombre); ?> <?php echo e($afiliado->apellido); ?>

            </div>
            <div class="card-body">
            <form id="formcosto"  action="<?php echo e(route('cliente.concepto',$afiliado->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?> 
                    <h5 class="card-title">Conceptos a pagar</h5>
                    <input class="form-control" hidden type="text" id="idcliente" name="idcliente" value="<?php echo e($afiliado->id); ?>">
                    <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check " id="div-<?php echo e($concepto->id); ?>">
                            <?php if($concepto->concepto_id!=null): ?>
                                <input class="form-check-input chk-concepto" type="checkbox" name="concepto[]" id="check-<?php echo e($concepto->id); ?>" value="<?php echo e($concepto->id); ?>" checked disabled >
                            <?php else: ?>
                                <input class="form-check-input chk-concepto" type="checkbox" name="concepto[]" id="check-<?php echo e($concepto->id); ?>" value="<?php echo e($concepto->id); ?>" >
                            <?php endif; ?>
                            
                        
                        

                            <label class="form-check-label" for="<?php echo e($concepto->id); ?>"><?php echo e($concepto->nombre); ?></label>
                        <input hidden class="form-control form-control-sm precio" type="text" id="precio-<?php echo e($concepto->id); ?>" name="<?php echo e($concepto->id); ?>" value="<?php echo e(number_format($concepto->precio,2)); ?>">

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" class="form-control btn-primary">Guardar</button>
                </form>
            </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>