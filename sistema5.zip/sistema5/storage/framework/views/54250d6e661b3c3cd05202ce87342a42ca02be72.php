<?php $__env->startSection('content'); ?>
<div class="container">
    
<a href="<?php echo e(route('concepto_egreso.create')); ?>" class="btn btn-primary mb-3" role="button"><i class="fas fa-plus-circle"></i> Registrar nuevo</a>
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de concepto de egresos</div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Nombre </th>
                        <th scope="col">Precio</th>
                        <th scope="col">Periodo</th>
                        <th scope="col">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($concepto->nombre); ?></td>
                        <td>S/. <?php echo e($concepto->precio); ?></td>
                        <td><?php echo e($concepto->periodo); ?></td>
                        
                        <td>
                            <a class="btn btn-success text-white" href=" <?php echo e(route('concepto_egreso.edit', $concepto->id)); ?> " role="button">
                            Editar
                            </a>
                        </td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>