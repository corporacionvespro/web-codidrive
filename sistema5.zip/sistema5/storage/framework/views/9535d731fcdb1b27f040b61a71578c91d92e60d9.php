<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
        <div class="card-header text-center">Registrar  empresas proveedoras</div>
        <div class="card-body">
            <form method="POST" action=" <?php echo e(route('proveedor.store')); ?> "> 
                        <?php echo e(csrf_field()); ?> 
                <div class="form-group">
                    <div class="form-group">
                        <div class="input-group <?php echo e($errors->has('nombre') ? 'input-error' : ''); ?>">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user"></i></span>
                            </div>
                            <input class="form-control " id="nombre" name="nombre" type="text"   placeholder="Nombre de la empresa destino" value=<?php echo e(old('nombre')); ?> >
                        </div>
                        <?php if($errors->has('nombre')): ?>
                            <span class="error"><strong><?php echo e($errors->first('nombre')); ?></strong></span>
                        <?php endif; ?>  
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                            </div>
                            <input class="form-control" id="tefefono" name="telefono" type="text"   placeholder="telefono" >
                        </div>
                    </div>
                    <button type="submit" class="form-control btn-primary">Registrar</button>
            </form>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>