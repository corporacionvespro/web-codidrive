
        <?php echo e(csrf_field()); ?>

        
            <div class="card-body pt-0" >                                
               
               <?php if(isset($ingreso)): ?>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Tipo</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"><?php echo e($ingreso->tipo); ?></label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Unidad</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> <?php echo e($ingreso->cliente->nombre); ?> <?php echo e($ingreso->cliente->apellido); ?></label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Afiliado</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"> palomino vega </label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">N° Doc</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"><?php echo e($ingreso->numdoc); ?></label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Concepto</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"><?php echo e($ingreso->descripcion); ?></label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre">Total</span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"><?php echo e($ingreso->total); ?></label>
                    </div>
                </div>    
               <?php else: ?>
            <?php endif; ?>

            </div>
        
        