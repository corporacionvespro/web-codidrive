<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mb-3">
        <div class="card-header "><i class="fas fa-user-tie"></i> TRABAJADOR: <span class="user"><?php echo e($user->name); ?> <?php echo e($user->apellido); ?></span></div>
        <div class="card-body">
            <form method="GET" action=" <?php echo e(route('user.show',$user)); ?> "> 
                        <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                                </div>
                                <label type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipUsernamePrepend" required  ><?php echo e($user->name); ?> </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                                </div>
                                <label class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos"  ><?php echo e($user->apellido); ?> </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-4">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                                </div>
                                <label class="form-control" id="dni" type="text" name="dni" placeholder="DNI"  ><?php echo e($user->dni); ?> </label>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-at"></i></span>
                                </div>
                                <label class="form-control" id="email" type="email" name="email"   placeholder="email " ><?php echo e($user->email); ?> </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                                </div>
                                <label class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono" ><?php echo e($user->telefono); ?> </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                                </div>
                                <label class="form-control" id="celular" type="text" name="celular"  placeholder="celular" ><?php echo e($user->celular); ?> </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                        </div>
                        <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección" ><?php echo e($user->direccion); ?> </label>
                    </div>
                </div>
               
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Tipo</span>
                                </div>
                                <label class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono" ><?php echo e($user->rol->nombre); ?> </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="mombre">Estado</i></span>
                                </div>
                                <label class="form-control" id="celular" type="text" name="celular"  placeholder="celular" ><?php echo e($user->estado); ?> </label>
                            </div>
                        </div>
                    </div>
                </div>
                
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>