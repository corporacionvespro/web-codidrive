<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Sistema web </title>

  
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> 
  
  <link href="<?php echo e(asset('css/all-fontawesome.min.css')); ?>" rel="stylesheet">  
  
  <link href="<?php echo e(asset('css/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
  
  <link href="https://fonts.googleapis.com/css?family=Warnes" rel="stylesheet">
  
  <link href="<?php echo e(asset('css/sb-admin.css')); ?>" rel="stylesheet">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.print.css">

  
  
  <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>"/>

</head>

<body class="fixed-nav sticky-footer bg" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg fixed-top" id="mainNav">
  <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset('img/user.png')); ?>" width="30" height="30" class="d-inline-block align-top" alt="no estoy">
        VESPRO</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Operaciones">
        <a class="nav-link" href="<?php echo e(route('ingreso.create')); ?>">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Operaciones</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Afiliados">
          <a class="nav-link" href="<?php echo e(route('afiliado.index')); ?>">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">Afiliados</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Caja">
          <a class="nav-link" href="<?php echo e(route('operaciones.cajahoy')); ?>">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">Caja</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="informes">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Informes</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Operaciones hoy ">
              <a class="nav-link" href="<?php echo e(route('operaciones.hoy')); ?>">
                <i class="fas fa-location-arrow"></i>
                <span class="nav-link-text">Operaciones hoy</span>
              </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Ingresos">
            <a class="nav-link" href="<?php echo e(route('operaciones.ingresos')); ?>">
                <i class="far fa-arrow-alt-circle-right"></i>
                <span class="nav-link-text">Ingresos</span>
              </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="egresos">
              <a class="nav-link" href="<?php echo e(route('operaciones.egresos')); ?>">
                <i class="far fa-arrow-alt-circle-left"></i>
                <span class="nav-link-text">Egresos</span>
              </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Depositos">
              <a class="nav-link" href="<?php echo e(route('operaciones.depositos')); ?>">
                <i class="fas fa-arrow-alt-circle-right"></i>
                <span class="nav-link-text">Depositos</span>
              </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Transferencias">
              <a class="nav-link" href="<?php echo e(route('operaciones.transferencias')); ?>">
                <i class="fas fa-arrow-alt-circle-left"></i>
                <span class="nav-link-text">Transferencias</span>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Proveedores">
          <a class="nav-link" href="<?php echo e(route('proveedor.index')); ?>">
            <i class="fa fa-fw fa-user-tag"></i>
            <span class="nav-link-text">Proveedores</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Usuarios">
          <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
            <i class="fa fa-fw fa-users-cog"></i>
            <span class="nav-link-text">Usuarios</span>
          </a>
        </li>


        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Conceptos">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#concepto" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Conceptos</span>
          </a>
          <ul class="sidenav-second-level collapse" id="concepto">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Concepto Ingresos ">
              <a class="nav-link" href="<?php echo e(route('concepto.index')); ?>">
                <i class="fas fa-location-arrow"></i>
                <span class="nav-link-text">Concepto Ingresos</span>
              </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Conceptos Egresos">
              <a class="nav-link" href="<?php echo e(route('concepto_egreso.index')); ?>">
                <i class="far fa-arrow-alt-circle-right"></i>
                <span class="nav-link-text">Concepto Egreso</span>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Usuarios">
          <a class="nav-link" href="<?php echo e(route('user.index')); ?>">
            <i class="fa fa-fw fa-users-cog"></i>
            <span class="nav-link-text">Configuraciones</span>
          </a>
        </li>
        
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Usuarios">
          <a class="nav-link" href="<?php echo e(route('empresa.index')); ?>">
            <i class="fa fa-fw fa-users-cog"></i>
            <span class="nav-link-text">Empresa</span>
          </a>
        </li>
      </ul>
      
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
            <i class="fas fa-sign-out-alt"></i>
          </a>
        </li>
      </ul>
      
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle mr-lg-2" id="messagesDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo e(Auth::user()->name); ?>

            <i class="fa fa-user fa-fw"></i>
            <span class="d-lg-none">User</span>
          </a>
          <div class="dropdown-menu user" aria-labelledby="messagesDropdown">
            <a class="dropdown-item" href="#">
                    <i class="fa fa-user fa-fw"></i>Perfil usuario
            </a>
            
            <a class="dropdown-item" href="<?php echo e(route('cerrar')); ?>"
                onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i> Salir
            </a>
            <form id="logout-form" action="<?php echo e(route('cerrar')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
          </div>
        </li>
      </ul>

      
    </div>
  </nav>
  <div class="content-wrapper">
    <div class="container-fluid" id="contenido">

        <?php if(session()->has('acceso')): ?>
          <div class="myAlert-top alert alert-danger" >
            <strong>:(</strong> <?php echo e(session('acceso')); ?>

            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          </div>
        <?php endif; ?> 
      
      <?php echo $__env->yieldContent('content'); ?> 
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © 2019 - CORPORACION VESPRO</small>
        </div>
      </div>
    </footer>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Realmente quiere salir?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-primary" href="login.html">Salir</a>
          </div>
        </div>
      </div>
    </div>
    
    
  </div>
  
  <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
  
  

  <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>

  
  <script src="<?php echo e(asset('js/sb-admin.js')); ?>"></script>
  <script>
    window.Laravel=<?php echo json_encode([
          'csrf_token'=>csrf_token(),
      ]); ?>;  

      /* registrar formlario con ajax */
    /*   $( "#formcosto" ).submit(function( event ) {
      event.preventDefault();
      //cambiar la url 
      history.pushState('','','../afiliado');

      var _token = $('input[name="_token"]').val();
      var precios = Array();
      var inputs =$('#formcosto .precio');
      for (var i = 0; i < inputs.length; i++) {
        var valor = inputs[i];
        var cadena= "#"+inputs[i].id;
        var ckeckbox=$(cadena).siblings('.chk-concepto');
        if (ckeckbox.prop('checked') && ckeckbox.prop('disabled')==false) {
          precios.push(inputs[i].value+'?'+ ckeckbox.prop('value')+'?'+$('#idcliente').val()+'?'+inputs[i].name);
        }
        
        // console.log(precios);
      }
      $.ajax({
          method: "post",
          url:"<?php echo e(route('afiliado.adeudo')); ?>",
          data:{
              
              // '_token':'<?php echo e(Session::token()); ?>',
              _token:_token,
              precios:precios
          },
          success:function(data){
            console.log(data);
            $('#contenido').html(data['html']);
            // $('#contenido').load(data['html']);
            // $ ('html'). load(data); 
        }
      })
      // .done(function( msg ) {
      //     // alert(msg);
      //     console.log(msg);
      // });
    }); */

    $(function(){
        $('#clienteList').on('click', 'li', function(){
          if($('#tipo').val()=='Deposito' || $('#tipo').val()=='Ingreso'){

            var query= $('#idcliente').val();
            $.ajax({
              url:"<?php echo e(route('concepto.buscar')); ?>", 
              method:"POST",
              data:{
                  query:query, 
                  // _token:_token
                  '_token':'<?php echo e(Session::token()); ?>'
              },

              success:function(data){
                console.log(data); 
                var dato;
                var html="";                  
                html+=' <option selected value="">Elija concepto</option>';          
                
                for (var i = 0; i < data.length; i++) {
                    dato= data[i];
                    html+='<option id='+dato['precio']+' nombre='+dato['nombre']+' value="'+dato['id']+'?'+dato['precio']+'?'+dato['periodo']+'?'+dato['cliente_id']+'?'+dato['nombre']+'">'+dato['nombre']+'</option>';
                }
                // html+='</select>';
                // html+=' </div>';
              
                $('#select-concepto').html(html);
                console.log( $('#select-concepto').html(html)); 

              }
            });
          }
        }); 
    })
  </script>
   <?php echo $__env->yieldContent('scripts'); ?> 
   <script>
     
     window.setTimeout(function() {      
      $(".myAlert-top").fadeTo(500, 0).slideUp(500, function(){
          $(this).remove(); 
      });
    }, 4000);
   </script>
</body>

</html>
