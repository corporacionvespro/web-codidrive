<?php $__env->startSection('content'); ?>
<div class="container">
    
    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mb-3" role="button"><i class="fas fa-plus-circle"></i> Registrar nuevo</a>
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de usuarios</div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Usuario</th>
                        <th scope="col">Email </th>
                        <th scope="col">Contraseñia</th>
                        <th scope="col">DNI</th>
                        <th scope="col">Telefono</th>
                        <th scope="col">Celular</th>
                        <th scope="col">Direccion</th>
                        <th scope="col">Rol</th>
                        <th scope="col">Estado</th>
                        <th scope="col" colspan="3">Acciones</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($user->name); ?> <?php echo e($user->apellido); ?></td>
                        <td><?php echo e($user->email); ?> </td>
                        <td><?php echo e($user->password); ?> </td>
                        <td><?php echo e($user->dni); ?></td>
                        <td><?php echo e($user->telefono); ?></td>
                        <td><?php echo e($user->celular); ?> </td>
                        <td><?php echo e($user->direccion); ?> </td>
                        <td><?php echo e($user->rol->nombre); ?> </td>
                        <td><?php echo e($user->estado); ?> </td>
                        <td>
                            <a class="btn btn-primary text-white" href="<?php echo e(route('user.show',$user->id)); ?>" >
                            Ver
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-success text-white" href=" <?php echo e(route('user.edit', $user->id)); ?> " role="button">
                            Editar
                            </a>
                        </td>
                        <td>
                            <a class="btn btn-danger text-white" href=" # " role="button">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>