<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
            <div class="card-header "><i class="fas fa-user-tie"></i> AFILIADO: <span class="user"><?php echo e($afiliado->nombre); ?> <?php echo e($afiliado->apellido); ?></span></div>
      <div class="card-body">
        <form method="POST" action=" <?php echo e(route('afiliado.show',$afiliado->id)); ?> ">
                    <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                        <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                        </div>
                        <label type="text" class="form-control" id="nombre" name="nombre" placeholder="nombres" aria-describedby="validationTooltipafiliadonamePrepend" required ><?php echo e($afiliado->nombre); ?></label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-user-tie"></i></span>
                    </div>
                    <label class="form-control" id="apellido" name="apellido" type="text" placeholder="apellidos" ><?php echo e($afiliado->apellido); ?></label>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-id-card"></i></span>
                    </div>
                    <label class="form-control" id="dni" type="text" name="dni" placeholder="DNI"><?php echo e($afiliado->dni); ?></label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-car"></i></span>
                    </div>
                    <label class="form-control" id="email" type="text" name="unidad"   placeholder="N° de unidad "> <?php echo e($afiliado->unidad); ?></label>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                    </div>
                    <label class="form-control" id="telefono" type="text" name="telefono"   placeholder="telefono"><?php echo e($afiliado->telefono); ?></label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="mombre"><i class="fas fa-mobile-alt"></i></span>
                    </div>
                    <label class="form-control" id="celular" type="text" name="celular"  placeholder="celular"><?php echo e($afiliado->celular); ?></label>
                    </div>
                </div>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-map-marker-alt"></i></span>
                </div>
                <label class="form-control" id="direccion" name="direccion" type="text"   placeholder="dirección"><?php echo e($afiliado->direccion); ?></label>
                </div>
            </div>
            
            
            

            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th scope="col">Concepto</th>
                            <th scope="col">Precio </th>
                            <th scope="col">Periodo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $concepto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item->nombre); ?></td>
                            <td><?php echo e($item->precio); ?> </td>
                            <td><?php echo e($item->periodo); ?> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
        </form>

        <div>

                <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">DERECHO</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">GPS</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">CAMISA</a>
                        </li>
                      </ul>
                      <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">.
                        hola josep 
                            ..</div>
                        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">...
                            hola elias 
                        </div>
                        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">...
                            klldjfldsfkjdsf
                        </div>
                      </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>