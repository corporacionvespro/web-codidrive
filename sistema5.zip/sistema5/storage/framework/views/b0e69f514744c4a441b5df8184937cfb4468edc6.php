<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card card-register mx-auto">
            <div class="card-header">
                <?php echo e($afiliado->nombre); ?> <?php echo e($afiliado->apellido); ?>

            </div>
            <div class="card-body">
                <form method="POST" action=" <?php echo e(route('cliente.concepto',$afiliado->id)); ?> "> 
                        <?php echo e(csrf_field()); ?>

                    <h5 class="card-title">Conceptos a pagar</h5>
                    <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check form-check-inline" id="combo">
                        <input class="form-check-input" type="checkbox" name="concepto[]" id="<?php echo e($concepto->id); ?>" value="<?php echo e($concepto->id); ?>">
                            <label class="form-check-label" for="<?php echo e($concepto->id); ?>"><?php echo e($concepto->nombre); ?></label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <button type="submit" class="form-control btn-primary">Guardar</button>
                </form>
            </div>
            </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>