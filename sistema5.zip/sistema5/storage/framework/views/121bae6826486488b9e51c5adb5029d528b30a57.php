<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mb-3">
        <div class="card-header text-center"><i class="fa fa-table"></i>Lista de afiliados con deuda </div>
        <div class="card-body">
            <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Afiliado</th>
                        <?php $__currentLoopData = $conceptos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $concepto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col"><?php echo e($concepto->nombre); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    
                    <tr>
                        
                        
                        <td>1</td>
                        <td>palomino vega </td>
                        <td>S/. 10</td>
                        <td>S/. 10</td>
                        <td>S/. 10</td>
                    </tr>
                    
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>