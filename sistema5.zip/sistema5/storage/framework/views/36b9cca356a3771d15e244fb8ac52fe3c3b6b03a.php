<?php $__env->startSection('content'); ?>

    <div class="col-sm-12 col-md-12 col-12">
        <div class="row mt-3">
            <div class="col-12">
                <div class="card ">
                    <div class="card-header">
                        
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-12">
                                    <button class="btn" data-toggle="modal" data-target="#fecha"><span><i class="fas fa-calendar-alt"></i></button>
                            </div>
                            <div class="col-md-4 col-sm-4 col-12 text-center">
                                    <strong>Resumen del dia</strong> 
                            </div>
                            <div class="col-md-4 col-sm-4 col-12 text-right">
                                    <label class=" titulo-resumen"><?php echo e(isset($inicio) ? $inicio : date("Y-m-d")); ?>  :: <?php echo e(isset($fin) ? $fin :""); ?> </label>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">                                   
                        <div class="row justify-content-center text-center">
                            <div class="col-12 col-md-4 col-lg-4 ">
                                <div class="card bg">
                                    <h5 class="text-datos">Caja</h5>
                                    <h2 class="dato">S/. <?php echo e($caja); ?></h2>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-4 ">
                                <div class="card bg">
                                    <h5 class="text-datos">Ctas Bancarias</h5>
                                    <h2 class="dato">S/. <?php echo e($banco); ?></h2>
                                </div>
                            </div>
                            <div class="col-12 col-md-4 col-lg-4 ">
                                <div class="card bg">
                                    <h5 class="text-datos">Combinado</h5>
                                    <h2 class="dato">S/. <?php echo e($combinado); ?> </h2>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-2" id="datos">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-right"> Ingresos:</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">S/. <?php echo e($ingreso); ?></label>
                                    </div>
                                </div>
                            </div> 
                            
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-right"> Depositos:</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">S/.<?php echo e($deposito); ?></label>
                                    </div>
                                </div>
                            </div> 
                        </div>
                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">                                                                
                                                <i class="fas fa-angle-double-left"> Egreso</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">S/. <?php echo e($egreso); ?></label>
                                    </div>
                                </div>
                            </div> 
                            <div class="col-12 col-sm-12 col-md-12 col-lg-6">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-left"> Transferencias:</i>
                                            </span>
                                        </div>
                                        <label class="form-control" for="ingreso">
                                            S/. <?php echo e($transferencia); ?>

                                        
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </div>
    </div>
        
    <div class="modal fade" id="fecha" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title titulo" id="exampleModalCenterTitle">Fechas</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                
                    <form method="POST" action="<?php echo e(route('operaciones.cajafecha')); ?>"> 
                            <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-12 col-sm-12 col-md-12 ">               
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">                                                                
                                                <i class="fas fa-angle-double-left">fecha inicio</i>
                                            </span>
                                        </div>
                                        <input type="date" class="form-control" name="inicio" id="" value="<?php echo e(isset($inicio) ? $inicio : date("Y-m-d")); ?>">
                                    </div>
                                </div>
                            </div> 
                            <div class="col-12 col-sm-12 col-md-12 ">               
                                <div class="form-group">
                                    <div class="input-group" >
                                        <div class="input-group-prepend">
                                            <span class="input-group-text inputresumen bg">
                                                <i class="fas fa-angle-double-left"> fecha final:</i>
                                            </span>
                                        </div>
                                        <input type="date" class="form-control" name="fin" id="" value="<?php echo e(isset($fin) ? $fin : date("Y-m-d")); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">OK</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>