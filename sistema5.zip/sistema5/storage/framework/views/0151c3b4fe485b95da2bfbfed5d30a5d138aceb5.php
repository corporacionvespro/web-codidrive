<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-register mx-auto mt-2">
      <div class="card-header text-center">Registrar  concepto para egresos</div>
      <div class="card-body">
        <form method="POST" action=" <?php echo e(route('concepto_egreso.store')); ?> "> 
                    <?php echo e(csrf_field()); ?> 
            <div class="form-group">
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-user"></i></span>
                </div>
                <input class="form-control" id="nombre" name="nombre" type="text"   placeholder="Nombre del concepto" >
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="mombre"><i class="fas fa-phone"></i></span>
                </div>
                <input class="form-control" id="precio" name="precio" type="text"   placeholder="precio" >
                </div>
            </div>
            <div class="form-group">
                <div class="form-row">
                    <div class="col-md-4">
                        <select class="form-control" name="periodo" id="periodo" required="">
                            <option selected value="">Escoger periodo</option>
                            <option value="Diario">Diario</option>
                            <option value="Mensual">Mensual</option>
                            <option value="Unico">Único</option>
                        </select>
                    </div>
                </div>
            </div>
            <button type="submit" class="form-control btn-primary">Registrar</button>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>