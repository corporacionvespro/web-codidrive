<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('welcome');
    return redirect()->route('home');
});

Auth::routes();


// Route::post( 'auth/login', 'CustomAuthController@postLogin');

Route::get('/home', 'HomeController@index')->name('home');

Route::resource('user', 'UserController');
Route::resource('afiliado', 'ClienteController');
Route::resource('proveedor', 'ProveedorController');
Route::resource('concepto', 'ConceptoController');
Route::resource('ingreso', 'IngresoController');
Route::resource('empresa', 'EmpresaController');
Route::resource('concepto_egreso', 'Concepto_egresoController');
// Route::resource('egreso', 'EgresoController');

Route::get('costo/{id}', 'ClienteController@costofijo')->name('concepto_cliente');
Route::post('costo/concepto/{id}',  'ClienteController@concepto' )->name('cliente.concepto');
Route::get('costoshow/{id}/afiliado', 'ClienteController@showcostofijo')->name('afiliado.showcosto');
Route::post('costo/',  'ClienteController@concepto_update' )->name('afiliado.adeudo');

Route::post('/buscar/afiliado', 'ClienteController@buscarafiliado')->name('afiliado.buscar');
Route::post('/buscar/proveedor', 'ProveedorController@buscarproveedor')->name('proveedor.buscar');/*  */
Route::post('/buscar/concepto', 'IngresoController@concepto_cliente')->name('concepto.buscar');
Route::post('/buscar/otros_concepto', 'IngresoController@buscarotro')->name('otros_concepto.buscar');
Route::post('/buscar/numdoc', 'IngresoController@numdoc')->name('numdoc.buscar');
// Route::post('/buscar/fechas', 'OperacionesController@fecha')->name('fecha.buscar');

Route::get('/ingresos', 'OperacionesController@ingreso')->name('operaciones.ingresos');
Route::get('/egresos', 'OperacionesController@egreso')->name('operaciones.egresos');
Route::get('/depositos', 'OperacionesController@deposito')->name('operaciones.depositos');
Route::get('/transferencia', 'OperacionesController@transferencia')->name('operaciones.transferencias');
Route::get('/operaciones-hoy', 'OperacionesController@hoy')->name('operaciones.hoy');

Route::post('/ingresosfecha', 'OperacionesController@ingresofecha')->name('operaciones.ingresosfecha');
Route::post('/egresosfecha', 'OperacionesController@egresofecha')->name('operaciones.egresosfecha');
Route::post('/depositosfecha', 'OperacionesController@depositofecha')->name('operaciones.depositosfecha');
Route::post('/transferenciafecha', 'OperacionesController@transferenciafecha')->name('operaciones.transferenciasfecha');
Route::post('/operaciones-hoyfecha', 'OperacionesController@totales')->name('operaciones.totales');

Route::get('/caja', 'OperacionesController@cajahoy')->name('operaciones.cajahoy');
Route::post('/cajafecha', 'OperacionesController@cajafecha')->name('operaciones.cajafecha')->middleware('roles');



Route::get('/egresos/concepto', 'ConceptoController@egresos')->name('concepto.egresos');
// Route::get('/concepto/egresos', 'OperacionesController@caja')->name('concepto.egreso');
Route::get('/palo', 'ClienteController@deuda')->name('afiliado.deuda');
Route::get('/palo/login', 'ClienteController@login');
Route::post('/resumen/{{Ingreso $ingreso}}', 'IngresoController@create_resumen')->name('ingreso.createresumen');

Route::post('/cerrar', 'HomeController@cerrar_session')->name('cerrar');


