<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clientes', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('nombre','150');
            $table->string('apellido','150');
            $table->string('dni')->unique();
            $table->string('telefono','15')->nullable();
            $table->string('celular','15')->nullable();
            $table->string('direccion','100');
            $table->string('unidad','50')->unique();
            $table->unsignedInteger('empresa_id');
        });

        DB::table('clientes')->insert([
            'nombre'=>'cristian',
            'apellido'=>'palomino vega',
            'dni'=>'12345678',
            'telefono'=>'121212132',
            'celular'=>'12341234',
            'direccion'=>'victor doig y lora',
            'unidad'=>'00001',
            'empresa_id'=>'2',
        ]);
        DB::table('clientes')->insert([
            'nombre'=>'Jose ',
            'apellido'=>'vargas perez',
            'dni'=>'12345638',
            'telefono'=>'121232132',
            'celular'=>'12321234',
            'direccion'=>'victor doig y lora',
            'unidad'=>'00002',
            'empresa_id'=>'2',
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clientes');
    }

}
