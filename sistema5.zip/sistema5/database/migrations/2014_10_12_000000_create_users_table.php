<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('apellido');
            $table->string('email')->unique();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
            $table->string('dni',8)->unique();
            $table->string('telefono','15')->nullable();
            $table->string('celular','15')->nullable();
            $table->string('direccion','100');
            $table->enum('estado',['Activo','Inactivo']);
            $table->unsignedInteger('rol_id');
            $table->unsignedInteger('empresa_id');
        });

        DB::table('users')->insert([
            'name'=>'Cesar',
            'apellido'=>'Choquehuanca',
            'email'=>'cesarchoqueskater@gmail.com',
            'password'=> bcrypt('choquehuanca'),
            'telefono'=>'255555',
            'celular'=>'999999999',
            'direccion'=>'la  quinta aura',
            'dni'=>'77777777',
            'estado'=>'Activo',
            'rol_id'=>1,
            'empresa_id'=>2
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
