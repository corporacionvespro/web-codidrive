<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConceptoEgresosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('concepto_egresos', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('nombre','150');
            $table->double('precio','10,2');
            // $table->string('periodo','1'); /* 1: diario 2:mensual  */
            $table->enum('periodo',['Diario','Semanal','Quinsenal','Mensual'.'Unico']);
            $table->unsignedInteger('empresa_id');
        });
        
        /* DB::table('concepto_egresos')->insert([
            'nombre'=>'alquiler sunat',
            'precio'=>'30',
            'periodo'=>'Mensual',
            'empresa_id'=>'2',
        ]);
        DB::table('concepto_egresos')->insert([
            'nombre'=>'alquiler',
            'precio'=>'10',
            'periodo'=>'Mensual',
            'empresa_id'=>'2',
        ]);
        DB::table('concepto_egresos')->insert([
            'nombre'=>'OTROS',
            'precio'=>'30',
            'periodo'=>'Unico',
            'empresa_id'=>'2',
        ]);
         */
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('concepto_egresos');
    }
}
