<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEgresosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        /* falta corregir  */
        Schema::create('egresos', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('numdoc', '20');
            $table->date('fecha');
            $table->double('total', '10,2');
            // $table->double('saldo');
            // $table->double('acuenta');
            $table->enum('tipo',['Egreso','Transferencia']);
            $table->string('descripcion', '200');             
            $table->unsignedInteger('concepto_id');
            $table->unsignedInteger('proveedor_id');
            $table->unsignedInteger('user_id');
            $table->unsignedInteger('empresa_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('egresos');
    }
}
