<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOtroConceptosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('otro_conceptos', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->string('nombre', '100');
            $table->double('costo','10,2');
            $table->double('saldo','10,2');
            $table->unsignedInteger('cliente_id');
            $table->unsignedInteger('user_id');  //user_id
            $table->unsignedInteger('empresa_id');
            $table->enum('estado',['Debe','Completo']);
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('otro_conceptos');
    }
}
