<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIngresosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingresos', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            
            $table->string('numdoc', '20');
            $table->date('fecha');
            $table->double('total', '10,2');
            // $table->double('saldo');
            // $table->double('acuenta');
            $table->enum('tipo',['Ingreso','Deposito']);
            $table->string('descripcion', '200');             
            $table->string('observaciones', '200');             
            $table->unsignedInteger('concepto_id');
            $table->unsignedInteger('cliente_id');
            $table->unsignedInteger('user_id');  //user_id
            $table->unsignedInteger('empresa_id');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingresos');
    }
}
