<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCostoFijosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('costo_fijos', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            // $table->double('precio', '10.2');
            $table->unsignedInteger('cliente_id');
            $table->unsignedInteger('concepto_id');
            $table->unsignedInteger('empresa_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('costo_fijos');
    }
}
